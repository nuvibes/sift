BEGIN TRANSACTION;
CREATE TABLE acl_grants (
  id              TEXT PRIMARY KEY,
  object_type     TEXT NOT NULL CHECK(object_type IN (
                    'global','root','folder','item',
                    'tag','person','collection','site','photo_set','song')),
  object_id       TEXT,
  subject_user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  effect          TEXT NOT NULL CHECK(effect IN ('share','restrict')),
  created_at      INTEGER NOT NULL,
  UNIQUE(object_type, object_id, subject_user_id, effect)
);
CREATE TABLE app_sessions (
  id            TEXT PRIMARY KEY,
  user_id       TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device_id     TEXT,
  client_kind   TEXT NOT NULL,
  started_at_ms INTEGER NOT NULL,
  last_at_ms    INTEGER NOT NULL
);
CREATE TABLE app_settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
CREATE TABLE artists (
  id                 TEXT PRIMARY KEY,
  name               TEXT NOT NULL,
  name_sort          TEXT,
  created_at         INTEGER NOT NULL,
  created_by_kind    TEXT,
  created_by_user_id TEXT,
  created_by_via     TEXT
);
CREATE TABLE asset_edits (
  asset_id  TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  edited_at INTEGER NOT NULL
) WITHOUT ROWID
;
CREATE TABLE asset_links (
  id         TEXT PRIMARY KEY,
  asset_id   TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  url        TEXT NOT NULL,
  label      TEXT,
  created_at INTEGER NOT NULL,
  UNIQUE(asset_id, url)
);
CREATE TABLE asset_locations (
  id            TEXT PRIMARY KEY,
  asset_id      TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  root_id       TEXT NOT NULL REFERENCES library_roots(id) ON DELETE CASCADE,
  folder_id     TEXT REFERENCES folders(id) ON DELETE SET NULL,
  rel_path      TEXT NOT NULL,
  filename      TEXT NOT NULL,
  size_bytes    INTEGER,
  mtime         INTEGER,
  status        TEXT NOT NULL DEFAULT 'present' CHECK(status IN ('present','missing')),
  first_seen_at INTEGER NOT NULL,
  last_seen_at  INTEGER NOT NULL,







  archive_rel_path TEXT,
  member_path      TEXT,
  UNIQUE(root_id, rel_path)
);
CREATE TABLE asset_people (
  asset_id  TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  person_id TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,


  source    TEXT,

  decided_at INTEGER,

  box_id    TEXT,
  PRIMARY KEY(asset_id, person_id)
);
CREATE TABLE asset_person_refusals (
  asset_id   TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  person_id  TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  refused_at INTEGER NOT NULL,
  PRIMARY KEY(asset_id, person_id)
);
CREATE TABLE asset_probes (
  asset_id      TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  probe_version INTEGER NOT NULL,
  tool          TEXT NOT NULL,
  body          BLOB NOT NULL,
  probed_at     INTEGER NOT NULL
);
CREATE TABLE asset_replay_heat (
  asset_id   TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  bucket     INTEGER NOT NULL,
  watched_ms INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (asset_id, user_id, bucket)
);
CREATE TABLE asset_stash_box_matches (
  asset_id   TEXT NOT NULL REFERENCES assets(id)        ON DELETE CASCADE,
  box_id     TEXT NOT NULL REFERENCES stash_boxes(id)   ON DELETE CASCADE,
  remote_id  TEXT NOT NULL,
  payload    TEXT NOT NULL,
  grade      TEXT NOT NULL CHECK(grade IN ('certain','likely','unsure')),
  state      TEXT NOT NULL DEFAULT 'waiting'
             CHECK(state IN ('waiting','applied','refused')),
  found_at   INTEGER NOT NULL,
  decided_at INTEGER,
  PRIMARY KEY (asset_id, box_id)
);
CREATE TABLE asset_tags (
  asset_id TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  tag_id   TEXT NOT NULL REFERENCES tags(id)   ON DELETE CASCADE,







  source   TEXT,

  decided_at INTEGER,

  box_id   TEXT,
  PRIMARY KEY(asset_id, tag_id)
);
CREATE TABLE asset_user_state (
  asset_id       TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  user_id        TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  favorite       INTEGER NOT NULL DEFAULT 0,
  rating         INTEGER CHECK(rating IS NULL OR rating BETWEEN 1 AND 10),
  view_count     INTEGER NOT NULL DEFAULT 0,
  watched_ms     INTEGER NOT NULL DEFAULT 0,
  resume_ms      INTEGER,
  hidden         INTEGER NOT NULL DEFAULT 0,
  hidden_at      INTEGER,
  last_viewed_at INTEGER,
  completed_at   INTEGER,
  pinned         INTEGER NOT NULL DEFAULT 0,
  o_count        INTEGER NOT NULL DEFAULT 0,
  updated_at     INTEGER NOT NULL,
  PRIMARY KEY (asset_id, user_id)
);
CREATE TABLE asset_usernames (
  asset_id    TEXT NOT NULL REFERENCES assets(id)    ON DELETE CASCADE,
  username_id TEXT NOT NULL REFERENCES usernames(id) ON DELETE CASCADE,



  source     TEXT,

  decided_at  INTEGER,


  post_id     TEXT,

  box_id      TEXT,
  PRIMARY KEY(asset_id, username_id)
);
CREATE TABLE assets (
  id                  TEXT PRIMARY KEY,



  identity            TEXT NOT NULL UNIQUE,
  media_type          TEXT NOT NULL CHECK(media_type IN ('video','image','gif')),
  mime                TEXT,
  width               INTEGER,
  height              INTEGER,
  duration_ms         INTEGER,

  fps                 REAL,
  size_bytes          INTEGER,
  container           TEXT,
  vcodec              TEXT,
  acodec              TEXT,


  bit_depth           INTEGER,
  phash               TEXT,
  videohash           TEXT,
  original_filename   TEXT,


  filename_sort       TEXT,
  added_at            INTEGER NOT NULL,
  probed_at           INTEGER,


  interleave_gap      INTEGER,


  oshash              TEXT,
  video_phash         TEXT,
  title               TEXT,


  download_url        TEXT,


  release_date        TEXT,
  identity_version    INTEGER NOT NULL DEFAULT 0,
  whole_digest        TEXT,


  color_transfer      TEXT,


  stranded_at         INTEGER,


  fingerprint_version INTEGER,
  audio_channels      INTEGER,
  audio_sample_rate   INTEGER,


  video_duration_ms   INTEGER,


  classified_version  INTEGER NOT NULL DEFAULT 1,


  details             TEXT,
  production_date     TEXT,
  site_code           TEXT,


  music               TEXT,

  keep_local          INTEGER NOT NULL DEFAULT 0,

  keep_from_swaps     INTEGER NOT NULL DEFAULT 0,



  still_at_ms         INTEGER
);
PRAGMA writable_schema=ON;
INSERT INTO sqlite_master(type,name,tbl_name,rootpage,sql)VALUES('table','assets_fts','assets_fts',0,'CREATE VIRTUAL TABLE assets_fts USING fts5(
  asset_id UNINDEXED,
  title, filename, path, tags, people, usernames, collections, sites, music,
  tokenize=''trigram'')');
CREATE TABLE 'assets_fts_config'(k PRIMARY KEY, v) WITHOUT ROWID;
INSERT INTO "assets_fts_config" VALUES('version',4);
CREATE TABLE 'assets_fts_content'(id INTEGER PRIMARY KEY, c0, c1, c2, c3, c4, c5, c6, c7, c8, c9);
CREATE TABLE 'assets_fts_data'(id INTEGER PRIMARY KEY, block BLOB);
INSERT INTO "assets_fts_data" VALUES(1,X'');
INSERT INTO "assets_fts_data" VALUES(10,X'00000000000000');
CREATE TABLE 'assets_fts_docsize'(id INTEGER PRIMARY KEY, sz BLOB);
CREATE TABLE 'assets_fts_idx'(segid, term, pgno, PRIMARY KEY(segid, term)) WITHOUT ROWID;
CREATE TABLE assets_fts_rows (
  asset_id TEXT PRIMARY KEY,
  fts_rowid INTEGER NOT NULL
);
CREATE TABLE audio_fingerprint_keys (
  key       INTEGER NOT NULL,
  asset_id  TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  PRIMARY KEY (key, asset_id)
) WITHOUT ROWID
;
CREATE TABLE audio_fingerprints (
  asset_id     TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  algorithm    INTEGER NOT NULL,
  tool         TEXT NOT NULL,
  duration_ms  INTEGER NOT NULL,
  offset_ms    INTEGER NOT NULL DEFAULT 0,
  fingerprint  BLOB NOT NULL,
  computed_at  INTEGER NOT NULL,
  indexed_scheme INTEGER
);
CREATE TABLE audio_fingerprints_pending (
  identity     TEXT PRIMARY KEY,
  algorithm    INTEGER NOT NULL,
  tool         TEXT NOT NULL,
  duration_ms  INTEGER NOT NULL,
  offset_ms    INTEGER NOT NULL DEFAULT 0,
  fingerprint  BLOB NOT NULL,
  computed_at  INTEGER NOT NULL
);
CREATE TABLE backlog_clock (
  id  INTEGER PRIMARY KEY CHECK (id = 1),
  seq INTEGER NOT NULL
);
INSERT INTO "backlog_clock" VALUES(1,0);
CREATE TABLE backlog_counts (
  bit  INTEGER NOT NULL,
  kind TEXT NOT NULL,
  n    INTEGER NOT NULL,
  PRIMARY KEY (bit, kind)
) WITHOUT ROWID
;
CREATE TABLE backlog_files (
  asset_id TEXT PRIMARY KEY,
  kind     TEXT NOT NULL,
  mask     INTEGER NOT NULL
) WITHOUT ROWID
;
CREATE TABLE backlog_moved (
  asset_id TEXT PRIMARY KEY,
  seq      INTEGER NOT NULL
) WITHOUT ROWID
;
CREATE TABLE backlog_terms (
  bit        INTEGER PRIMARY KEY CHECK (bit BETWEEN 0 AND 61),
  signature  TEXT NOT NULL UNIQUE,
  folded_to  INTEGER NOT NULL,
  asked_at   INTEGER NOT NULL,
  checked_at INTEGER NOT NULL,
  building   INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE browse_grants (
  id         TEXT PRIMARY KEY,
  abs_path   TEXT NOT NULL UNIQUE,
  granted_at INTEGER NOT NULL
);
CREATE TABLE claim_rejections (
  name_key   TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL
);
CREATE TABLE collection_items (
  collection_id TEXT NOT NULL REFERENCES collections(id) ON DELETE CASCADE,
  asset_id      TEXT NOT NULL REFERENCES assets(id)      ON DELETE CASCADE,
  added_at      INTEGER,
  PRIMARY KEY(collection_id, asset_id)
);
CREATE TABLE collection_tags (
  collection_id TEXT NOT NULL REFERENCES collections(id) ON DELETE CASCADE,
  tag_id        TEXT NOT NULL REFERENCES tags(id)        ON DELETE CASCADE,
  added_at      INTEGER,
  PRIMARY KEY(collection_id, tag_id)
);
CREATE TABLE collection_user_state (
  collection_id TEXT NOT NULL REFERENCES collections(id) ON DELETE CASCADE,
  user_id       TEXT NOT NULL REFERENCES users(id)       ON DELETE CASCADE,
  favorite      INTEGER NOT NULL DEFAULT 0,
  rating        INTEGER CHECK(rating IS NULL OR rating BETWEEN 1 AND 10),
  hidden        INTEGER NOT NULL DEFAULT 0,
  hidden_at     INTEGER,
  pinned        INTEGER NOT NULL DEFAULT 0,
  updated_at    INTEGER NOT NULL,
  PRIMARY KEY (collection_id, user_id)
);
CREATE TABLE collections (
  id             TEXT PRIMARY KEY,
  name           TEXT NOT NULL,
  cover_asset_id TEXT REFERENCES assets(id) ON DELETE SET NULL,
  owner_id       TEXT REFERENCES users(id) ON DELETE CASCADE,
  created_at     INTEGER NOT NULL,
  cover_at_ms INTEGER,
  name_sort TEXT,
  cover_upload_id TEXT,
  created_by_kind TEXT,
  created_by_user_id TEXT,
  created_by_via TEXT,
  cover_frame TEXT,
  cover_cleared_at INTEGER,
  cover_by_default TEXT,
  edited_at INTEGER
);
CREATE TABLE cover_pictures (
  id             TEXT PRIMARY KEY,
  rel_cache_path TEXT NOT NULL,
  size_bytes     INTEGER,
  created_at     INTEGER NOT NULL
);
CREATE TABLE creator_studios (
  name        TEXT PRIMARY KEY COLLATE NOCASE,
  username_id TEXT REFERENCES usernames(id) ON DELETE CASCADE,
  decided_at  INTEGER NOT NULL
);
CREATE TABLE dedup_candidates (
  id              TEXT PRIMARY KEY,
  asset_a         TEXT REFERENCES assets(id) ON DELETE CASCADE,
  asset_b         TEXT REFERENCES assets(id) ON DELETE CASCADE,
  method          TEXT CHECK(method IN ('phash','videohash','video_phash')),
  distance        INTEGER,


  duration_gap_ms INTEGER,
  status          TEXT NOT NULL DEFAULT 'pending'
                  CHECK(status IN ('pending','confirmed','dismissed')),
  created_at      INTEGER NOT NULL,
  UNIQUE(asset_a, asset_b, method)
);
CREATE TABLE derivatives (
  id             TEXT PRIMARY KEY,
  asset_id       TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  kind           TEXT NOT NULL CHECK(kind IN ('thumb','preview','sprite','rendition','remux')),
  rel_cache_path TEXT NOT NULL,
  params         TEXT NOT NULL DEFAULT '{}',
  size_bytes     INTEGER,
  content_hash   TEXT,
  created_at     INTEGER NOT NULL,
  recipe_version INTEGER NOT NULL DEFAULT 0,
  UNIQUE(asset_id, kind, params)
);
CREATE TABLE download_items (
  url_hash   TEXT NOT NULL,
  media_key  TEXT NOT NULL,
  asset_id   TEXT REFERENCES assets(id) ON DELETE SET NULL,
  created_at INTEGER NOT NULL,
  PRIMARY KEY (url_hash, media_key)
);
CREATE TABLE download_sites (
  key       TEXT PRIMARY KEY,
  site_id   TEXT NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  filed_at  INTEGER NOT NULL
);
CREATE TABLE downloads (
  id             TEXT PRIMARY KEY,
  url            TEXT NOT NULL,
  url_hash       TEXT NOT NULL,
  state          TEXT NOT NULL DEFAULT 'queued'
                 CHECK(state IN ('queued','running','paused','done','duplicate','failed','skipped',
                                 'canceled','quarantined')),
  dest_folder_id TEXT REFERENCES folders(id) ON DELETE SET NULL,
  site           TEXT,
  username       TEXT,
  asset_id       TEXT REFERENCES assets(id) ON DELETE SET NULL,
  error          TEXT,
  created_at     INTEGER NOT NULL,
  error_code     TEXT,
  error_tier     INTEGER,
  via            TEXT,
  finished_at    INTEGER,
  filename       TEXT,
  aimed_kind     TEXT,
  aimed_id       TEXT,
  aimed_by       TEXT,
  job_id         TEXT REFERENCES jobs(id) ON DELETE SET NULL,
  hidden_at      INTEGER,
  via_address    TEXT,
  folder_id      TEXT,
  username_from  TEXT CHECK(username_from IN ('address','resolver','page')),
  remember       INTEGER CHECK(remember IN (0,1)),
  seen_at        INTEGER
, post_id TEXT, title TEXT, posted TEXT, original TEXT, files_offered INTEGER, files_left_out INTEGER, requested_by TEXT REFERENCES users(id) ON DELETE SET NULL, site_id TEXT REFERENCES sites(id) ON DELETE SET NULL, person_id TEXT REFERENCES people(id) ON DELETE SET NULL, reads_refused TEXT);
CREATE TABLE enrichment_runs (
  id        TEXT PRIMARY KEY,
  subject   TEXT NOT NULL CHECK(subject IN ('asset','person','site','tag')),
  local_id  TEXT NOT NULL,
  box_id    TEXT NOT NULL,
  at        INTEGER NOT NULL,
  automatic INTEGER NOT NULL DEFAULT 0,


  applied   TEXT
) WITHOUT ROWID
;
CREATE TABLE face_asset_people (
  asset_id   TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  person_id  TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  PRIMARY KEY(asset_id, person_id)
);
CREATE TABLE face_confirmations (
  id           TEXT PRIMARY KEY,
  asset_id     TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  person_id    TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  embedding    BLOB NOT NULL,
  recognizer   TEXT,
  created_at   INTEGER NOT NULL
);
CREATE TABLE face_detections (
  id           TEXT PRIMARY KEY,
  track_id     TEXT NOT NULL REFERENCES face_tracks(id) ON DELETE CASCADE,
  timestamp_ms INTEGER NOT NULL,
  box_x        INTEGER NOT NULL,
  box_y        INTEGER NOT NULL,
  box_w        INTEGER NOT NULL,
  box_h        INTEGER NOT NULL,
  score        REAL NOT NULL,
  quality      REAL NOT NULL,
  pixels       INTEGER,
  sharpness    REAL,
  frontality   REAL,
  containment  REAL,
  strength     REAL,
  agreement    REAL,
  crop_path    TEXT NOT NULL,
  crop_digest  TEXT NOT NULL,
  embedding    BLOB NOT NULL,
  created_at   INTEGER NOT NULL
);
CREATE TABLE face_folder_left_out (
  job_id TEXT NOT NULL,
  file   TEXT NOT NULL,
  reason TEXT NOT NULL,
  PRIMARY KEY (job_id, file)
);
CREATE TABLE face_folder_read (
  pack_id    TEXT NOT NULL REFERENCES face_packs(id) ON DELETE CASCADE,
  recognizer TEXT NOT NULL,
  folder     TEXT NOT NULL COLLATE NOCASE,
  digest     TEXT NOT NULL,
  PRIMARY KEY (pack_id, recognizer, folder, digest)
);
CREATE TABLE face_grouping (
  id           TEXT PRIMARY KEY,
  asset_id     TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  pile_id      TEXT NOT NULL,
  embedding    BLOB NOT NULL,
  centroid     BLOB NOT NULL,
  recognizer   TEXT,
  created_at   INTEGER NOT NULL
);
CREATE TABLE face_ignored (
  id           TEXT PRIMARY KEY,
  asset_id     TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  pile_id      TEXT NOT NULL,
  embedding    BLOB NOT NULL,
  centroid     BLOB NOT NULL,
  recognizer   TEXT,
  created_at   INTEGER NOT NULL
);
CREATE TABLE face_own_library (
  one INTEGER PRIMARY KEY CHECK (one = 1),
  id  TEXT NOT NULL
);
CREATE TABLE face_packs (
  id           TEXT PRIMARY KEY,
  name         TEXT NOT NULL UNIQUE COLLATE NOCASE,
  version      TEXT NOT NULL,
  recognizer   TEXT NOT NULL,
  dimension    INTEGER NOT NULL,
  digest       TEXT NOT NULL,
  installed_at INTEGER NOT NULL,
  library      TEXT
);
CREATE TABLE face_pile_proposals (
  pile_id    TEXT NOT NULL REFERENCES face_piles(id) ON DELETE CASCADE,
  person_id  TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  reason     TEXT NOT NULL CHECK(reason IN ('folder')),
  folder_id  TEXT NOT NULL REFERENCES folders(id) ON DELETE CASCADE,
  files      INTEGER NOT NULL,
  of_files   INTEGER NOT NULL,
  state      TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','refused','accepted')),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY(pile_id, person_id)
);
CREATE TABLE face_piles (
  id         TEXT PRIMARY KEY,
  status     TEXT NOT NULL CHECK(status IN ('open','ignored')),
  centroid   BLOB NOT NULL,
  size       INTEGER NOT NULL,
  by_hand    INTEGER NOT NULL DEFAULT 0,
  recognizer TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE face_references (
  id          TEXT PRIMARY KEY,
  person_id   TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  crop_path   TEXT,
  crop_digest TEXT NOT NULL,
  embedding   BLOB NOT NULL,
  quality     REAL NOT NULL,
  origin      TEXT NOT NULL CHECK(origin IN ('added','pack','confirmed','seed','recognized')),
  pack_id     TEXT REFERENCES face_packs(id) ON DELETE CASCADE,
  recognizer  TEXT NOT NULL,
  pixels      INTEGER,
  track_id    TEXT,
  asset_id    TEXT,
  created_at  INTEGER NOT NULL,
  source      TEXT,
  retired_at  INTEGER,
  UNIQUE(person_id, crop_digest)
);
CREATE TABLE face_rejected (
  id           TEXT PRIMARY KEY,
  asset_id     TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  person_id    TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  embedding    BLOB NOT NULL,
  recognizer   TEXT,
  created_at   INTEGER NOT NULL
);
CREATE TABLE face_rejections (
  track_id   TEXT NOT NULL REFERENCES face_tracks(id) ON DELETE CASCADE,
  person_id  TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  PRIMARY KEY(track_id, person_id)
);
CREATE TABLE face_removals (
  id           TEXT PRIMARY KEY,
  asset_id     TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  embedding    BLOB NOT NULL,
  recognizer   TEXT NOT NULL,
  quality      REAL NOT NULL,
  pixels       INTEGER,
  sharpness    REAL,
  frontality   REAL,
  created_at   INTEGER NOT NULL
);
CREATE TABLE face_runs (
  id         TEXT PRIMARY KEY,
  tuning     TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE face_scans (
  asset_id         TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  status           TEXT NOT NULL
                   CHECK(status IN ('no_faces','none_identified','some_identified','all_identified')),
  depth            TEXT NOT NULL CHECK(depth IN ('fast','deep')),
  coverage         REAL NOT NULL,
  frames_sampled   INTEGER NOT NULL,
  track_count      INTEGER NOT NULL,
  identified_count INTEGER NOT NULL,
  detector         TEXT NOT NULL,
  recognizer       TEXT NOT NULL,
  settings_digest  TEXT NOT NULL,
  settings_density REAL,
  quality_version  INTEGER,
  sampling_version INTEGER,
  scanned_at       INTEGER NOT NULL,
  reached_ms       INTEGER,
  settings_shape   TEXT,
  refused_small    INTEGER,
  refused_closer   INTEGER,
  cut_short        INTEGER,
  refused_largest  INTEGER,
  refused_blurred  INTEGER,
  refused_turned   INTEGER,
  refused_edge     INTEGER
);
CREATE TABLE face_starter_refusals (
  person_id   TEXT PRIMARY KEY REFERENCES people(id) ON DELETE CASCADE,
  recognizer  TEXT NOT NULL,
  pictures    INTEGER NOT NULL,
  refused_at  INTEGER NOT NULL
);
CREATE TABLE face_successors (
  track_id     TEXT PRIMARY KEY,
  successor_id TEXT NOT NULL,
  asset_id     TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  created_at   INTEGER NOT NULL
);
CREATE TABLE face_tracks (
  id           TEXT PRIMARY KEY,
  asset_id     TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  started_ms   INTEGER NOT NULL,
  ended_ms     INTEGER NOT NULL,
  seen_in      INTEGER NOT NULL,
  quality      REAL NOT NULL,
  person_id    TEXT REFERENCES people(id) ON DELETE SET NULL,
  confidence   REAL,
  attribution  TEXT CHECK(attribution IN ('matched','suggested','confirmed')),
  pile_id      TEXT REFERENCES face_piles(id) ON DELETE SET NULL,
  attributed_at INTEGER,
  created_at   INTEGER NOT NULL,
  asked_by     TEXT CHECK(asked_by IN ('match','group','undone','box'))
);
CREATE TABLE face_weights (
  id           TEXT PRIMARY KEY,
  revision     TEXT NOT NULL,
  digest       TEXT NOT NULL,
  size_bytes   INTEGER NOT NULL,
  installed_at INTEGER NOT NULL
);
CREATE TABLE file_departure_viewers (
  user_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  asset_id  TEXT NOT NULL REFERENCES file_departures(asset_id) ON DELETE CASCADE,
  concealed INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, asset_id)
) WITHOUT ROWID
;
CREATE TABLE file_departures (
  asset_id      TEXT PRIMARY KEY,
  arrived_at    INTEGER,
  ended_at      INTEGER NOT NULL,
  size_bytes    INTEGER,
  media_type    TEXT,
  duration_ms   INTEGER,
  site_ids      TEXT NOT NULL DEFAULT '[]',
  viewers_known INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE file_moves (
  id             TEXT PRIMARY KEY,
  kind           TEXT NOT NULL,
  location_id    TEXT,
  asset_id       TEXT,
  root_id        TEXT NOT NULL,
  from_rel_path  TEXT NOT NULL,
  from_folder_id TEXT,
  to_rel_path    TEXT NOT NULL,
  to_folder_id   TEXT,
  moved_by       TEXT REFERENCES users(id) ON DELETE SET NULL,


  moved_by_sift  INTEGER NOT NULL DEFAULT 0,


  reason         TEXT,
  moved_at       INTEGER NOT NULL,
  undone_at      INTEGER
);
CREATE TABLE file_verdicts (
  asset_id   TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  product    TEXT NOT NULL,
  code       TEXT NOT NULL,
  reason     TEXT NOT NULL,
  transient  INTEGER NOT NULL DEFAULT 0,
  at         INTEGER NOT NULL,
  PRIMARY KEY (asset_id, product)
);
CREATE TABLE filename_refusals (
  asset_id   TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL
);
CREATE TABLE folder_ancestry (
  folder_id   TEXT NOT NULL REFERENCES folders(id) ON DELETE CASCADE,
  ancestor_id TEXT NOT NULL REFERENCES folders(id) ON DELETE CASCADE,
  depth       INTEGER NOT NULL,
  PRIMARY KEY (folder_id, ancestor_id)
) WITHOUT ROWID
;
CREATE TABLE folder_claims (
  id          TEXT PRIMARY KEY,
  folder_id   TEXT NOT NULL REFERENCES folders(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL CHECK(kind IN ('person','site','username')),
  name_key    TEXT NOT NULL,
  proposed    TEXT NOT NULL,
  person_id   TEXT REFERENCES people(id) ON DELETE CASCADE,
  group_id    TEXT,
  site        TEXT,
  is_username INTEGER NOT NULL DEFAULT 0,
  evidence    TEXT NOT NULL CHECK(evidence IN ('face_group','name_only','filenames',
              'known_in_filenames','username_folder','by_hand')),
  state       TEXT NOT NULL DEFAULT 'pending'
              CHECK(state IN ('pending','confirmed','rejected')),
  created_at  INTEGER NOT NULL,
  decided_at  INTEGER,
  UNIQUE(folder_id, name_key)
);
CREATE TABLE folder_passes (
  folder_id  TEXT PRIMARY KEY REFERENCES folders(id) ON DELETE CASCADE,
  signature  TEXT NOT NULL,
  scanned_at INTEGER NOT NULL
);
CREATE TABLE folder_people (
  folder_id  TEXT NOT NULL REFERENCES folders(id) ON DELETE CASCADE,
  person_id  TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  PRIMARY KEY(folder_id, person_id)
);
CREATE TABLE folder_refusals (
  folder_id  TEXT NOT NULL REFERENCES folders(id) ON DELETE CASCADE,
  person_id  TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  PRIMARY KEY(folder_id, person_id)
);
CREATE TABLE folder_user_state (
  folder_id  TEXT NOT NULL REFERENCES folders(id) ON DELETE CASCADE,
  user_id    TEXT NOT NULL REFERENCES users(id)   ON DELETE CASCADE,
  hidden     INTEGER NOT NULL DEFAULT 0,
  hidden_at  INTEGER,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (folder_id, user_id)
);
CREATE TABLE folders (
  id         TEXT PRIMARY KEY,
  root_id    TEXT NOT NULL REFERENCES library_roots(id) ON DELETE CASCADE,
  parent_id  TEXT REFERENCES folders(id) ON DELETE CASCADE,
  rel_path   TEXT NOT NULL,
  name       TEXT NOT NULL,
  seen_mtime REAL, keep_local INTEGER NOT NULL DEFAULT 0, keep_from_swaps INTEGER NOT NULL DEFAULT 0,
  UNIQUE(root_id, rel_path)
);
CREATE TABLE insight_days (
  user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  day      TEXT NOT NULL,
  metric   TEXT NOT NULL,
  key      TEXT NOT NULL DEFAULT '',
  whole    INTEGER NOT NULL,
  hidden   INTEGER NOT NULL DEFAULT 0,
  split_at INTEGER NOT NULL,
  PRIMARY KEY (user_id, day, metric, key)
) WITHOUT ROWID
;
CREATE TABLE insight_progress (
  user_id     TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  added_up_to TEXT NOT NULL
);
CREATE TABLE interface_state (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key     TEXT NOT NULL,
  value   TEXT NOT NULL,
  PRIMARY KEY(user_id, key)
);
CREATE TABLE job_tallies (
  type  TEXT NOT NULL,
  state TEXT NOT NULL,
  n     INTEGER NOT NULL,
  PRIMARY KEY (type, state)
) WITHOUT ROWID
;
CREATE TABLE jobs (
  id           TEXT PRIMARY KEY,
  parent_id    TEXT REFERENCES jobs(id) ON DELETE CASCADE,
  type         TEXT NOT NULL,
  state        TEXT NOT NULL DEFAULT 'queued'
               CHECK(state IN ('queued','running','done','failed','canceled','blocked','paused')),
  priority     INTEGER NOT NULL DEFAULT 100,
  payload      TEXT NOT NULL,
  progress     REAL NOT NULL DEFAULT 0,
  attempts     INTEGER NOT NULL DEFAULT 0,
  max_attempts INTEGER NOT NULL DEFAULT 3,
  claimed_by   TEXT,
  heartbeat_at INTEGER,
  error        TEXT,


  note         TEXT,




  run_after    INTEGER,
  created_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL,


  units        INTEGER NOT NULL DEFAULT 1,


  started_at   INTEGER,



  stop_wanted  TEXT,




  requested_by TEXT,




  timing       TEXT,



  root_id      TEXT,
  to_read      TEXT
);
CREATE TABLE library_roots (
  id                  TEXT PRIMARY KEY,
  name                TEXT NOT NULL,
  abs_path            TEXT NOT NULL UNIQUE,
  kind                TEXT NOT NULL DEFAULT 'local' CHECK(kind IN ('local','nas','other')),
  created_at          INTEGER NOT NULL
);
CREATE TABLE loop_tags (
  loop_id TEXT NOT NULL REFERENCES loops(id) ON DELETE CASCADE,
  tag_id  TEXT NOT NULL REFERENCES tags(id)  ON DELETE CASCADE,
  added_at INTEGER,
  PRIMARY KEY(loop_id, tag_id)
);
CREATE TABLE loops (
  id         TEXT PRIMARY KEY,
  asset_id   TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,



  start_ms   INTEGER NOT NULL CHECK(start_ms >= 0),
  end_ms     INTEGER NOT NULL,
  name       TEXT,
  created_by TEXT REFERENCES users(id) ON DELETE SET NULL,
  created_at INTEGER NOT NULL,
  edited_at  INTEGER,
  CHECK(end_ms > start_ms)
);
CREATE TABLE machine_rates (
  profile      TEXT PRIMARY KEY,
  measured_at  INTEGER NOT NULL,
  decode_fps   REAL,
  seek_seconds REAL,
  storages     TEXT NOT NULL DEFAULT '{}',




  measurement  TEXT
);
CREATE TABLE music_catchup (
  id       INTEGER PRIMARY KEY CHECK (id = 1),
  until    INTEGER NOT NULL,
  asked_at INTEGER NOT NULL
);
CREATE TABLE music_lookup_key (
  id        INTEGER PRIMARY KEY CHECK (id = 1),
  secret_id TEXT NOT NULL,
  set_at    INTEGER NOT NULL
);
CREATE TABLE music_lookups (
  asset_id     TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  looked_up_at INTEGER NOT NULL,
  lengths_sent TEXT NOT NULL,
  status       TEXT NOT NULL CHECK (status IN ('named', 'nothing', 'refused', 'failed')),
  recording_id TEXT,
  title        TEXT,
  artists      TEXT,
  score        REAL
);
CREATE TABLE music_name_refusals (
  asset_id   TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  song       TEXT NOT NULL,
  refused_at INTEGER NOT NULL,
  PRIMARY KEY (asset_id, song)
) WITHOUT ROWID
;
CREATE TABLE music_pairs (
  a_id        TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  b_id        TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  ber         REAL NOT NULL,
  offset_s    REAL NOT NULL,
  windows     INTEGER NOT NULL,
  matching    INTEGER NOT NULL,
  computed_at INTEGER NOT NULL,
  PRIMARY KEY (a_id, b_id),
  CHECK (a_id < b_id)
) WITHOUT ROWID
;
CREATE TABLE music_waiting (
  asset_id TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE
) WITHOUT ROWID
;
CREATE TABLE opinions (
  id           TEXT PRIMARY KEY,
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject_kind TEXT NOT NULL,
  subject_id   TEXT NOT NULL,
  kind         TEXT NOT NULL CHECK (kind IN ('rating','favorite','pin','o','hide')),
  before       INTEGER,
  after        INTEGER,
  at           INTEGER NOT NULL
);
CREATE TABLE pack_entries (
  id                TEXT PRIMARY KEY,
  pack_id           TEXT NOT NULL REFERENCES face_packs(id) ON DELETE CASCADE,
  name              TEXT NOT NULL,
  aliases           TEXT NOT NULL DEFAULT '[]',
  links             TEXT NOT NULL DEFAULT '[]',
  claimed_person_id TEXT REFERENCES people(id) ON DELETE SET NULL,
  created_at        INTEGER NOT NULL,
  declined_at       INTEGER,
  source            TEXT,
  confirmed         INTEGER,
  UNIQUE(pack_id, name COLLATE NOCASE)
);
CREATE TABLE pack_entry_faces (
  id          TEXT PRIMARY KEY,
  entry_id    TEXT NOT NULL REFERENCES pack_entries(id) ON DELETE CASCADE,
  crop_path   TEXT,
  crop_digest TEXT NOT NULL,
  embedding   BLOB NOT NULL,
  quality     REAL NOT NULL,
  recognizer  TEXT NOT NULL,
  UNIQUE(entry_id, crop_digest)
);
CREATE TABLE page_visits (
  id             TEXT PRIMARY KEY,
  user_id        TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  app_session_id TEXT NOT NULL REFERENCES app_sessions(id) ON DELETE CASCADE,
  place          TEXT NOT NULL,
  ref            TEXT NOT NULL DEFAULT '',
  hidden         INTEGER NOT NULL DEFAULT 0,
  opened_at_ms   INTEGER NOT NULL,
  last_at_ms     INTEGER NOT NULL,
  front_ms       INTEGER NOT NULL,
  device_id      TEXT,
  client_kind    TEXT NOT NULL
);
CREATE TABLE people (
  id             TEXT PRIMARY KEY,
  name           TEXT NOT NULL,
  cover_asset_id TEXT REFERENCES assets(id) ON DELETE SET NULL,
  notes          TEXT,
  created_at     INTEGER NOT NULL,
  cover_track_id TEXT,

  disambiguation TEXT,
  gender TEXT,
  birth_date TEXT,
  country TEXT,
  ethnicity TEXT,
  eye_color TEXT,
  hair_color TEXT,
  height_cm INTEGER,
  measurements TEXT,
  breast_type TEXT,
  career_start_year INTEGER,
  career_end_year INTEGER,
  tattoos TEXT,
  piercings TEXT,
  cover_at_ms INTEGER,
  name_sort TEXT,
  cover_upload_id TEXT,
  pmv_creator INTEGER NOT NULL DEFAULT 0,
  created_by_box_id TEXT,
  created_by_kind TEXT,
  created_by_user_id TEXT,
  created_by_via TEXT,
  keep_local INTEGER NOT NULL DEFAULT 0,
  cover_frame TEXT,
  keep_from_swaps INTEGER NOT NULL DEFAULT 0,
  cover_cleared_at INTEGER,
  cover_by_default TEXT,
  edited_at INTEGER
);
CREATE TABLE people_aliases (
  id        TEXT PRIMARY KEY,
  person_id TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  alias     TEXT NOT NULL,
  alias_sort TEXT,
  added_at  INTEGER,
  UNIQUE(person_id, alias COLLATE NOCASE)
);
CREATE TABLE people_links (
  id          TEXT PRIMARY KEY,
  person_id   TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  url         TEXT NOT NULL,
  site_id     TEXT REFERENCES sites(id) ON DELETE SET NULL,
  label       TEXT,
  created_at  INTEGER NOT NULL,
  UNIQUE(person_id, url)
);
CREATE TABLE person_stash_box_links (
  person_id  TEXT NOT NULL REFERENCES people(id)      ON DELETE CASCADE,
  box_id     TEXT NOT NULL REFERENCES stash_boxes(id) ON DELETE CASCADE,
  remote_id  TEXT NOT NULL,
  payload    TEXT NOT NULL,
  fetched_at INTEGER NOT NULL,
  PRIMARY KEY (person_id, box_id)
);
CREATE TABLE person_tags (
  person_id TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  tag_id    TEXT NOT NULL REFERENCES tags(id)   ON DELETE CASCADE,
  added_at  INTEGER,
  PRIMARY KEY(person_id, tag_id)
);
CREATE TABLE person_user_state (
  person_id  TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  user_id    TEXT NOT NULL REFERENCES users(id)  ON DELETE CASCADE,
  favorite   INTEGER NOT NULL DEFAULT 0,
  rating     INTEGER CHECK(rating IS NULL OR rating BETWEEN 1 AND 10),
  hidden     INTEGER NOT NULL DEFAULT 0,
  hidden_at  INTEGER,
  pinned     INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (person_id, user_id)
);
CREATE TABLE photo_set_items (
  photo_set_id TEXT NOT NULL REFERENCES photo_sets(id) ON DELETE CASCADE,
  asset_id     TEXT NOT NULL REFERENCES assets(id)     ON DELETE CASCADE,
  position     INTEGER,
  added_at     INTEGER,
  PRIMARY KEY(photo_set_id, asset_id)
);
CREATE TABLE photo_set_tags (
  photo_set_id TEXT NOT NULL REFERENCES photo_sets(id) ON DELETE CASCADE,
  tag_id       TEXT NOT NULL REFERENCES tags(id)       ON DELETE CASCADE,
  added_at     INTEGER,
  PRIMARY KEY(photo_set_id, tag_id)
);
CREATE TABLE photo_set_user_state (
  photo_set_id TEXT NOT NULL REFERENCES photo_sets(id) ON DELETE CASCADE,
  user_id      TEXT NOT NULL REFERENCES users(id)      ON DELETE CASCADE,
  hidden       INTEGER NOT NULL DEFAULT 0,
  hidden_at    INTEGER,
  favorite     INTEGER NOT NULL DEFAULT 0,
  rating       INTEGER CHECK(rating IS NULL OR rating BETWEEN 1 AND 10),
  pinned       INTEGER NOT NULL DEFAULT 0,
  updated_at   INTEGER NOT NULL,
  PRIMARY KEY (photo_set_id, user_id)
);
CREATE TABLE photo_sets (
  id             TEXT PRIMARY KEY,
  name           TEXT NOT NULL,
  cover_asset_id TEXT REFERENCES assets(id) ON DELETE SET NULL,



  origin         TEXT NOT NULL DEFAULT 'manual'
                 CHECK(origin IN ('manual','download','folder','archive','filename','shoot','stash_library')),
  origin_url     TEXT,




  folder_id      TEXT REFERENCES folders(id) ON DELETE SET NULL,




  archive_root_id  TEXT REFERENCES library_roots(id) ON DELETE SET NULL,
  archive_rel_path TEXT,
  notes          TEXT,
  created_at     INTEGER NOT NULL,
  cover_at_ms INTEGER,
  name_sort TEXT,
  cover_upload_id TEXT,
  created_by_kind TEXT,
  created_by_user_id TEXT,
  created_by_via TEXT,
  cover_frame TEXT,
  cover_cleared_at INTEGER,
  cover_by_default TEXT,
  edited_at INTEGER
);
CREATE TABLE placeless_assets (asset_id TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE) WITHOUT ROWID;
CREATE TABLE play_names (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind    TEXT NOT NULL CHECK(kind IN ('person','tag','site','song')),
  ref     TEXT NOT NULL,
  name    TEXT NOT NULL,
  since   INTEGER NOT NULL
);
CREATE TABLE plays (
  id              TEXT PRIMARY KEY,
  user_id         TEXT REFERENCES users(id) ON DELETE CASCADE,
  asset_id        TEXT,
  started_at      INTEGER NOT NULL,
  duration_ms     INTEGER NOT NULL,
  ended_at_ms     INTEGER,
  heat            TEXT,
  made_at         INTEGER NOT NULL,


  sitting         TEXT,
  seeks           INTEGER NOT NULL DEFAULT 0,



  screen          TEXT CHECK(screen IN ('panel','corner','theater')),
  opened_from     TEXT CHECK(opened_from IN (
                    'library','search','favorites','recent','loops','person','site','tag',
                    'collection','photo_set','song','organize','downloads','hidden','start',
                    'link','folder','insights','other'
                  )),
  kind            TEXT CHECK(kind IN ('video','image','gif')),

  loop_id         TEXT,
  kept_filter_id  TEXT,
  theater_session TEXT,


  length_ms       INTEGER,



  opened_from_id  TEXT,

  start_ms        INTEGER,
  seek_log        TEXT,
  speeds          TEXT,
  fullscreen_ms   INTEGER,
  completions     INTEGER,
  magnified       INTEGER,

  device_id       TEXT,
  client_kind     TEXT,
  about           TEXT
);
CREATE TABLE produced_files (
  id               TEXT PRIMARY KEY,
  asset_id         TEXT NOT NULL UNIQUE REFERENCES assets(id) ON DELETE CASCADE,
  source_asset_id  TEXT REFERENCES assets(id) ON DELETE SET NULL,
  operation        TEXT NOT NULL,
  preset           TEXT,
  target_bytes     INTEGER,
  produced_by      TEXT REFERENCES users(id) ON DELETE SET NULL,
  produced_at      INTEGER NOT NULL
);
CREATE TABLE recaps (
  id       TEXT PRIMARY KEY,
  user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  period   TEXT NOT NULL,
  made_at  INTEGER NOT NULL,
  seen_at  INTEGER,
  body     TEXT NOT NULL,
  UNIQUE (user_id, period)
);
CREATE TABLE root_import_prefs (
  root_id    TEXT NOT NULL REFERENCES library_roots(id) ON DELETE CASCADE,
  key        TEXT NOT NULL,
  value      TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY(root_id, key)
);
CREATE TABLE root_user_state (
  root_id    TEXT NOT NULL REFERENCES library_roots(id) ON DELETE CASCADE,
  user_id    TEXT NOT NULL REFERENCES users(id)         ON DELETE CASCADE,
  hidden     INTEGER NOT NULL DEFAULT 0,
  hidden_at  INTEGER,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (root_id, user_id)
);
CREATE TABLE said_times (
  run_id  TEXT NOT NULL,
  at      INTEGER NOT NULL,
  quick   INTEGER,
  slow    INTEGER,
  low     INTEGER,
  high    INTEGER,
  left    INTEGER NOT NULL,
  stalled INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE save_log (
  id       TEXT PRIMARY KEY,
  user_id  TEXT REFERENCES users(id)  ON DELETE CASCADE,
  asset_id TEXT REFERENCES assets(id) ON DELETE SET NULL,
  saved_at INTEGER NOT NULL
);
CREATE TABLE saved_searches (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind       TEXT NOT NULL DEFAULT 'asset',
  name       TEXT NOT NULL,
  query      TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  UNIQUE(user_id, kind, name)
);
CREATE TABLE scan_rejections (
  id            TEXT PRIMARY KEY,
  root_id       TEXT NOT NULL REFERENCES library_roots(id) ON DELETE CASCADE,
  rel_path      TEXT NOT NULL,
  size_bytes    INTEGER NOT NULL,
  mtime_ns      INTEGER NOT NULL,
  reason        TEXT NOT NULL,
  detected      TEXT,
  first_seen_at INTEGER NOT NULL,
  last_seen_at  INTEGER NOT NULL,
  UNIQUE(root_id, rel_path)
);
CREATE TABLE schema_version (  component TEXT PRIMARY KEY,  version   INTEGER NOT NULL);
INSERT INTO "schema_version" VALUES('identity',4);
INSERT INTO "schema_version" VALUES('workbench',18);
INSERT INTO "schema_version" VALUES('access',5);
INSERT INTO "schema_version" VALUES('benchmarks',3);
INSERT INTO "schema_version" VALUES('library',7);
INSERT INTO "schema_version" VALUES('content',31);
INSERT INTO "schema_version" VALUES('catalog',92);
INSERT INTO "schema_version" VALUES('dedup',4);
INSERT INTO "schema_version" VALUES('jobs',16);
INSERT INTO "schema_version" VALUES('download',38);
INSERT INTO "schema_version" VALUES('faces',43);
INSERT INTO "schema_version" VALUES('file_moves',4);
INSERT INTO "schema_version" VALUES('importing',1);
INSERT INTO "schema_version" VALUES('user_state',6);
INSERT INTO "schema_version" VALUES('music',6);
INSERT INTO "schema_version" VALUES('visibility',19);
INSERT INTO "schema_version" VALUES('insights',6);
INSERT INTO "schema_version" VALUES('ledger',8);
INSERT INTO "schema_version" VALUES('performance',2);
INSERT INTO "schema_version" VALUES('placeless',1);
INSERT INTO "schema_version" VALUES('player',7);
INSERT INTO "schema_version" VALUES('produced_files',1);
INSERT INTO "schema_version" VALUES('save_log',1);
INSERT INTO "schema_version" VALUES('scan_memory',2);
INSERT INTO "schema_version" VALUES('search_history',11);
INSERT INTO "schema_version" VALUES('semantic',5);
INSERT INTO "schema_version" VALUES('sessions',3);
INSERT INTO "schema_version" VALUES('settings',18);
INSERT INTO "schema_version" VALUES('shoots',1);
INSERT INTO "schema_version" VALUES('stash_boxes',21);
INSERT INTO "schema_version" VALUES('stash_migration',3);
INSERT INTO "schema_version" VALUES('suggestions',11);
INSERT INTO "schema_version" VALUES('swap',5);
INSERT INTO "schema_version" VALUES('theater',7);
INSERT INTO "schema_version" VALUES('tidy',1);
INSERT INTO "schema_version" VALUES('tunnels',1);
INSERT INTO "schema_version" VALUES('watermarks',8);
CREATE TABLE search_events (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL,
  subject     TEXT NOT NULL,
  results     INTEGER,
  opened_id   TEXT,
  at          INTEGER NOT NULL,
  device_id   TEXT,
  client_kind TEXT
);
CREATE TABLE search_history (
  id         TEXT PRIMARY KEY,
  user_id    TEXT REFERENCES users(id) ON DELETE CASCADE,
  kind       TEXT NOT NULL,
  subject    TEXT NOT NULL,
  label      TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE TABLE search_opens (
  id          TEXT PRIMARY KEY,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  event_id    TEXT REFERENCES search_events(id) ON DELETE CASCADE,
  subject     TEXT NOT NULL,
  asset_id    TEXT NOT NULL,
  at          INTEGER NOT NULL,
  device_id   TEXT,
  client_kind TEXT
);
CREATE TABLE search_unindexed (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  n  INTEGER NOT NULL
);
INSERT INTO "search_unindexed" VALUES(1,0);
CREATE TABLE secrets (
  id         TEXT PRIMARY KEY,
  ciphertext BLOB NOT NULL,
  nonce      BLOB NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE semantic_counts (
  revision TEXT PRIMARY KEY,
  files    INTEGER NOT NULL DEFAULT 0,
  frames   INTEGER NOT NULL DEFAULT 0
) WITHOUT ROWID
;
CREATE TABLE semantic_file_keys (
  file     INTEGER PRIMARY KEY,
  asset_id TEXT NOT NULL UNIQUE,
  revision TEXT NOT NULL
);
CREATE TABLE semantic_frame_keys (
  frame    INTEGER PRIMARY KEY,
  asset_id TEXT NOT NULL,
  revision TEXT NOT NULL
);
CREATE TABLE semantic_indexed (
  asset_id   TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  revision   TEXT NOT NULL,
  frames     INTEGER NOT NULL,
  indexed_at INTEGER NOT NULL
);
CREATE TABLE semantic_pooled (
  asset_id TEXT NOT NULL,
  revision TEXT NOT NULL,
  pooled   BLOB NOT NULL,
  PRIMARY KEY (asset_id, revision)
);
CREATE TABLE semantic_unrecorded (
  asset_id TEXT PRIMARY KEY
) WITHOUT ROWID
;
CREATE TABLE sessions (
  id              TEXT PRIMARY KEY,
  user_id         TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash      TEXT NOT NULL UNIQUE,
  created_at      INTEGER NOT NULL,
  last_seen_at    INTEGER NOT NULL,
  expires_at      INTEGER NOT NULL,
  locked_at       INTEGER,
  unlock_failures INTEGER NOT NULL DEFAULT 0,
  device_id       TEXT,
  client_kind     TEXT
);
CREATE TABLE shoot_proposal_items (
  proposal_id TEXT NOT NULL REFERENCES shoot_proposals(id) ON DELETE CASCADE,
  asset_id    TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  position    INTEGER NOT NULL,
  named       INTEGER NOT NULL,
  PRIMARY KEY (proposal_id, asset_id)
);
CREATE TABLE shoot_proposals (
  id        TEXT PRIMARY KEY,
  person_id TEXT NOT NULL REFERENCES people(id) ON DELETE CASCADE,
  name      TEXT NOT NULL,
  found_at  INTEGER NOT NULL
);
CREATE TABLE shoot_refusals (
  asset_id   TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL
);
CREATE TABLE shoot_sets (
  proposal_id  TEXT PRIMARY KEY,
  photo_set_id TEXT NOT NULL,
  decision_id  TEXT,
  made_at      INTEGER NOT NULL
);
CREATE TABLE site_aliases (
  id          TEXT PRIMARY KEY,
  site_id     TEXT NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  alias       TEXT NOT NULL,
  alias_sort  TEXT,
  added_at    INTEGER,
  UNIQUE(site_id, alias COLLATE NOCASE)
);
CREATE TABLE site_art (
  scope     TEXT PRIMARY KEY,
  path      TEXT NOT NULL,
  stored_at INTEGER NOT NULL
, username_id TEXT REFERENCES usernames(id) ON DELETE SET NULL);
CREATE TABLE site_connections (
  id           TEXT PRIMARY KEY,
  site_id      TEXT REFERENCES sites(id) ON DELETE CASCADE,
  secret_id    TEXT REFERENCES secrets(id) ON DELETE SET NULL,
  status       TEXT,
  updated_at   INTEGER,
  expires_at   INTEGER,
  expires_last INTEGER,
  last_used_at INTEGER
);
CREATE TABLE site_links (
  id          TEXT PRIMARY KEY,
  site_id     TEXT NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  url         TEXT NOT NULL,
  label       TEXT,
  created_at  INTEGER NOT NULL,
  UNIQUE(site_id, url)
);
CREATE TABLE site_options (
  scope          TEXT PRIMARY KEY,
  naming         TEXT,
  dest_folder_id TEXT REFERENCES folders(id) ON DELETE SET NULL,




  downloader     TEXT,
  updated_at     INTEGER NOT NULL
);
CREATE TABLE site_stash_box_links (
  site_id    TEXT NOT NULL REFERENCES sites(id)       ON DELETE CASCADE,
  box_id     TEXT NOT NULL REFERENCES stash_boxes(id) ON DELETE CASCADE,
  remote_id  TEXT NOT NULL,
  payload    TEXT NOT NULL,
  fetched_at INTEGER NOT NULL,
  PRIMARY KEY (site_id, box_id)
);
CREATE TABLE site_tags (
  site_id  TEXT NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  tag_id   TEXT NOT NULL REFERENCES tags(id)  ON DELETE CASCADE,
  added_at INTEGER,
  PRIMARY KEY(site_id, tag_id)
);
CREATE TABLE site_user_state (
  site_id     TEXT NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
  user_id     TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  favorite    INTEGER NOT NULL DEFAULT 0,
  rating      INTEGER CHECK(rating IS NULL OR rating BETWEEN 1 AND 10),
  hidden      INTEGER NOT NULL DEFAULT 0,
  hidden_at   INTEGER,
  pinned      INTEGER NOT NULL DEFAULT 0,
  updated_at  INTEGER NOT NULL,
  PRIMARY KEY (site_id, user_id)
);
CREATE TABLE sites (
  id    TEXT PRIMARY KEY,
  name  TEXT NOT NULL UNIQUE COLLATE NOCASE,



  kind  TEXT,
  cover_asset_id TEXT REFERENCES assets(id) ON DELETE SET NULL,
  notes TEXT,
  parent_id TEXT REFERENCES sites(id) ON DELETE SET NULL,
  cover_at_ms INTEGER,
  name_sort TEXT,
  cover_upload_id TEXT,
  created_by_box_id TEXT,
  created_at INTEGER,
  created_by_kind TEXT,
  created_by_user_id TEXT,
  created_by_via TEXT,
  keep_local INTEGER NOT NULL DEFAULT 0,
  cover_frame TEXT,
  keep_from_swaps INTEGER NOT NULL DEFAULT 0,
  cover_cleared_at INTEGER,
  cover_by_default TEXT,


  drawn_by_pack INTEGER NOT NULL DEFAULT 0,
  edited_at INTEGER
);
CREATE TABLE song_artists (
  song_id   TEXT NOT NULL REFERENCES songs(id) ON DELETE CASCADE,
  artist_id TEXT NOT NULL REFERENCES artists(id) ON DELETE CASCADE,
  position  INTEGER NOT NULL,
  source    TEXT CHECK (source IS NULL OR source IN ('acoustid', 'swap')),
  added_at  INTEGER,
  PRIMARY KEY (song_id, artist_id)
) WITHOUT ROWID
;
CREATE TABLE song_files (
  asset_id      TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  song_id       TEXT NOT NULL REFERENCES songs(id) ON DELETE CASCADE,
  source        TEXT CHECK (source IS NULL OR source IN ('acoustid', 'site', 'shared', 'swap')),
  from_asset_id TEXT REFERENCES assets(id) ON DELETE SET NULL,
  score         REAL,
  added_at      INTEGER
);
CREATE TABLE song_user_state (
  song_id    TEXT NOT NULL REFERENCES songs(id) ON DELETE CASCADE,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  hidden     INTEGER NOT NULL DEFAULT 0,
  hidden_at  INTEGER,
  favorite   INTEGER NOT NULL DEFAULT 0,
  rating     INTEGER CHECK(rating IS NULL OR rating BETWEEN 1 AND 10),
  pinned     INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (song_id, user_id)
);
CREATE TABLE songs (
  id                 TEXT PRIMARY KEY,
  name               TEXT NOT NULL,
  name_sort          TEXT,
  recording_id       TEXT,
  notes              TEXT,
  cover_asset_id     TEXT REFERENCES assets(id) ON DELETE SET NULL,
  cover_at_ms        INTEGER,
  cover_upload_id    TEXT,
  cover_frame        TEXT,
  cover_cleared_at   INTEGER,
  cover_by_default   TEXT,
  created_at         INTEGER NOT NULL,
  created_by_kind    TEXT,
  created_by_user_id TEXT,
  created_by_via     TEXT,
  edited_at          INTEGER
);
ANALYZE "sqlite_master";
INSERT INTO "sqlite_stat1" VALUES('version_booted',NULL,'1');
INSERT INTO "sqlite_stat1" VALUES('search_unindexed',NULL,'1');
INSERT INTO "sqlite_stat1" VALUES('assets_fts_config','assets_fts_config','1 1');
INSERT INTO "sqlite_stat1" VALUES('assets_fts_data',NULL,'2');
INSERT INTO "sqlite_stat1" VALUES('schema_version','sqlite_autoindex_schema_version_1','37 1');
INSERT INTO "sqlite_stat1" VALUES('backlog_clock',NULL,'1');
CREATE TABLE stash_box_answers (
  box_id     TEXT NOT NULL REFERENCES stash_boxes(id) ON DELETE CASCADE,
  kind       TEXT NOT NULL,
  ask        TEXT NOT NULL,
  payload    TEXT NOT NULL,
  fetched_at INTEGER NOT NULL,
  PRIMARY KEY (box_id, kind, ask)
);
CREATE TABLE stash_box_catch_ups (
  name   TEXT PRIMARY KEY,
  ran_at INTEGER NOT NULL
);
CREATE TABLE stash_box_kept (
  subject    TEXT NOT NULL,
  local_id   TEXT NOT NULL,
  box_id     TEXT NOT NULL REFERENCES stash_boxes(id) ON DELETE CASCADE,
  key        TEXT NOT NULL,
  mine       TEXT NOT NULL,
  theirs     TEXT NOT NULL,
  decided_at INTEGER NOT NULL,
  PRIMARY KEY (subject, local_id, box_id, key)
);
CREATE TABLE stash_box_scans (
  id         TEXT PRIMARY KEY,
  asset_id   TEXT NOT NULL REFERENCES assets(id)      ON DELETE CASCADE,
  box_id     TEXT NOT NULL REFERENCES stash_boxes(id) ON DELETE CASCADE,
  scanned_at INTEGER NOT NULL,
  found      INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE stash_box_undecided (
  subject    TEXT NOT NULL,
  local_id   TEXT NOT NULL,
  candidates INTEGER NOT NULL,
  seen_at    INTEGER NOT NULL,
  PRIMARY KEY (subject, local_id)
);
CREATE TABLE stash_boxes (
  id                  TEXT PRIMARY KEY,
  name                TEXT NOT NULL,
  endpoint            TEXT NOT NULL UNIQUE,
  secret_id           TEXT,
  enabled             INTEGER NOT NULL DEFAULT 1,
  route               TEXT,
  requests_per_minute INTEGER NOT NULL DEFAULT 240,
  sites_are           TEXT NOT NULL DEFAULT 'site' CHECK(sites_are IN ('site','person')),
  slug                TEXT,
  created_at          INTEGER NOT NULL
);
CREATE TABLE stash_galleries (
  source       TEXT NOT NULL,
  stash_id     INTEGER NOT NULL,
  name         TEXT NOT NULL,
  photo_set_id TEXT,
  pictures     TEXT NOT NULL DEFAULT '[]',
  PRIMARY KEY (source, stash_id)
) WITHOUT ROWID
;
CREATE TABLE stash_groups (
  source        TEXT NOT NULL,
  stash_id      INTEGER NOT NULL,
  name          TEXT NOT NULL,
  collection_id TEXT,
  scenes        TEXT NOT NULL DEFAULT '[]',
  PRIMARY KEY (source, stash_id)
) WITHOUT ROWID
;
CREATE TABLE stash_waiting (
  id       TEXT PRIMARY KEY,
  kind     TEXT NOT NULL CHECK(kind IN ('file','picture')),
  stash_id INTEGER NOT NULL,
  read_at  INTEGER NOT NULL,
  user_id  TEXT REFERENCES users(id) ON DELETE SET NULL,
  label    TEXT NOT NULL,
  label_key TEXT NOT NULL,
  package  TEXT NOT NULL,
  UNIQUE (kind, stash_id)
);
CREATE TABLE stash_waiting_entities (
  kind   TEXT NOT NULL CHECK(kind IN ('person','site','tag')),
  name   TEXT NOT NULL,
  record TEXT NOT NULL,
  PRIMARY KEY (kind, name)
) WITHOUT ROWID
;
CREATE TABLE stash_waiting_files (
  waiting_id  TEXT NOT NULL REFERENCES stash_waiting(id) ON DELETE CASCADE,
  position    INTEGER NOT NULL,
  path        TEXT NOT NULL,
  here        TEXT,
  oshash      TEXT,
  phash       TEXT,
  size_bytes  INTEGER,
  duration_ms INTEGER,
  PRIMARY KEY (waiting_id, position)
) WITHOUT ROWID
;
CREATE TABLE swap_device (
  id             INTEGER PRIMARY KEY CHECK (id = 1),
  device_id      TEXT NOT NULL,
  key_secret_id  TEXT NOT NULL,
  created_at     INTEGER NOT NULL
);
CREATE TABLE swap_manifests (
  session_id   TEXT NOT NULL REFERENCES swap_sessions(id) ON DELETE CASCADE,
  file_key     TEXT NOT NULL,
  size         INTEGER NOT NULL,
  chunk_size   INTEGER NOT NULL,
  done         TEXT NOT NULL DEFAULT '[]',
  digest       TEXT,
  staged_path  TEXT,
  updated_at   INTEGER NOT NULL, version TEXT,
  PRIMARY KEY (session_id, file_key)
) WITHOUT ROWID
;
CREATE TABLE swap_sessions (
  id            TEXT PRIMARY KEY,
  role          TEXT NOT NULL CHECK (role IN ('host', 'guest')),
  state         TEXT NOT NULL CHECK (state IN (
    'waiting', 'connected', 'offered', 'transferring', 'done', 'ended', 'failed')),
  tunnel_id     TEXT,
  peer_device   TEXT,
  token_expires INTEGER,
  chosen        TEXT NOT NULL DEFAULT '[]',
  offered_files INTEGER NOT NULL DEFAULT 0,
  wanted_files  INTEGER NOT NULL DEFAULT 0,
  sent_files    INTEGER NOT NULL DEFAULT 0,
  sent_bytes    INTEGER NOT NULL DEFAULT 0,
  rate_bps      INTEGER,
  dest_folder_id TEXT,
  started_at    INTEGER NOT NULL,
  ended_at      INTEGER,
  end_reason    TEXT
, cut_off_at INTEGER, two_way INTEGER NOT NULL DEFAULT 0, back_offered INTEGER NOT NULL DEFAULT 0, back_wanted INTEGER NOT NULL DEFAULT 0, back_files INTEGER NOT NULL DEFAULT 0, back_bytes INTEGER NOT NULL DEFAULT 0, folder_id TEXT);
CREATE TABLE tag_aliases (
  id     TEXT PRIMARY KEY,
  tag_id TEXT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  alias  TEXT NOT NULL,
  alias_sort TEXT,
  added_at INTEGER,
  UNIQUE(tag_id, alias COLLATE NOCASE)
);
CREATE TABLE tag_stash_box_links (
  tag_id     TEXT NOT NULL REFERENCES tags(id)        ON DELETE CASCADE,
  box_id     TEXT NOT NULL REFERENCES stash_boxes(id) ON DELETE CASCADE,
  remote_id  TEXT NOT NULL,
  payload    TEXT NOT NULL,
  fetched_at INTEGER NOT NULL,
  PRIMARY KEY (tag_id, box_id)
);
CREATE TABLE tag_user_state (
  tag_id     TEXT NOT NULL REFERENCES tags(id)  ON DELETE CASCADE,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  favorite   INTEGER NOT NULL DEFAULT 0,
  rating     INTEGER CHECK(rating IS NULL OR rating BETWEEN 1 AND 10),
  hidden     INTEGER NOT NULL DEFAULT 0,
  hidden_at  INTEGER,
  pinned     INTEGER NOT NULL DEFAULT 0,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (tag_id, user_id)
);
CREATE TABLE tags (
  id             TEXT PRIMARY KEY,
  name           TEXT NOT NULL UNIQUE COLLATE NOCASE,
  cover_asset_id TEXT REFERENCES assets(id) ON DELETE SET NULL,
  created_at     INTEGER NOT NULL,
  description TEXT,
  category TEXT,
  cover_at_ms INTEGER,
  name_sort TEXT,
  cover_upload_id TEXT,
  created_by_box_id TEXT,
  created_by_kind TEXT,
  created_by_user_id TEXT,
  created_by_via TEXT,
  keep_local INTEGER NOT NULL DEFAULT 0,
  cover_frame TEXT,
  parent_id TEXT REFERENCES tags(id) ON DELETE SET NULL,
  keep_from_swaps INTEGER NOT NULL DEFAULT 0,
  cover_cleared_at INTEGER,
  cover_by_default TEXT,
  edited_at INTEGER,
  created_by_act TEXT
);
CREATE TABLE theater_arrangements (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name       TEXT NOT NULL,



  layout     TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,


  shape      TEXT,



  strip      INTEGER NOT NULL DEFAULT 0,



  UNIQUE(user_id, name)
);
CREATE TABLE theater_cells (
  arrangement_id TEXT NOT NULL REFERENCES theater_arrangements(id) ON DELETE CASCADE,
  position       INTEGER NOT NULL,
  source         TEXT NOT NULL,
  media_kind     TEXT NOT NULL,
  ordering       TEXT NOT NULL,
  end_behaviour  TEXT NOT NULL,


  timer_seconds  INTEGER,
  volume         INTEGER NOT NULL,







  sort           TEXT,






  aspect         TEXT,
  PRIMARY KEY (arrangement_id, position)
);
CREATE TABLE theater_sessions (
  id             TEXT PRIMARY KEY,
  user_id        TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  session        TEXT NOT NULL,
  started_at     INTEGER NOT NULL,
  ended_at       INTEGER,
  layout         TEXT,
  cells          INTEGER,
  arrangement_id TEXT,
  sources        TEXT,
  files          INTEGER NOT NULL DEFAULT 0,
  made_at        INTEGER NOT NULL,
  UNIQUE(user_id, session)
);
CREATE TABLE tidy_surveys (
  name        TEXT PRIMARY KEY,
  count       INTEGER NOT NULL,
  frees_bytes INTEGER,
  surveyed_at INTEGER NOT NULL
);
CREATE TABLE tunnel_routes (
  scope      TEXT PRIMARY KEY,
  route      TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE tunnels (
  id         TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  secret_id  TEXT REFERENCES secrets(id) ON DELETE SET NULL,
  enabled    INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  can_host   INTEGER
);
CREATE TABLE undo_rows (
  receipt_id TEXT NOT NULL,
  seq        INTEGER NOT NULL,
  row        TEXT NOT NULL,
  PRIMARY KEY (receipt_id, seq)
) WITHOUT ROWID
;
CREATE TABLE user_settings (
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  key     TEXT NOT NULL,
  value   TEXT NOT NULL,
  PRIMARY KEY(user_id, key)
);
CREATE TABLE username_numbers_waiting (
  site     TEXT NOT NULL,
  number   TEXT NOT NULL,
  files    INTEGER NOT NULL,
  seen_at  INTEGER NOT NULL,
  PRIMARY KEY(site, number)
);
CREATE TABLE usernames (
  id           TEXT PRIMARY KEY,
  site_id      TEXT REFERENCES sites(id) ON DELETE SET NULL,
  name         TEXT NOT NULL,
  display_name TEXT,
  url          TEXT,
  person_id    TEXT REFERENCES people(id) ON DELETE SET NULL,
  created_at   INTEGER NOT NULL,












  number TEXT,




  number_via TEXT,



  number_agreed INTEGER,
  name_sort    TEXT,
  edited_at    INTEGER,
  UNIQUE(site_id, name)
);
CREATE TABLE users (
  id            TEXT PRIMARY KEY,
  username      TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  pin_hash      TEXT,
  role          TEXT NOT NULL CHECK(role IN ('admin','guest')),
  mk_wrapped    BLOB,
  mk_nonce      BLOB,
  mk_kdf_salt   BLOB,
  created_at    INTEGER NOT NULL,
  disabled      INTEGER NOT NULL DEFAULT 0,
  cache_stamp   INTEGER NOT NULL DEFAULT 0,
  renames       INTEGER NOT NULL DEFAULT 0,
  renames_since INTEGER
);
CREATE TABLE version_booted (
  id      INTEGER PRIMARY KEY CHECK (id = 1),
  version TEXT NOT NULL
);
INSERT INTO "version_booted" VALUES(1,'0.2.3');
CREATE TABLE viewer_assets (
  user_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  asset_id  TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  concealed INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, asset_id)
) WITHOUT ROWID
;
CREATE TABLE viewer_entity_counts (
  user_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind      TEXT NOT NULL,
  object_id TEXT NOT NULL,
  permitted INTEGER NOT NULL DEFAULT 0,
  concealed INTEGER NOT NULL DEFAULT 0,
  permitted_bytes INTEGER NOT NULL DEFAULT 0,
  concealed_bytes INTEGER NOT NULL DEFAULT 0,
  permitted_ms INTEGER NOT NULL DEFAULT 0,
  concealed_ms INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, kind, object_id)
) WITHOUT ROWID
;
CREATE TABLE viewer_pair_counts (
  user_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind_a    TEXT NOT NULL,
  id_a      TEXT NOT NULL,
  kind_b    TEXT NOT NULL,
  id_b      TEXT NOT NULL,
  permitted INTEGER NOT NULL DEFAULT 0,
  concealed INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, kind_a, id_a, kind_b, id_b)
) WITHOUT ROWID
;
CREATE TABLE viewer_partner_counts (
  user_id      TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind         TEXT NOT NULL,
  object_id    TEXT NOT NULL,
  partner_kind TEXT NOT NULL,
  permitted    INTEGER NOT NULL DEFAULT 0,
  shown        INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, kind, object_id, partner_kind)
) WITHOUT ROWID
;
CREATE TABLE viewer_stats (
  user_id   TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  permitted INTEGER NOT NULL DEFAULT 0,
  concealed INTEGER NOT NULL DEFAULT 0,
  permitted_bytes INTEGER NOT NULL DEFAULT 0,
  concealed_bytes INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE viewer_wall_totals (
  user_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind      TEXT NOT NULL,
  permitted INTEGER NOT NULL DEFAULT 0,
  shown     INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (user_id, kind)
) WITHOUT ROWID
;
CREATE TABLE visibility_decided (
  user_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  asset_id  TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  concealed INTEGER NOT NULL,
  PRIMARY KEY (user_id, asset_id)
) WITHOUT ROWID
;
CREATE TABLE visibility_members (
  asset_id  TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  side      INTEGER NOT NULL,
  kind      TEXT NOT NULL,
  object_id TEXT NOT NULL,
  n         INTEGER NOT NULL,
  bytes     INTEGER NOT NULL,
  ms        INTEGER NOT NULL,
  PRIMARY KEY (asset_id, side, kind, object_id)
) WITHOUT ROWID
;
CREATE TABLE visibility_moved (
  asset_id TEXT NOT NULL,
  user_id  TEXT NOT NULL,
  dn       INTEGER NOT NULL,
  dc       INTEGER NOT NULL,
  read     INTEGER NOT NULL,
  size     INTEGER NOT NULL,
  time     INTEGER NOT NULL,
  PRIMARY KEY (read, asset_id, user_id)
) WITHOUT ROWID
;
CREATE TABLE visibility_owed (
  asset_id  TEXT NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  user_id   TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  concealed INTEGER,
  owed      INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (asset_id, user_id)
) WITHOUT ROWID
;
CREATE TABLE visibility_pending (
  user_id  TEXT NOT NULL,
  asset_id TEXT NOT NULL,
  PRIMARY KEY (user_id, asset_id)
) WITHOUT ROWID
;
CREATE TABLE visibility_places (
  user_id    TEXT NOT NULL,
  root_id    TEXT NOT NULL,
  place      TEXT NOT NULL,
  restricted INTEGER NOT NULL,
  shared     INTEGER NOT NULL,
  vaulted    INTEGER NOT NULL,
  PRIMARY KEY (user_id, root_id, place)
) WITHOUT ROWID
;
CREATE TABLE watermark_reads (
  asset_id        TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  text            TEXT NOT NULL,
  kind            TEXT NOT NULL DEFAULT 'site',
  site            TEXT NOT NULL,
  username        TEXT,
  confidence      REAL NOT NULL,
  frame_ms        INTEGER,
  revision        TEXT,
  matcher_version INTEGER,
  read_at         INTEGER NOT NULL
, site_id TEXT REFERENCES sites(id) ON DELETE SET NULL);
CREATE TABLE watermark_refusals (
  asset_id   TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL
);
CREATE TABLE watermark_scans (
  asset_id   TEXT PRIMARY KEY REFERENCES assets(id) ON DELETE CASCADE,
  revision   TEXT NOT NULL,
  identity   TEXT NOT NULL,
  found      INTEGER NOT NULL,
  scanned_at INTEGER NOT NULL
);
CREATE TABLE work_prices (
  family     TEXT NOT NULL,
  profile    TEXT NOT NULL,
  kind       TEXT NOT NULL,
  items      INTEGER,
  quick      REAL,
  middle     REAL,
  slow       REAL,
  from_items INTEGER NOT NULL DEFAULT 0,
  runs       TEXT NOT NULL DEFAULT '[]',
  PRIMARY KEY (family, profile, kind)
) WITHOUT ROWID
;
CREATE TABLE work_runs (
  id           TEXT PRIMARY KEY,
  family       TEXT NOT NULL,
  started_at   INTEGER NOT NULL,
  updated_at   INTEGER NOT NULL,
  finished_at  INTEGER,
  stopped      INTEGER NOT NULL DEFAULT 0,
  jobs_done    INTEGER NOT NULL DEFAULT 0,
  jobs_failed  INTEGER NOT NULL DEFAULT 0,
  worker_ms    INTEGER NOT NULL DEFAULT 0,
  files        TEXT NOT NULL DEFAULT '{}',
  stages       TEXT NOT NULL DEFAULT '{}',
  machine      TEXT NOT NULL DEFAULT '',
  profile      TEXT NOT NULL DEFAULT '',
  settings     TEXT NOT NULL DEFAULT '{}',
  version      TEXT NOT NULL DEFAULT '',


  products     TEXT NOT NULL DEFAULT '{}',




  accelerator  TEXT NOT NULL DEFAULT '',


  requested_by TEXT,




  made_for     TEXT,

  ended_with   TEXT,

  time_left    TEXT
);
CREATE TABLE workbench_decision_subjects (
  decision_id TEXT NOT NULL REFERENCES workbench_decisions(id) ON DELETE CASCADE,
  kind        TEXT NOT NULL,
  subject_id  TEXT NOT NULL,
  name        TEXT,
  PRIMARY KEY (decision_id, kind, subject_id)
);
CREATE TABLE workbench_decisions (
  id          TEXT PRIMARY KEY,
  queue       TEXT NOT NULL,
  user_id     TEXT REFERENCES users(id) ON DELETE SET NULL,
  title       TEXT NOT NULL,
  detail      TEXT NOT NULL,
  payload     TEXT NOT NULL,
  decided_at  INTEGER NOT NULL,
  reversed_at INTEGER,
  verb        TEXT,
  actor_kind  TEXT,
  actor_id    TEXT,
  object_kind TEXT,
  object_id   TEXT,
  object_name TEXT,
  touched     INTEGER,
  client_kind TEXT,
  device_id   TEXT
, fold_key TEXT GENERATED ALWAYS AS (
CASE
  WHEN verb IN ('ran', 'merged', 'renamed', 'forgot', 'swap_started', 'swap_ended') THEN id
  WHEN verb IN ('sharing_turned_on', 'sharing_turned_off', 'start_with_windows_on',
                'start_with_windows_off', 'firewall_opened', 'storage_moved',
                'update_started', 'library_opened', 'restarted') THEN id
  WHEN (CASE WHEN verb = 'added' AND json_valid(payload) THEN json_extract(payload, '$.backfilled') END) THEN 'added|backfilled|' || COALESCE(object_kind, '')
  ELSE verb || '|' || queue || '|' || COALESCE(actor_kind, '') || '|'
       || COALESCE(actor_id, '') || '|' || COALESCE(object_kind, '') || '|'
       || CASE
            WHEN verb = 'edited' THEN COALESCE((CASE WHEN verb = 'edited' AND object_kind IS NULL AND json_valid(payload) THEN json_extract(payload, '$.key') END), id)
            WHEN verb = 'decided' THEN title
            WHEN verb = 'song_named' THEN COALESCE(object_id, '') || '|' || COALESCE((CASE WHEN verb = 'song_named' AND json_valid(payload) THEN json_extract(payload, '$.song') END), '')
            WHEN (CASE WHEN verb = 'added' AND actor_kind = 'sift' AND actor_id = 'swap' AND json_valid(payload) THEN json_extract(payload, '$.session') END) IS NOT NULL THEN (CASE WHEN verb = 'added' AND actor_kind = 'sift' AND actor_id = 'swap' AND json_valid(payload) THEN json_extract(payload, '$.session') END)
            WHEN (CASE WHEN verb = 'pressed' AND json_valid(payload) THEN json_extract(payload, '$.passes') END) IS NOT NULL THEN (CASE WHEN verb = 'pressed' AND json_valid(payload) THEN json_extract(payload, '$.passes') END)
            WHEN actor_kind IS NULL OR actor_kind = 'user' THEN COALESCE(object_id, '')
            ELSE ''
          END
       || '|' || COALESCE((CASE WHEN verb = 'deleted' AND json_valid(payload) THEN json_extract(payload, '$.from') END), '')
END) VIRTUAL, fold_gap INTEGER GENERATED ALWAYS AS (CASE WHEN (CASE WHEN verb = 'edited' AND object_kind IS NULL AND json_valid(payload) THEN json_extract(payload, '$.key') END) IS NOT NULL THEN 600 ELSE 60 END) VIRTUAL, opens INTEGER NOT NULL DEFAULT 1, closes INTEGER NOT NULL DEFAULT 1, press_id TEXT);
CREATE INDEX ix_workbench_decided ON workbench_decisions(decided_at DESC, id DESC);
CREATE INDEX ix_workbench_object ON workbench_decisions(object_kind, object_id, decided_at DESC);
CREATE INDEX ix_workbench_actor ON workbench_decisions(actor_id, decided_at DESC);
CREATE INDEX ix_workbench_subject ON workbench_decision_subjects(kind, subject_id);
CREATE INDEX ix_workbench_fold ON workbench_decisions(fold_key, decided_at, id);
CREATE INDEX ix_workbench_openings ON workbench_decisions(fold_key, decided_at, id) WHERE opens = 1;
CREATE INDEX ix_workbench_closings ON workbench_decisions(decided_at DESC, id DESC) WHERE closes = 1;
CREATE INDEX ix_workbench_closing_keys ON workbench_decisions(fold_key, decided_at, id) WHERE closes = 1;
CREATE INDEX ix_workbench_press ON workbench_decisions(press_id, decided_at, id);
CREATE TRIGGER workbench_press_arrives AFTER INSERT ON workbench_decisions BEGIN 
UPDATE workbench_decisions
   SET opens = NOT EXISTS (
         SELECT 1 FROM workbench_decisions p
          WHERE p.fold_key IS workbench_decisions.fold_key
            AND p.decided_at >= workbench_decisions.decided_at - workbench_decisions.fold_gap
            AND (p.decided_at, p.id) < (workbench_decisions.decided_at, workbench_decisions.id)),
       closes = NOT EXISTS (
         SELECT 1 FROM workbench_decisions n
          WHERE n.fold_key IS workbench_decisions.fold_key
            AND n.decided_at <= workbench_decisions.decided_at + workbench_decisions.fold_gap
            AND (n.decided_at, n.id) > (workbench_decisions.decided_at, workbench_decisions.id)) WHERE id = NEW.id OR id = (SELECT p.id FROM workbench_decisions p
          WHERE p.fold_key IS NEW.fold_key AND p.id <> NEW.id
            AND (p.decided_at, p.id) < (NEW.decided_at, NEW.id)
          ORDER BY p.decided_at DESC, p.id DESC LIMIT 1) OR id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1); UPDATE workbench_decisions
   SET press_id = CASE WHEN opens = 0 THEN (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT p.id FROM workbench_decisions p
          WHERE p.fold_key IS NEW.fold_key AND p.id <> NEW.id
            AND (p.decided_at, p.id) < (NEW.decided_at, NEW.id)
          ORDER BY p.decided_at DESC, p.id DESC LIMIT 1))
                       WHEN (SELECT q.opens FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) = 0 THEN (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1))
                       ELSE (SELECT lower(hex(randomblob(16)))) END
 WHERE id = NEW.id; UPDATE workbench_decisions
   SET press_id = CASE WHEN (SELECT COUNT(*) FROM workbench_decisions c WHERE c.press_id = (SELECT q.press_id FROM workbench_decisions q WHERE q.id = NEW.id))
         >= (SELECT COUNT(*) FROM workbench_decisions c WHERE c.press_id = (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1))) THEN (SELECT q.press_id FROM workbench_decisions q WHERE q.id = NEW.id) ELSE (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) END
 WHERE press_id = (SELECT CASE WHEN (SELECT q.press_id FROM workbench_decisions q WHERE q.id = NEW.id) IS NOT (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) AND (SELECT q.opens FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) = 0
                               THEN CASE WHEN (SELECT COUNT(*) FROM workbench_decisions c WHERE c.press_id = (SELECT q.press_id FROM workbench_decisions q WHERE q.id = NEW.id))
         >= (SELECT COUNT(*) FROM workbench_decisions c WHERE c.press_id = (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1))) THEN (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) ELSE (SELECT q.press_id FROM workbench_decisions q WHERE q.id = NEW.id) END END); END;
CREATE TRIGGER workbench_press_moves AFTER UPDATE OF id, queue, title, payload, decided_at, verb, actor_kind, actor_id, object_kind, object_id ON workbench_decisions WHEN OLD.fold_key IS NOT NEW.fold_key OR OLD.decided_at IS NOT NEW.decided_at OR OLD.id IS NOT NEW.id BEGIN 
UPDATE workbench_decisions
   SET opens = NOT EXISTS (
         SELECT 1 FROM workbench_decisions p
          WHERE p.fold_key IS workbench_decisions.fold_key
            AND p.decided_at >= workbench_decisions.decided_at - workbench_decisions.fold_gap
            AND (p.decided_at, p.id) < (workbench_decisions.decided_at, workbench_decisions.id)),
       closes = NOT EXISTS (
         SELECT 1 FROM workbench_decisions n
          WHERE n.fold_key IS workbench_decisions.fold_key
            AND n.decided_at <= workbench_decisions.decided_at + workbench_decisions.fold_gap
            AND (n.decided_at, n.id) > (workbench_decisions.decided_at, workbench_decisions.id)) WHERE id = NEW.id OR id = (SELECT p.id FROM workbench_decisions p
          WHERE p.fold_key IS NEW.fold_key AND p.id <> NEW.id
            AND (p.decided_at, p.id) < (NEW.decided_at, NEW.id)
          ORDER BY p.decided_at DESC, p.id DESC LIMIT 1) OR id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1) OR id = (SELECT p.id FROM workbench_decisions p
          WHERE p.fold_key IS OLD.fold_key AND p.id <> NEW.id
            AND (p.decided_at, p.id) < (OLD.decided_at, OLD.id)
          ORDER BY p.decided_at DESC, p.id DESC LIMIT 1) OR id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS OLD.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (OLD.decided_at, OLD.id)
          ORDER BY n.decided_at, n.id LIMIT 1); UPDATE workbench_decisions SET press_id = (SELECT lower(hex(randomblob(16))))
 WHERE press_id = (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS OLD.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (OLD.decided_at, OLD.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) AND (decided_at, id) >= (SELECT q.decided_at, q.id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS OLD.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (OLD.decided_at, OLD.id)
          ORDER BY n.decided_at, n.id LIMIT 1))
   AND (SELECT q.opens FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS OLD.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (OLD.decided_at, OLD.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) = 1 AND (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT p.id FROM workbench_decisions p
          WHERE p.fold_key IS OLD.fold_key AND p.id <> NEW.id
            AND (p.decided_at, p.id) < (OLD.decided_at, OLD.id)
          ORDER BY p.decided_at DESC, p.id DESC LIMIT 1)) = (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS OLD.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (OLD.decided_at, OLD.id)
          ORDER BY n.decided_at, n.id LIMIT 1)); UPDATE workbench_decisions
   SET press_id = CASE WHEN opens = 0 THEN (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT p.id FROM workbench_decisions p
          WHERE p.fold_key IS NEW.fold_key AND p.id <> NEW.id
            AND (p.decided_at, p.id) < (NEW.decided_at, NEW.id)
          ORDER BY p.decided_at DESC, p.id DESC LIMIT 1))
                       WHEN (SELECT q.opens FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) = 0 THEN (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1))
                       ELSE (SELECT lower(hex(randomblob(16)))) END
 WHERE id = NEW.id; UPDATE workbench_decisions
   SET press_id = CASE WHEN (SELECT COUNT(*) FROM workbench_decisions c WHERE c.press_id = (SELECT q.press_id FROM workbench_decisions q WHERE q.id = NEW.id))
         >= (SELECT COUNT(*) FROM workbench_decisions c WHERE c.press_id = (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1))) THEN (SELECT q.press_id FROM workbench_decisions q WHERE q.id = NEW.id) ELSE (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) END
 WHERE press_id = (SELECT CASE WHEN (SELECT q.press_id FROM workbench_decisions q WHERE q.id = NEW.id) IS NOT (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) AND (SELECT q.opens FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) = 0
                               THEN CASE WHEN (SELECT COUNT(*) FROM workbench_decisions c WHERE c.press_id = (SELECT q.press_id FROM workbench_decisions q WHERE q.id = NEW.id))
         >= (SELECT COUNT(*) FROM workbench_decisions c WHERE c.press_id = (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1))) THEN (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS NEW.fold_key AND n.id <> NEW.id
            AND (n.decided_at, n.id) > (NEW.decided_at, NEW.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) ELSE (SELECT q.press_id FROM workbench_decisions q WHERE q.id = NEW.id) END END); END;
CREATE TRIGGER workbench_press_goes AFTER DELETE ON workbench_decisions BEGIN 
UPDATE workbench_decisions
   SET opens = NOT EXISTS (
         SELECT 1 FROM workbench_decisions p
          WHERE p.fold_key IS workbench_decisions.fold_key
            AND p.decided_at >= workbench_decisions.decided_at - workbench_decisions.fold_gap
            AND (p.decided_at, p.id) < (workbench_decisions.decided_at, workbench_decisions.id)),
       closes = NOT EXISTS (
         SELECT 1 FROM workbench_decisions n
          WHERE n.fold_key IS workbench_decisions.fold_key
            AND n.decided_at <= workbench_decisions.decided_at + workbench_decisions.fold_gap
            AND (n.decided_at, n.id) > (workbench_decisions.decided_at, workbench_decisions.id)) WHERE id = (SELECT p.id FROM workbench_decisions p
          WHERE p.fold_key IS OLD.fold_key AND p.id <> OLD.id
            AND (p.decided_at, p.id) < (OLD.decided_at, OLD.id)
          ORDER BY p.decided_at DESC, p.id DESC LIMIT 1) OR id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS OLD.fold_key AND n.id <> OLD.id
            AND (n.decided_at, n.id) > (OLD.decided_at, OLD.id)
          ORDER BY n.decided_at, n.id LIMIT 1); UPDATE workbench_decisions SET press_id = (SELECT lower(hex(randomblob(16))))
 WHERE press_id = (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS OLD.fold_key AND n.id <> OLD.id
            AND (n.decided_at, n.id) > (OLD.decided_at, OLD.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) AND (decided_at, id) >= (SELECT q.decided_at, q.id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS OLD.fold_key AND n.id <> OLD.id
            AND (n.decided_at, n.id) > (OLD.decided_at, OLD.id)
          ORDER BY n.decided_at, n.id LIMIT 1))
   AND (SELECT q.opens FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS OLD.fold_key AND n.id <> OLD.id
            AND (n.decided_at, n.id) > (OLD.decided_at, OLD.id)
          ORDER BY n.decided_at, n.id LIMIT 1)) = 1 AND (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT p.id FROM workbench_decisions p
          WHERE p.fold_key IS OLD.fold_key AND p.id <> OLD.id
            AND (p.decided_at, p.id) < (OLD.decided_at, OLD.id)
          ORDER BY p.decided_at DESC, p.id DESC LIMIT 1)) = (SELECT q.press_id FROM workbench_decisions q WHERE q.id = (SELECT n.id FROM workbench_decisions n
          WHERE n.fold_key IS OLD.fold_key AND n.id <> OLD.id
            AND (n.decided_at, n.id) > (OLD.decided_at, OLD.id)
          ORDER BY n.decided_at, n.id LIMIT 1)); END;
CREATE INDEX ix_acl_subject ON acl_grants(subject_user_id);
CREATE INDEX ix_acl_object ON acl_grants(object_type, object_id);
CREATE UNIQUE INDEX ux_acl_global ON acl_grants(object_type, subject_user_id, effect) WHERE object_id IS NULL;
CREATE INDEX ix_folders_parent ON folders(parent_id);
CREATE INDEX ix_rus_hidden ON root_user_state(user_id, hidden) WHERE hidden = 1;
CREATE INDEX ix_fus_hidden ON folder_user_state(user_id, hidden) WHERE hidden = 1;
CREATE INDEX ix_assets_phash ON assets(phash);
CREATE INDEX ix_assets_added_id ON assets(added_at, id);
CREATE INDEX ix_assets_name ON assets(COALESCE(filename_sort, original_filename), id);
CREATE INDEX ix_assets_duration ON assets(duration_ms, id);
CREATE INDEX ix_assets_size ON assets(size_bytes, id);
CREATE INDEX ix_assets_legacy_identity ON assets(identity_version) WHERE identity_version = 0;
CREATE INDEX ix_assets_kept_local ON assets(id) WHERE keep_local = 1;
CREATE INDEX ix_assets_kept_from_swaps ON assets(id) WHERE keep_from_swaps = 1;
CREATE INDEX ix_derivatives_preview ON derivatives(asset_id, params) WHERE kind = 'preview';
CREATE INDEX ix_loc_asset ON asset_locations(asset_id);
CREATE INDEX ix_loc_folder ON asset_locations(folder_id);
CREATE INDEX ix_file_verdicts_product ON file_verdicts(product, transient);
CREATE INDEX ix_opinions_user ON opinions(user_id, at);
CREATE INDEX ix_opinions_subject ON opinions(subject_kind, subject_id, at);
CREATE INDEX ix_assets_unread ON assets(added_at, id) WHERE probed_at IS NULL;
CREATE INDEX ix_assets_classified ON assets(classified_version);
CREATE INDEX ix_assets_video_unhashed ON assets(id) WHERE media_type = 'video' AND oshash IS NULL;
CREATE INDEX ix_assets_print_version ON assets(fingerprint_version);
CREATE INDEX ix_backlog_moved_seq ON backlog_moved(seq);
CREATE TRIGGER backlog_assets_added AFTER INSERT ON assets BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_assets_removed AFTER DELETE ON assets BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_assets_moved AFTER UPDATE ON assets BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.id, (SELECT seq FROM backlog_clock WHERE id = 1)); UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_asset_locations_added AFTER INSERT ON asset_locations BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_asset_locations_removed AFTER DELETE ON asset_locations BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_asset_locations_moved AFTER UPDATE OF status, asset_id, root_id ON asset_locations WHEN OLD.status IS NOT NEW.status OR OLD.asset_id IS NOT NEW.asset_id OR OLD.root_id IS NOT NEW.root_id BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_derivatives_added AFTER INSERT ON derivatives BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_derivatives_removed AFTER DELETE ON derivatives BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_derivatives_moved AFTER UPDATE ON derivatives BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_file_verdicts_added AFTER INSERT ON file_verdicts BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_file_verdicts_removed AFTER DELETE ON file_verdicts BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_file_verdicts_moved AFTER UPDATE ON file_verdicts BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE INDEX ix_asset_links_asset ON asset_links(asset_id);
CREATE INDEX ix_asset_people_person ON asset_people(person_id);
CREATE INDEX ix_asset_people_source_decided ON asset_people(source, decided_at);
CREATE INDEX ix_asset_person_refusals_person ON asset_person_refusals(person_id);
CREATE INDEX ix_asset_tags_tag ON asset_tags(tag_id);
CREATE INDEX ix_asset_usernames_post ON asset_usernames(username_id, post_id, asset_id) WHERE post_id IS NOT NULL;
CREATE INDEX ix_asset_usernames_source ON asset_usernames(source, username_id, asset_id);
CREATE INDEX ix_asset_usernames_username ON asset_usernames(username_id);
CREATE INDEX ix_collection_items_asset ON collection_items(asset_id);
CREATE INDEX ix_collection_tags_tag ON collection_tags(tag_id);
CREATE INDEX ix_cus_favorite ON collection_user_state(user_id, favorite) WHERE favorite = 1;
CREATE INDEX ix_cus_hidden ON collection_user_state(user_id, hidden) WHERE hidden = 1;
CREATE INDEX ix_enrichment_runs_at ON enrichment_runs(subject, at DESC);
CREATE INDEX ix_enrichment_runs_subject ON enrichment_runs(subject, local_id, box_id, at DESC);
CREATE INDEX ix_loop_tags_tag ON loop_tags(tag_id);
CREATE INDEX ix_loops_asset ON loops(asset_id, start_ms);
CREATE INDEX ix_people_kept_local ON people(id) WHERE keep_local = 1;
CREATE INDEX ix_people_kept_from_swaps ON people(id) WHERE keep_from_swaps = 1;
CREATE INDEX ix_people_aliases_alias ON people_aliases(alias COLLATE NOCASE);
CREATE INDEX ix_people_aliases_person ON people_aliases(person_id);
CREATE INDEX ix_people_links_person ON people_links(person_id);
CREATE INDEX ix_people_links_site ON people_links(site_id);
CREATE INDEX ix_people_links_url ON people_links(url);
CREATE INDEX ix_person_tags_tag ON person_tags(tag_id);
CREATE INDEX ix_pus_favorite ON person_user_state(user_id, favorite) WHERE favorite = 1;
CREATE INDEX ix_pus_hidden ON person_user_state(user_id, hidden) WHERE hidden = 1;
CREATE INDEX ix_psi_asset ON photo_set_items(asset_id);
CREATE INDEX ix_psi_set ON photo_set_items(photo_set_id, position);
CREATE INDEX ix_pst_tag ON photo_set_tags(tag_id);
CREATE INDEX ix_psus_hidden ON photo_set_user_state(user_id, hidden) WHERE hidden = 1;
CREATE UNIQUE INDEX ix_photo_sets_archive ON photo_sets(archive_root_id, archive_rel_path) WHERE archive_rel_path IS NOT NULL;
CREATE UNIQUE INDEX ix_photo_sets_folder ON photo_sets(folder_id) WHERE folder_id IS NOT NULL;
CREATE INDEX ix_site_aliases_alias ON site_aliases(alias COLLATE NOCASE);
CREATE INDEX ix_site_aliases_site ON site_aliases(site_id);
CREATE INDEX ix_site_links_site ON site_links(site_id);
CREATE INDEX ix_site_tags_tag ON site_tags(tag_id);
CREATE INDEX ix_site_user_state_favorite ON site_user_state(user_id, favorite);
CREATE INDEX ix_site_user_state_hidden ON site_user_state(user_id, hidden);
CREATE INDEX ix_sites_kept_local ON sites(id) WHERE keep_local = 1;
CREATE INDEX ix_sites_kept_from_swaps ON sites(id) WHERE keep_from_swaps = 1;
CREATE INDEX ix_sites_parent ON sites(parent_id);
CREATE INDEX ix_tag_aliases_alias ON tag_aliases(alias COLLATE NOCASE);
CREATE INDEX ix_tag_aliases_tag ON tag_aliases(tag_id);
CREATE INDEX ix_tus_favorite ON tag_user_state(user_id, favorite) WHERE favorite = 1;
CREATE INDEX ix_tus_hidden ON tag_user_state(user_id, hidden) WHERE hidden = 1;
CREATE INDEX ix_tags_kept_local ON tags(id) WHERE keep_local = 1;
CREATE INDEX ix_tags_kept_from_swaps ON tags(id) WHERE keep_from_swaps = 1;
CREATE INDEX ix_tags_parent ON tags(parent_id);
CREATE INDEX ix_usernames_name ON usernames(name COLLATE NOCASE);
CREATE INDEX ix_usernames_person ON usernames(person_id);
CREATE INDEX ix_usernames_site ON usernames(site_id);
CREATE UNIQUE INDEX ux_usernames_number ON usernames(site_id, number) WHERE number IS NOT NULL;
CREATE UNIQUE INDEX ux_songs_recording ON songs(recording_id) WHERE recording_id IS NOT NULL;
CREATE INDEX ix_songs_name ON songs(name COLLATE NOCASE);
CREATE INDEX ix_song_files_song ON song_files(song_id, asset_id);
CREATE INDEX ix_song_user_state_favorite ON song_user_state(user_id, favorite) WHERE favorite = 1;
CREATE INDEX ix_song_user_state_hidden ON song_user_state(user_id, hidden) WHERE hidden = 1;
CREATE UNIQUE INDEX ux_artists_name ON artists(name COLLATE NOCASE);
CREATE INDEX ix_song_artists_artist ON song_artists(artist_id, song_id);
CREATE TRIGGER search_unindexed_asset_in AFTER INSERT ON assets
    WHEN NOT EXISTS (SELECT 1 FROM assets_fts_rows m WHERE m.asset_id = NEW.id)
    BEGIN UPDATE search_unindexed SET n = n + 1 WHERE id = 1; END;
CREATE TRIGGER search_unindexed_asset_out AFTER DELETE ON assets
    WHEN NOT EXISTS (SELECT 1 FROM assets_fts_rows m WHERE m.asset_id = OLD.id)
    BEGIN UPDATE search_unindexed SET n = n - 1 WHERE id = 1; END;
CREATE TRIGGER search_unindexed_row_in AFTER INSERT ON assets_fts_rows
    WHEN EXISTS (SELECT 1 FROM assets a WHERE a.id = NEW.asset_id)
    BEGIN UPDATE search_unindexed SET n = n - 1 WHERE id = 1; END;
CREATE TRIGGER search_unindexed_row_out AFTER DELETE ON assets_fts_rows
    WHEN EXISTS (SELECT 1 FROM assets a WHERE a.id = OLD.asset_id)
    BEGIN UPDATE search_unindexed SET n = n + 1 WHERE id = 1; END;
CREATE INDEX ix_asset_people_first ON asset_people(person_id, decided_at, asset_id);
CREATE INDEX ix_collection_items_first ON collection_items(collection_id, added_at, asset_id);
CREATE INDEX ix_psi_first ON photo_set_items(photo_set_id, added_at, position, asset_id);
CREATE TRIGGER song_music_filed AFTER INSERT ON song_files BEGIN UPDATE assets SET music = (SELECT s.name FROM songs s WHERE s.id = NEW.song_id) WHERE id = NEW.asset_id AND music IS NOT (SELECT s.name FROM songs s WHERE s.id = NEW.song_id); END;
CREATE TRIGGER song_music_moved AFTER UPDATE OF song_id ON song_files WHEN OLD.song_id IS NOT NEW.song_id BEGIN UPDATE assets SET music = (SELECT s.name FROM songs s WHERE s.id = NEW.song_id) WHERE id = NEW.asset_id AND music IS NOT (SELECT s.name FROM songs s WHERE s.id = NEW.song_id); END;
CREATE TRIGGER song_music_unfiled AFTER DELETE ON song_files BEGIN UPDATE assets SET music = NULL WHERE id = OLD.asset_id AND music IS NOT NULL AND NOT EXISTS (SELECT 1 FROM song_files f WHERE f.asset_id = OLD.asset_id); END;
CREATE TRIGGER song_music_renamed AFTER UPDATE OF name ON songs WHEN OLD.name IS NOT NEW.name BEGIN UPDATE assets SET music = NEW.name WHERE id IN (SELECT f.asset_id FROM song_files f WHERE f.song_id = NEW.id) AND music IS NOT NEW.name; END;
CREATE INDEX ix_folders_kept_local ON folders(id) WHERE keep_local = 1;
CREATE INDEX ix_folders_kept_from_swaps ON folders(id) WHERE keep_from_swaps = 1;
CREATE INDEX ix_dedup_status ON dedup_candidates(status, distance);
CREATE INDEX ix_dedup_asset_a ON dedup_candidates(asset_a);
CREATE INDEX ix_dedup_asset_b ON dedup_candidates(asset_b);
CREATE INDEX ix_jobs_claim_by_id ON jobs(state, priority, id, run_after);
CREATE INDEX ix_jobs_watchdog ON jobs(state, heartbeat_at);
CREATE INDEX ix_jobs_parent ON jobs(parent_id);
CREATE INDEX ix_jobs_state_by_id ON jobs(state, id);
CREATE INDEX ix_jobs_family ON jobs(root_id, state);
CREATE INDEX ix_jobs_family_by_id ON jobs(root_id, id);
CREATE INDEX ix_jobs_tops_by_id ON jobs(id) WHERE root_id = id;
CREATE INDEX ix_jobs_last_run ON jobs(type, updated_at, id) WHERE state IN ('done', 'canceled') AND started_at IS NOT NULL;
CREATE INDEX ix_jobs_by_type ON jobs(type, state, id);
CREATE INDEX ix_jobs_unpressed_tops ON jobs(type, state) WHERE root_id = id AND requested_by IS NULL;
CREATE TRIGGER jobs_tally_added AFTER INSERT ON jobs BEGIN
  INSERT INTO job_tallies (type, state, n) VALUES (NEW.type, NEW.state, 1)
  ON CONFLICT(type, state) DO UPDATE SET n = n + 1;
END;
CREATE TRIGGER jobs_tally_removed AFTER DELETE ON jobs BEGIN
  UPDATE job_tallies SET n = n - 1 WHERE type = OLD.type AND state = OLD.state;
END;
CREATE TRIGGER jobs_tally_moved AFTER UPDATE OF type, state ON jobs
 WHEN OLD.type IS NOT NEW.type OR OLD.state IS NOT NEW.state BEGIN
  UPDATE job_tallies SET n = n - 1 WHERE type = OLD.type AND state = OLD.state;
  INSERT INTO job_tallies (type, state, n) VALUES (NEW.type, NEW.state, 1)
  ON CONFLICT(type, state) DO UPDATE SET n = n + 1;
END;
CREATE INDEX ix_jobs_settled_by_created ON jobs(created_at, state, type) WHERE state IN ('done', 'failed');
CREATE INDEX ix_jobs_done_by_updated ON jobs(updated_at, type) WHERE state = 'done';
CREATE INDEX ix_downloads_urlhash ON downloads(url_hash);
CREATE INDEX ix_downloads_job ON downloads(job_id);
CREATE INDEX ix_downloads_asset ON downloads(asset_id) WHERE asset_id IS NOT NULL;
CREATE INDEX ix_site_connections_site ON site_connections(site_id);
CREATE INDEX ix_download_sites_site ON download_sites(site_id);
CREATE INDEX ix_site_art_username ON site_art(username_id);
CREATE INDEX ix_face_tracks_attributed ON face_tracks(attributed_at DESC, id DESC) WHERE person_id IS NOT NULL;
CREATE INDEX ix_face_tracks_created ON face_tracks(created_at);
CREATE INDEX ix_face_tracks_asset ON face_tracks(asset_id);
CREATE INDEX ix_face_tracks_person_recent ON face_tracks(person_id, attributed_at, id) WHERE person_id IS NOT NULL;
CREATE INDEX ix_face_tracks_pile ON face_tracks(pile_id) WHERE pile_id IS NOT NULL;
CREATE INDEX ix_face_detections_track ON face_detections(track_id);
CREATE INDEX ix_face_references_person ON face_references(person_id);
CREATE INDEX ix_face_references_track ON face_references(track_id);
CREATE INDEX ix_face_references_asset ON face_references(person_id, asset_id);
CREATE INDEX ix_face_references_pack ON face_references(pack_id) WHERE pack_id IS NOT NULL;
CREATE INDEX ix_face_piles_status ON face_piles(status);
CREATE UNIQUE INDEX ix_face_packs_library ON face_packs(library) WHERE library IS NOT NULL;
CREATE INDEX ix_face_asset_people_person ON face_asset_people(person_id);
CREATE INDEX ix_pack_entries_unclaimed ON pack_entries(name COLLATE NOCASE) WHERE claimed_person_id IS NULL;
CREATE INDEX ix_pack_entry_faces_entry ON pack_entry_faces(entry_id);
CREATE INDEX ix_face_removals_asset ON face_removals(asset_id);
CREATE INDEX ix_face_ignored_asset ON face_ignored(asset_id);
CREATE INDEX ix_face_confirmations_asset ON face_confirmations(asset_id);
CREATE INDEX ix_face_confirmations_person ON face_confirmations(person_id, created_at, asset_id);
CREATE INDEX ix_face_grouping_asset ON face_grouping(asset_id);
CREATE INDEX ix_face_rejections_person ON face_rejections(person_id, created_at, track_id);
CREATE INDEX ix_face_rejected_asset ON face_rejected(asset_id);
CREATE INDEX ix_face_pile_proposals_folder ON face_pile_proposals(folder_id, person_id);
CREATE INDEX ix_face_successors_successor ON face_successors(successor_id);
CREATE INDEX ix_face_successors_asset ON face_successors(asset_id);
CREATE TRIGGER backlog_face_scans_added AFTER INSERT ON face_scans BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_face_scans_removed AFTER DELETE ON face_scans BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_face_scans_moved AFTER UPDATE OF asset_id, coverage, quality_version, sampling_version, settings_digest, settings_shape, settings_density ON face_scans WHEN OLD.asset_id IS NOT NEW.asset_id OR OLD.coverage IS NOT NEW.coverage OR OLD.quality_version IS NOT NEW.quality_version OR OLD.sampling_version IS NOT NEW.sampling_version OR OLD.settings_digest IS NOT NEW.settings_digest OR OLD.settings_shape IS NOT NEW.settings_shape OR OLD.settings_density IS NOT NEW.settings_density BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE INDEX ix_file_moves_moved_at ON file_moves(moved_at);
CREATE INDEX ix_file_moves_asset ON file_moves(asset_id);
CREATE INDEX ix_aus_recent ON asset_user_state(user_id, last_viewed_at DESC) WHERE last_viewed_at IS NOT NULL;
CREATE INDEX ix_aus_favorite ON asset_user_state(user_id, favorite) WHERE favorite = 1;
CREATE INDEX ix_aus_hidden ON asset_user_state(user_id, hidden) WHERE hidden = 1;
CREATE INDEX ix_audio_pending_age ON audio_fingerprints_pending(computed_at);
CREATE INDEX ix_audio_keys_asset ON audio_fingerprint_keys(asset_id);
CREATE INDEX ix_music_pairs_b ON music_pairs(b_id);
CREATE TRIGGER music_waiting_file_changed AFTER UPDATE OF acodec, probed_at ON assets WHEN NEW.acodec IS NOT OLD.acodec OR NEW.probed_at IS NOT OLD.probed_at BEGIN DELETE FROM music_waiting WHERE asset_id = NEW.id AND NOT EXISTS (SELECT 1 FROM assets a WHERE a.id = NEW.id AND a.acodec IS NOT NULL AND a.probed_at IS NOT NULL AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM audio_fingerprints d WHERE d.asset_id = a.id)); INSERT INTO music_waiting (asset_id) SELECT a.id FROM assets a WHERE a.id = NEW.id AND a.acodec IS NOT NULL AND a.probed_at IS NOT NULL AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM audio_fingerprints d WHERE d.asset_id = a.id) AND NOT EXISTS (SELECT 1 FROM music_waiting w WHERE w.asset_id = a.id); END;
CREATE TRIGGER music_waiting_file_arrived AFTER INSERT ON assets WHEN NEW.acodec IS NOT NULL AND NEW.probed_at IS NOT NULL BEGIN INSERT INTO music_waiting (asset_id) SELECT a.id FROM assets a WHERE a.id = NEW.id AND a.acodec IS NOT NULL AND a.probed_at IS NOT NULL AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM audio_fingerprints d WHERE d.asset_id = a.id) AND NOT EXISTS (SELECT 1 FROM music_waiting w WHERE w.asset_id = a.id); END;
CREATE TRIGGER music_waiting_copy_arrived AFTER INSERT ON asset_locations BEGIN INSERT INTO music_waiting (asset_id) SELECT a.id FROM assets a WHERE a.id = NEW.asset_id AND a.acodec IS NOT NULL AND a.probed_at IS NOT NULL AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM audio_fingerprints d WHERE d.asset_id = a.id) AND NOT EXISTS (SELECT 1 FROM music_waiting w WHERE w.asset_id = a.id); END;
CREATE TRIGGER music_waiting_copy_changed AFTER UPDATE OF status, asset_id ON asset_locations WHEN NEW.status IS NOT OLD.status OR NEW.asset_id IS NOT OLD.asset_id BEGIN DELETE FROM music_waiting WHERE asset_id = OLD.asset_id AND NOT EXISTS (SELECT 1 FROM assets a WHERE a.id = OLD.asset_id AND a.acodec IS NOT NULL AND a.probed_at IS NOT NULL AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM audio_fingerprints d WHERE d.asset_id = a.id)); INSERT INTO music_waiting (asset_id) SELECT a.id FROM assets a WHERE a.id = OLD.asset_id AND a.acodec IS NOT NULL AND a.probed_at IS NOT NULL AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM audio_fingerprints d WHERE d.asset_id = a.id) AND NOT EXISTS (SELECT 1 FROM music_waiting w WHERE w.asset_id = a.id); DELETE FROM music_waiting WHERE asset_id = NEW.asset_id AND NOT EXISTS (SELECT 1 FROM assets a WHERE a.id = NEW.asset_id AND a.acodec IS NOT NULL AND a.probed_at IS NOT NULL AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM audio_fingerprints d WHERE d.asset_id = a.id)); INSERT INTO music_waiting (asset_id) SELECT a.id FROM assets a WHERE a.id = NEW.asset_id AND a.acodec IS NOT NULL AND a.probed_at IS NOT NULL AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM audio_fingerprints d WHERE d.asset_id = a.id) AND NOT EXISTS (SELECT 1 FROM music_waiting w WHERE w.asset_id = a.id); END;
CREATE TRIGGER music_waiting_copy_gone AFTER DELETE ON asset_locations BEGIN DELETE FROM music_waiting WHERE asset_id = OLD.asset_id AND NOT EXISTS (SELECT 1 FROM assets a WHERE a.id = OLD.asset_id AND a.acodec IS NOT NULL AND a.probed_at IS NOT NULL AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM audio_fingerprints d WHERE d.asset_id = a.id)); END;
CREATE TRIGGER music_waiting_done AFTER INSERT ON audio_fingerprints BEGIN DELETE FROM music_waiting WHERE asset_id = NEW.asset_id; END;
CREATE TRIGGER music_waiting_undone AFTER DELETE ON audio_fingerprints BEGIN INSERT INTO music_waiting (asset_id) SELECT a.id FROM assets a WHERE a.id = OLD.asset_id AND a.acodec IS NOT NULL AND a.probed_at IS NOT NULL AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM audio_fingerprints d WHERE d.asset_id = a.id) AND NOT EXISTS (SELECT 1 FROM music_waiting w WHERE w.asset_id = a.id); END;
CREATE TRIGGER music_waiting_done_moved AFTER UPDATE OF asset_id ON audio_fingerprints BEGIN DELETE FROM music_waiting WHERE asset_id = NEW.asset_id AND NOT EXISTS (SELECT 1 FROM assets a WHERE a.id = NEW.asset_id AND a.acodec IS NOT NULL AND a.probed_at IS NOT NULL AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM audio_fingerprints d WHERE d.asset_id = a.id)); INSERT INTO music_waiting (asset_id) SELECT a.id FROM assets a WHERE a.id = OLD.asset_id AND a.acodec IS NOT NULL AND a.probed_at IS NOT NULL AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM audio_fingerprints d WHERE d.asset_id = a.id) AND NOT EXISTS (SELECT 1 FROM music_waiting w WHERE w.asset_id = a.id); END;
CREATE TRIGGER backlog_audio_fingerprints_added AFTER INSERT ON audio_fingerprints BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_audio_fingerprints_removed AFTER DELETE ON audio_fingerprints BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_audio_fingerprints_moved AFTER UPDATE OF asset_id, algorithm, indexed_scheme ON audio_fingerprints WHEN OLD.asset_id IS NOT NEW.asset_id OR OLD.algorithm IS NOT NEW.algorithm OR OLD.indexed_scheme IS NOT NEW.indexed_scheme BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_music_waiting_added AFTER INSERT ON music_waiting BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_music_waiting_removed AFTER DELETE ON music_waiting BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_music_waiting_moved AFTER UPDATE ON music_waiting BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE INDEX ix_folder_ancestry_ancestor ON folder_ancestry(ancestor_id, folder_id);
CREATE INDEX ix_viewer_assets_concealed ON viewer_assets(user_id, asset_id) WHERE concealed = 1;
CREATE INDEX ix_viewer_pair_counts_b ON viewer_pair_counts(user_id, kind_b, id_b, kind_a, id_a, permitted, concealed);
CREATE INDEX ix_viewer_pair_counts_empty ON viewer_pair_counts(user_id) WHERE permitted <= 0;
CREATE INDEX ix_visibility_owed_now ON visibility_owed(asset_id) WHERE owed = 0;
CREATE VIEW visibility_step_user (user_id) AS SELECT NULL WHERE 0;
CREATE VIEW visibility_step_settle (user_id) AS SELECT NULL WHERE 0;
CREATE VIEW visibility_step_settled (user_id) AS SELECT NULL WHERE 0;
CREATE VIEW visibility_step_touch (user_id) AS SELECT NULL WHERE 0;
CREATE VIEW visibility_step_answers (user_id) AS SELECT NULL WHERE 0;
CREATE VIEW visibility_step_touch_face_tracks (user_id) AS SELECT NULL WHERE 0;
CREATE VIEW visibility_step_touch_loops (user_id) AS SELECT NULL WHERE 0;
CREATE VIEW visibility_step_touch_music_waiting (user_id) AS SELECT NULL WHERE 0;
CREATE VIEW visibility_step_rows (user_id) AS SELECT NULL WHERE 0;
CREATE VIEW visibility_step_owe (user_id) AS SELECT NULL WHERE 0;
CREATE VIEW visibility_step_fold (user_id) AS SELECT NULL WHERE 0;
CREATE VIEW visibility_step_fold_page (user_id) AS SELECT NULL WHERE 0;
CREATE VIEW visibility_step_going (user_id) AS SELECT NULL WHERE 0;
CREATE TRIGGER vis_folders_insert AFTER INSERT ON folders BEGIN
INSERT INTO folder_ancestry (folder_id, ancestor_id, depth) SELECT NEW.id, NEW.id, 0  WHERE NEW.parent_id IS NULL     OR EXISTS (SELECT 1 FROM folders p                  JOIN folder_ancestry pa ON pa.folder_id = p.id                                        AND pa.ancestor_id = p.id                 WHERE p.id = NEW.parent_id AND p.root_id = NEW.root_id);
INSERT INTO folder_ancestry (folder_id, ancestor_id, depth) SELECT NEW.id, pa.ancestor_id, pa.depth + 1   FROM folder_ancestry pa JOIN folders p ON p.id = pa.folder_id  WHERE p.id = NEW.parent_id AND p.root_id = NEW.root_id;
END;
CREATE TRIGGER vis_folders_delete_before BEFORE DELETE ON folders BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT u.id AS user_id, l.asset_id  FROM users u, folder_ancestry an  JOIN asset_locations l ON l.folder_id = an.folder_id WHERE an.ancestor_id = OLD.id);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_folders_move AFTER UPDATE OF parent_id, root_id ON folders BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT u.id AS user_id, l.asset_id  FROM users u, folder_ancestry an  JOIN asset_locations l ON l.folder_id = an.folder_id WHERE an.ancestor_id = NEW.id);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
DELETE FROM folder_ancestry WHERE folder_id IN (SELECT folder_id FROM folder_ancestry                      WHERE ancestor_id = NEW.id)   AND NOT (NEW.parent_id IS NULL            OR (EXISTS (SELECT 1 FROM folders p                          JOIN folder_ancestry pa ON pa.folder_id = p.id                                                AND pa.ancestor_id = p.id                         WHERE p.id = NEW.parent_id AND p.root_id = NEW.root_id)                AND NOT EXISTS (SELECT 1 FROM folder_ancestry s                                 WHERE s.ancestor_id = NEW.id                                   AND s.folder_id = NEW.parent_id)));
DELETE FROM folder_ancestry WHERE folder_id IN (SELECT folder_id FROM folder_ancestry                      WHERE ancestor_id = NEW.id)   AND ancestor_id NOT IN (SELECT folder_id FROM folder_ancestry                            WHERE ancestor_id = NEW.id);
INSERT INTO folder_ancestry (folder_id, ancestor_id, depth) SELECT s.folder_id, pa.ancestor_id, s.depth + 1 + pa.depth   FROM folder_ancestry s, folder_ancestry pa  WHERE s.ancestor_id = NEW.id    AND pa.folder_id = NEW.parent_id    AND EXISTS (SELECT 1 FROM folders p                 WHERE p.id = NEW.parent_id AND p.root_id = NEW.root_id);
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_folders_name_before BEFORE UPDATE OF name ON folders WHEN OLD.name IS NOT NEW.name AND NOT EXISTS (SELECT 1 FROM folders WHERE id = NEW.id AND NOT (id = OLD.id)) AND NOT EXISTS (SELECT 1 FROM folders WHERE root_id = NEW.root_id AND rel_path = NEW.rel_path AND NOT (root_id = OLD.root_id AND rel_path = OLD.rel_path)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT u.id AS user_id, l.asset_id FROM users u, asset_locations l WHERE l.folder_id = NEW.id);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_folders_name AFTER UPDATE OF name ON folders BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_assets_delete_before BEFORE DELETE ON assets BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
INSERT INTO visibility_step_going (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_assets_size_before BEFORE UPDATE OF size_bytes, duration_ms, media_type ON assets WHEN OLD.size_bytes IS NOT NEW.size_bytes OR OLD.duration_ms IS NOT NEW.duration_ms OR OLD.media_type IS NOT NEW.media_type BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, NEW.id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_assets_size AFTER UPDATE OF size_bytes, duration_ms, media_type ON assets BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_tags_insert_before BEFORE INSERT ON asset_tags WHEN NOT EXISTS (SELECT 1 FROM asset_tags WHERE asset_id = NEW.asset_id AND tag_id = NEW.tag_id) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_tags_insert AFTER INSERT ON asset_tags BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_tags_delete_before BEFORE DELETE ON asset_tags BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_tags_delete AFTER DELETE ON asset_tags BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_tags_update_before BEFORE UPDATE ON asset_tags WHEN NOT EXISTS (SELECT 1 FROM asset_tags WHERE asset_id = NEW.asset_id AND tag_id = NEW.tag_id AND NOT (asset_id = OLD.asset_id AND tag_id = OLD.tag_id)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u UNION ALL SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_tags_update AFTER UPDATE ON asset_tags BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_people_insert_before BEFORE INSERT ON asset_people WHEN NOT EXISTS (SELECT 1 FROM asset_people WHERE asset_id = NEW.asset_id AND person_id = NEW.person_id) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_people_insert AFTER INSERT ON asset_people BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_people_delete_before BEFORE DELETE ON asset_people BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_people_delete AFTER DELETE ON asset_people BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_people_update_before BEFORE UPDATE ON asset_people WHEN NOT EXISTS (SELECT 1 FROM asset_people WHERE asset_id = NEW.asset_id AND person_id = NEW.person_id AND NOT (asset_id = OLD.asset_id AND person_id = OLD.person_id)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u UNION ALL SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_people_update AFTER UPDATE ON asset_people BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_collection_items_insert_before BEFORE INSERT ON collection_items WHEN NOT EXISTS (SELECT 1 FROM collection_items WHERE collection_id = NEW.collection_id AND asset_id = NEW.asset_id) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_collection_items_insert AFTER INSERT ON collection_items BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_collection_items_delete_before BEFORE DELETE ON collection_items BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_collection_items_delete AFTER DELETE ON collection_items BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_collection_items_update_before BEFORE UPDATE ON collection_items WHEN NOT EXISTS (SELECT 1 FROM collection_items WHERE collection_id = NEW.collection_id AND asset_id = NEW.asset_id AND NOT (collection_id = OLD.collection_id AND asset_id = OLD.asset_id)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u UNION ALL SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_collection_items_update AFTER UPDATE ON collection_items BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_photo_set_items_insert_before BEFORE INSERT ON photo_set_items WHEN NOT EXISTS (SELECT 1 FROM photo_set_items WHERE photo_set_id = NEW.photo_set_id AND asset_id = NEW.asset_id) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_photo_set_items_insert AFTER INSERT ON photo_set_items BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_photo_set_items_delete_before BEFORE DELETE ON photo_set_items BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_photo_set_items_delete AFTER DELETE ON photo_set_items BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_photo_set_items_update_before BEFORE UPDATE ON photo_set_items WHEN NOT EXISTS (SELECT 1 FROM photo_set_items WHERE photo_set_id = NEW.photo_set_id AND asset_id = NEW.asset_id AND NOT (photo_set_id = OLD.photo_set_id AND asset_id = OLD.asset_id)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u UNION ALL SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_photo_set_items_update AFTER UPDATE ON photo_set_items BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_song_files_insert_before BEFORE INSERT ON song_files WHEN NOT EXISTS (SELECT 1 FROM song_files WHERE asset_id = NEW.asset_id) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_song_files_insert AFTER INSERT ON song_files BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_song_files_delete_before BEFORE DELETE ON song_files BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_song_files_delete AFTER DELETE ON song_files BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_song_files_update_before BEFORE UPDATE ON song_files WHEN NOT EXISTS (SELECT 1 FROM song_files WHERE asset_id = NEW.asset_id AND NOT (asset_id = OLD.asset_id)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u UNION ALL SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_song_files_update AFTER UPDATE ON song_files BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_usernames_insert_before BEFORE INSERT ON asset_usernames WHEN NOT EXISTS (SELECT 1 FROM asset_usernames WHERE asset_id = NEW.asset_id AND username_id = NEW.username_id) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_usernames_insert AFTER INSERT ON asset_usernames BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_usernames_delete_before BEFORE DELETE ON asset_usernames BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_usernames_delete AFTER DELETE ON asset_usernames BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_usernames_update_before BEFORE UPDATE ON asset_usernames WHEN NOT EXISTS (SELECT 1 FROM asset_usernames WHERE asset_id = NEW.asset_id AND username_id = NEW.username_id AND NOT (asset_id = OLD.asset_id AND username_id = OLD.username_id)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u UNION ALL SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_usernames_update AFTER UPDATE ON asset_usernames BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_loops_insert_before BEFORE INSERT ON loops WHEN NOT EXISTS (SELECT 1 FROM loops WHERE id = NEW.id) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch_loops (user_id) VALUES (NULL);
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_loops_insert AFTER INSERT ON loops BEGIN
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_loops_delete_before BEFORE DELETE ON loops BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch_loops (user_id) VALUES (NULL);
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_loops_delete AFTER DELETE ON loops BEGIN
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_loops_update_before BEFORE UPDATE OF id, asset_id ON loops WHEN NOT EXISTS (SELECT 1 FROM loops WHERE id = NEW.id AND NOT (id = OLD.id)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u UNION ALL SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch_loops (user_id) VALUES (NULL);
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_loops_update AFTER UPDATE OF id, asset_id ON loops BEGIN
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_asset_locations_insert_before BEFORE INSERT ON asset_locations WHEN NOT EXISTS (SELECT 1 FROM asset_locations WHERE id = NEW.id) AND NOT EXISTS (SELECT 1 FROM asset_locations WHERE root_id = NEW.root_id AND rel_path = NEW.rel_path) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_locations_insert AFTER INSERT ON asset_locations BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_locations_delete_before BEFORE DELETE ON asset_locations BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_locations_delete AFTER DELETE ON asset_locations BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_locations_update_before BEFORE UPDATE OF asset_id, root_id, folder_id, status ON asset_locations WHEN NOT EXISTS (SELECT 1 FROM asset_locations WHERE id = NEW.id AND NOT (id = OLD.id)) AND NOT EXISTS (SELECT 1 FROM asset_locations WHERE root_id = NEW.root_id AND rel_path = NEW.rel_path AND NOT (root_id = OLD.root_id AND rel_path = OLD.rel_path)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u UNION ALL SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_locations_update AFTER UPDATE OF asset_id, root_id, folder_id, status ON asset_locations BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_face_tracks_insert_before BEFORE INSERT ON face_tracks WHEN NOT EXISTS (SELECT 1 FROM face_tracks WHERE id = NEW.id) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch_face_tracks (user_id) VALUES (NULL);
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_face_tracks_insert AFTER INSERT ON face_tracks BEGIN
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_face_tracks_delete_before BEFORE DELETE ON face_tracks BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch_face_tracks (user_id) VALUES (NULL);
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_face_tracks_delete AFTER DELETE ON face_tracks BEGIN
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_face_tracks_update_before BEFORE UPDATE OF asset_id, person_id, pile_id, attribution ON face_tracks WHEN NOT EXISTS (SELECT 1 FROM face_tracks WHERE id = NEW.id AND NOT (id = OLD.id)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u UNION ALL SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch_face_tracks (user_id) VALUES (NULL);
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_face_tracks_update AFTER UPDATE OF asset_id, person_id, pile_id, attribution ON face_tracks BEGIN
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_music_waiting_insert_before BEFORE INSERT ON music_waiting WHEN NOT EXISTS (SELECT 1 FROM music_waiting WHERE asset_id = NEW.asset_id) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch_music_waiting (user_id) VALUES (NULL);
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_music_waiting_insert AFTER INSERT ON music_waiting BEGIN
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_music_waiting_delete_before BEFORE DELETE ON music_waiting BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch_music_waiting (user_id) VALUES (NULL);
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_music_waiting_delete AFTER DELETE ON music_waiting BEGIN
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_music_waiting_update_before BEFORE UPDATE ON music_waiting WHEN NOT EXISTS (SELECT 1 FROM music_waiting WHERE asset_id = NEW.asset_id AND NOT (asset_id = OLD.asset_id)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT u.id AS user_id, OLD.asset_id AS asset_id FROM users u UNION ALL SELECT u.id AS user_id, NEW.asset_id AS asset_id FROM users u);
INSERT INTO visibility_step_touch_music_waiting (user_id) VALUES (NULL);
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_music_waiting_update AFTER UPDATE ON music_waiting BEGIN
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_usernames_site_before BEFORE UPDATE OF site_id ON usernames WHEN NOT EXISTS (SELECT 1 FROM usernames WHERE id = NEW.id AND NOT (id = OLD.id)) AND NOT EXISTS (SELECT 1 FROM usernames WHERE site_id = NEW.site_id AND name = NEW.name AND NOT (site_id = OLD.site_id AND name = OLD.name)) AND NOT EXISTS (SELECT 1 FROM usernames WHERE site_id = NEW.site_id AND number = NEW.number AND NOT (site_id = OLD.site_id AND number = OLD.number)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT u.id AS user_id, aa.asset_id  FROM users u, asset_usernames aa WHERE aa.username_id = NEW.id);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_usernames_site AFTER UPDATE OF site_id ON usernames BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_usernames_delete_before BEFORE DELETE ON usernames BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT u.id AS user_id, aa.asset_id  FROM users u, asset_usernames aa WHERE aa.username_id = OLD.id);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_sites_parent_before BEFORE UPDATE OF parent_id ON sites WHEN NOT EXISTS (SELECT 1 FROM sites WHERE id = NEW.id AND NOT (id = OLD.id)) AND NOT EXISTS (SELECT 1 FROM sites WHERE name = NEW.name AND NOT (name = OLD.name)) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT u.id AS user_id, reached.asset_id  FROM users u, (SELECT aa.asset_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id WHERE reach.ancestor_id = NEW.id) reached);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_sites_parent AFTER UPDATE OF parent_id ON sites BEGIN
INSERT INTO visibility_step_rows (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_sites_delete_before BEFORE DELETE ON sites BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT u.id AS user_id, reached.asset_id  FROM users u, (SELECT aa.asset_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id WHERE reach.ancestor_id = OLD.id) reached);
INSERT INTO visibility_step_touch (user_id) VALUES (NULL);
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_acl_grants_insert_global AFTER INSERT ON acl_grants WHEN NEW.object_type = 'global' BEGIN
INSERT INTO visibility_step_user (user_id) VALUES (NEW.subject_user_id);
END;
CREATE TRIGGER vis_acl_grants_insert_root AFTER INSERT ON acl_grants WHEN NEW.object_type = 'root' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, l.asset_id FROM asset_locations l WHERE l.root_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_insert_folder AFTER INSERT ON acl_grants WHEN NEW.object_type = 'folder' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, l.asset_id  FROM folder_ancestry an JOIN asset_locations l ON l.folder_id = an.folder_id WHERE an.ancestor_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_insert_item AFTER INSERT ON acl_grants WHEN NEW.object_type = 'item' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT NEW.subject_user_id AS user_id, NEW.object_id AS asset_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_insert_tag AFTER INSERT ON acl_grants WHEN NEW.object_type = 'tag' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, asset_id FROM asset_tags WHERE tag_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_insert_person AFTER INSERT ON acl_grants WHEN NEW.object_type = 'person' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, asset_id FROM asset_people WHERE person_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_insert_collection AFTER INSERT ON acl_grants WHEN NEW.object_type = 'collection' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, asset_id FROM collection_items WHERE collection_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_insert_site AFTER INSERT ON acl_grants WHEN NEW.object_type = 'site' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, reached.asset_id  FROM (SELECT aa.asset_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id WHERE reach.ancestor_id = NEW.object_id) reached);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_insert_photo_set AFTER INSERT ON acl_grants WHEN NEW.object_type = 'photo_set' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, asset_id FROM photo_set_items WHERE photo_set_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_insert_song AFTER INSERT ON acl_grants WHEN NEW.object_type = 'song' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, asset_id FROM song_files WHERE song_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_delete_global AFTER DELETE ON acl_grants WHEN OLD.object_type = 'global' BEGIN
INSERT INTO visibility_step_user (user_id) VALUES (OLD.subject_user_id);
END;
CREATE TRIGGER vis_acl_grants_delete_root AFTER DELETE ON acl_grants WHEN OLD.object_type = 'root' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, l.asset_id FROM asset_locations l WHERE l.root_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_delete_folder AFTER DELETE ON acl_grants WHEN OLD.object_type = 'folder' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, l.asset_id  FROM folder_ancestry an JOIN asset_locations l ON l.folder_id = an.folder_id WHERE an.ancestor_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_delete_item AFTER DELETE ON acl_grants WHEN OLD.object_type = 'item' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT OLD.subject_user_id AS user_id, OLD.object_id AS asset_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_delete_tag AFTER DELETE ON acl_grants WHEN OLD.object_type = 'tag' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, asset_id FROM asset_tags WHERE tag_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_delete_person AFTER DELETE ON acl_grants WHEN OLD.object_type = 'person' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, asset_id FROM asset_people WHERE person_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_delete_collection AFTER DELETE ON acl_grants WHEN OLD.object_type = 'collection' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, asset_id FROM collection_items WHERE collection_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_delete_site AFTER DELETE ON acl_grants WHEN OLD.object_type = 'site' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, reached.asset_id  FROM (SELECT aa.asset_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id WHERE reach.ancestor_id = OLD.object_id) reached);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_delete_photo_set AFTER DELETE ON acl_grants WHEN OLD.object_type = 'photo_set' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, asset_id FROM photo_set_items WHERE photo_set_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_delete_song AFTER DELETE ON acl_grants WHEN OLD.object_type = 'song' BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, asset_id FROM song_files WHERE song_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_global AFTER UPDATE ON acl_grants WHEN NEW.object_type = 'global' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
INSERT INTO visibility_step_user (user_id) VALUES (NEW.subject_user_id);
END;
CREATE TRIGGER vis_acl_grants_update_root AFTER UPDATE ON acl_grants WHEN NEW.object_type = 'root' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, l.asset_id FROM asset_locations l WHERE l.root_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_folder AFTER UPDATE ON acl_grants WHEN NEW.object_type = 'folder' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, l.asset_id  FROM folder_ancestry an JOIN asset_locations l ON l.folder_id = an.folder_id WHERE an.ancestor_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_item AFTER UPDATE ON acl_grants WHEN NEW.object_type = 'item' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT NEW.subject_user_id AS user_id, NEW.object_id AS asset_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_tag AFTER UPDATE ON acl_grants WHEN NEW.object_type = 'tag' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, asset_id FROM asset_tags WHERE tag_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_person AFTER UPDATE ON acl_grants WHEN NEW.object_type = 'person' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, asset_id FROM asset_people WHERE person_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_collection AFTER UPDATE ON acl_grants WHEN NEW.object_type = 'collection' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, asset_id FROM collection_items WHERE collection_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_site AFTER UPDATE ON acl_grants WHEN NEW.object_type = 'site' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, reached.asset_id  FROM (SELECT aa.asset_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id WHERE reach.ancestor_id = NEW.object_id) reached);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_photo_set AFTER UPDATE ON acl_grants WHEN NEW.object_type = 'photo_set' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, asset_id FROM photo_set_items WHERE photo_set_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_song AFTER UPDATE ON acl_grants WHEN NEW.object_type = 'song' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.subject_user_id AS user_id, asset_id FROM song_files WHERE song_id = NEW.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_global_was AFTER UPDATE ON acl_grants WHEN OLD.object_type = 'global' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
INSERT INTO visibility_step_user (user_id) VALUES (OLD.subject_user_id);
END;
CREATE TRIGGER vis_acl_grants_update_root_was AFTER UPDATE ON acl_grants WHEN OLD.object_type = 'root' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, l.asset_id FROM asset_locations l WHERE l.root_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_folder_was AFTER UPDATE ON acl_grants WHEN OLD.object_type = 'folder' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, l.asset_id  FROM folder_ancestry an JOIN asset_locations l ON l.folder_id = an.folder_id WHERE an.ancestor_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_item_was AFTER UPDATE ON acl_grants WHEN OLD.object_type = 'item' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT OLD.subject_user_id AS user_id, OLD.object_id AS asset_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_tag_was AFTER UPDATE ON acl_grants WHEN OLD.object_type = 'tag' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, asset_id FROM asset_tags WHERE tag_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_person_was AFTER UPDATE ON acl_grants WHEN OLD.object_type = 'person' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, asset_id FROM asset_people WHERE person_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_collection_was AFTER UPDATE ON acl_grants WHEN OLD.object_type = 'collection' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, asset_id FROM collection_items WHERE collection_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_site_was AFTER UPDATE ON acl_grants WHEN OLD.object_type = 'site' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, reached.asset_id  FROM (SELECT aa.asset_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id WHERE reach.ancestor_id = OLD.object_id) reached);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_photo_set_was AFTER UPDATE ON acl_grants WHEN OLD.object_type = 'photo_set' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, asset_id FROM photo_set_items WHERE photo_set_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_acl_grants_update_song_was AFTER UPDATE ON acl_grants WHEN OLD.object_type = 'song' AND (OLD.object_type IS NOT NEW.object_type OR OLD.object_id IS NOT NEW.object_id OR OLD.subject_user_id IS NOT NEW.subject_user_id OR OLD.effect IS NOT NEW.effect) BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.subject_user_id AS user_id, asset_id FROM song_files WHERE song_id = OLD.object_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_owe (user_id) SELECT NULL WHERE (SELECT COUNT(*) FROM (SELECT 1 FROM visibility_pending LIMIT 1000)) >= 1000;
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_user_state_insert AFTER INSERT ON asset_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT NEW.user_id AS user_id, NEW.asset_id AS asset_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_user_state_delete AFTER DELETE ON asset_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT OLD.user_id AS user_id, OLD.asset_id AS asset_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_asset_user_state_update AFTER UPDATE OF hidden, user_id, asset_id ON asset_user_state WHEN OLD.hidden IS NOT NEW.hidden OR OLD.user_id IS NOT NEW.user_id OR OLD.asset_id IS NOT NEW.asset_id BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT OLD.user_id AS user_id, OLD.asset_id AS asset_id UNION ALL SELECT NEW.user_id AS user_id, NEW.asset_id AS asset_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_root_user_state_insert AFTER INSERT ON root_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.user_id AS user_id, l.asset_id FROM asset_locations l WHERE l.root_id = NEW.root_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_root_user_state_delete AFTER DELETE ON root_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, l.asset_id FROM asset_locations l WHERE l.root_id = OLD.root_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_root_user_state_update AFTER UPDATE OF hidden, user_id, root_id ON root_user_state WHEN OLD.hidden IS NOT NEW.hidden OR OLD.user_id IS NOT NEW.user_id OR OLD.root_id IS NOT NEW.root_id BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, l.asset_id FROM asset_locations l WHERE l.root_id = OLD.root_id UNION ALL SELECT DISTINCT NEW.user_id AS user_id, l.asset_id FROM asset_locations l WHERE l.root_id = NEW.root_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_folder_user_state_insert AFTER INSERT ON folder_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.user_id AS user_id, l.asset_id  FROM folder_ancestry an JOIN asset_locations l ON l.folder_id = an.folder_id WHERE an.ancestor_id = NEW.folder_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_folder_user_state_delete AFTER DELETE ON folder_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, l.asset_id  FROM folder_ancestry an JOIN asset_locations l ON l.folder_id = an.folder_id WHERE an.ancestor_id = OLD.folder_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_folder_user_state_update AFTER UPDATE OF hidden, user_id, folder_id ON folder_user_state WHEN OLD.hidden IS NOT NEW.hidden OR OLD.user_id IS NOT NEW.user_id OR OLD.folder_id IS NOT NEW.folder_id BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, l.asset_id  FROM folder_ancestry an JOIN asset_locations l ON l.folder_id = an.folder_id WHERE an.ancestor_id = OLD.folder_id UNION ALL SELECT DISTINCT NEW.user_id AS user_id, l.asset_id  FROM folder_ancestry an JOIN asset_locations l ON l.folder_id = an.folder_id WHERE an.ancestor_id = NEW.folder_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_tag_user_state_insert AFTER INSERT ON tag_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.user_id AS user_id, asset_id FROM asset_tags WHERE tag_id = NEW.tag_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_tag_user_state_delete AFTER DELETE ON tag_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, asset_id FROM asset_tags WHERE tag_id = OLD.tag_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_tag_user_state_update AFTER UPDATE OF hidden, user_id, tag_id ON tag_user_state WHEN OLD.hidden IS NOT NEW.hidden OR OLD.user_id IS NOT NEW.user_id OR OLD.tag_id IS NOT NEW.tag_id BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, asset_id FROM asset_tags WHERE tag_id = OLD.tag_id UNION ALL SELECT DISTINCT NEW.user_id AS user_id, asset_id FROM asset_tags WHERE tag_id = NEW.tag_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_person_user_state_insert AFTER INSERT ON person_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.user_id AS user_id, asset_id FROM asset_people WHERE person_id = NEW.person_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_person_user_state_delete AFTER DELETE ON person_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, asset_id FROM asset_people WHERE person_id = OLD.person_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_person_user_state_update AFTER UPDATE OF hidden, user_id, person_id ON person_user_state WHEN OLD.hidden IS NOT NEW.hidden OR OLD.user_id IS NOT NEW.user_id OR OLD.person_id IS NOT NEW.person_id BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, asset_id FROM asset_people WHERE person_id = OLD.person_id UNION ALL SELECT DISTINCT NEW.user_id AS user_id, asset_id FROM asset_people WHERE person_id = NEW.person_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_collection_user_state_insert AFTER INSERT ON collection_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.user_id AS user_id, asset_id FROM collection_items WHERE collection_id = NEW.collection_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_collection_user_state_delete AFTER DELETE ON collection_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, asset_id FROM collection_items WHERE collection_id = OLD.collection_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_collection_user_state_update AFTER UPDATE OF hidden, user_id, collection_id ON collection_user_state WHEN OLD.hidden IS NOT NEW.hidden OR OLD.user_id IS NOT NEW.user_id OR OLD.collection_id IS NOT NEW.collection_id BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, asset_id FROM collection_items WHERE collection_id = OLD.collection_id UNION ALL SELECT DISTINCT NEW.user_id AS user_id, asset_id FROM collection_items WHERE collection_id = NEW.collection_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_site_user_state_insert AFTER INSERT ON site_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.user_id AS user_id, reached.asset_id  FROM (SELECT aa.asset_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id WHERE reach.ancestor_id = NEW.site_id) reached);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_site_user_state_delete AFTER DELETE ON site_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, reached.asset_id  FROM (SELECT aa.asset_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id WHERE reach.ancestor_id = OLD.site_id) reached);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_site_user_state_update AFTER UPDATE OF hidden, user_id, site_id ON site_user_state WHEN OLD.hidden IS NOT NEW.hidden OR OLD.user_id IS NOT NEW.user_id OR OLD.site_id IS NOT NEW.site_id BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, reached.asset_id  FROM (SELECT aa.asset_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id WHERE reach.ancestor_id = OLD.site_id) reached UNION ALL SELECT DISTINCT NEW.user_id AS user_id, reached.asset_id  FROM (SELECT aa.asset_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id WHERE reach.ancestor_id = NEW.site_id) reached);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_photo_set_user_state_insert AFTER INSERT ON photo_set_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.user_id AS user_id, asset_id FROM photo_set_items WHERE photo_set_id = NEW.photo_set_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_photo_set_user_state_delete AFTER DELETE ON photo_set_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, asset_id FROM photo_set_items WHERE photo_set_id = OLD.photo_set_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_photo_set_user_state_update AFTER UPDATE OF hidden, user_id, photo_set_id ON photo_set_user_state WHEN OLD.hidden IS NOT NEW.hidden OR OLD.user_id IS NOT NEW.user_id OR OLD.photo_set_id IS NOT NEW.photo_set_id BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, asset_id FROM photo_set_items WHERE photo_set_id = OLD.photo_set_id UNION ALL SELECT DISTINCT NEW.user_id AS user_id, asset_id FROM photo_set_items WHERE photo_set_id = NEW.photo_set_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_song_user_state_insert AFTER INSERT ON song_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT NEW.user_id AS user_id, asset_id FROM song_files WHERE song_id = NEW.song_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_song_user_state_delete AFTER DELETE ON song_user_state BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, asset_id FROM song_files WHERE song_id = OLD.song_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_song_user_state_update AFTER UPDATE OF hidden, user_id, song_id ON song_user_state WHEN OLD.hidden IS NOT NEW.hidden OR OLD.user_id IS NOT NEW.user_id OR OLD.song_id IS NOT NEW.song_id BEGIN
DELETE FROM visibility_pending;
INSERT INTO visibility_pending (user_id, asset_id) SELECT DISTINCT user_id, asset_id FROM (SELECT DISTINCT OLD.user_id AS user_id, asset_id FROM song_files WHERE song_id = OLD.song_id UNION ALL SELECT DISTINCT NEW.user_id AS user_id, asset_id FROM song_files WHERE song_id = NEW.song_id);
INSERT INTO visibility_step_settle (user_id) VALUES (NULL);
INSERT INTO visibility_step_answers (user_id) VALUES (NULL);
INSERT INTO visibility_step_settled (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_users_insert AFTER INSERT ON users BEGIN
INSERT INTO visibility_step_user (user_id) VALUES (NEW.id);
END;
CREATE TRIGGER vis_users_role AFTER UPDATE OF role ON users BEGIN
INSERT INTO visibility_step_user (user_id) VALUES (NEW.id);
END;
CREATE TRIGGER vis_pair_counts_insert AFTER INSERT ON viewer_pair_counts WHEN (NEW.permitted > 0) != 0 OR (NEW.permitted - NEW.concealed > 0) != 0 BEGIN
INSERT INTO viewer_partner_counts (user_id, kind, object_id, partner_kind) SELECT NEW.user_id, NEW.kind_a, NEW.id_a, NEW.kind_b WHERE ((NEW.permitted > 0) > 0 OR (NEW.permitted - NEW.concealed > 0) > 0) AND NOT EXISTS (SELECT 1 FROM viewer_partner_counts WHERE user_id = NEW.user_id AND kind = NEW.kind_a   AND object_id = NEW.id_a AND partner_kind = NEW.kind_b);
UPDATE viewer_partner_counts SET permitted = permitted + (NEW.permitted > 0), shown = shown + (NEW.permitted - NEW.concealed > 0) WHERE user_id = NEW.user_id AND kind = NEW.kind_a   AND object_id = NEW.id_a AND partner_kind = NEW.kind_b;
DELETE FROM viewer_partner_counts WHERE user_id = NEW.user_id AND kind = NEW.kind_a   AND object_id = NEW.id_a AND partner_kind = NEW.kind_b   AND permitted <= 0;
INSERT INTO viewer_partner_counts (user_id, kind, object_id, partner_kind) SELECT NEW.user_id, NEW.kind_b, NEW.id_b, NEW.kind_a WHERE ((NEW.permitted > 0) > 0 OR (NEW.permitted - NEW.concealed > 0) > 0) AND NOT EXISTS (SELECT 1 FROM viewer_partner_counts WHERE user_id = NEW.user_id AND kind = NEW.kind_b   AND object_id = NEW.id_b AND partner_kind = NEW.kind_a);
UPDATE viewer_partner_counts SET permitted = permitted + (NEW.permitted > 0), shown = shown + (NEW.permitted - NEW.concealed > 0) WHERE user_id = NEW.user_id AND kind = NEW.kind_b   AND object_id = NEW.id_b AND partner_kind = NEW.kind_a;
DELETE FROM viewer_partner_counts WHERE user_id = NEW.user_id AND kind = NEW.kind_b   AND object_id = NEW.id_b AND partner_kind = NEW.kind_a   AND permitted <= 0;
END;
CREATE TRIGGER vis_pair_counts_delete AFTER DELETE ON viewer_pair_counts WHEN -(OLD.permitted > 0) != 0 OR -(OLD.permitted - OLD.concealed > 0) != 0 BEGIN
INSERT INTO viewer_partner_counts (user_id, kind, object_id, partner_kind) SELECT OLD.user_id, OLD.kind_a, OLD.id_a, OLD.kind_b WHERE (-(OLD.permitted > 0) > 0 OR -(OLD.permitted - OLD.concealed > 0) > 0) AND NOT EXISTS (SELECT 1 FROM viewer_partner_counts WHERE user_id = OLD.user_id AND kind = OLD.kind_a   AND object_id = OLD.id_a AND partner_kind = OLD.kind_b);
UPDATE viewer_partner_counts SET permitted = permitted + -(OLD.permitted > 0), shown = shown + -(OLD.permitted - OLD.concealed > 0) WHERE user_id = OLD.user_id AND kind = OLD.kind_a   AND object_id = OLD.id_a AND partner_kind = OLD.kind_b;
DELETE FROM viewer_partner_counts WHERE user_id = OLD.user_id AND kind = OLD.kind_a   AND object_id = OLD.id_a AND partner_kind = OLD.kind_b   AND permitted <= 0;
INSERT INTO viewer_partner_counts (user_id, kind, object_id, partner_kind) SELECT OLD.user_id, OLD.kind_b, OLD.id_b, OLD.kind_a WHERE (-(OLD.permitted > 0) > 0 OR -(OLD.permitted - OLD.concealed > 0) > 0) AND NOT EXISTS (SELECT 1 FROM viewer_partner_counts WHERE user_id = OLD.user_id AND kind = OLD.kind_b   AND object_id = OLD.id_b AND partner_kind = OLD.kind_a);
UPDATE viewer_partner_counts SET permitted = permitted + -(OLD.permitted > 0), shown = shown + -(OLD.permitted - OLD.concealed > 0) WHERE user_id = OLD.user_id AND kind = OLD.kind_b   AND object_id = OLD.id_b AND partner_kind = OLD.kind_a;
DELETE FROM viewer_partner_counts WHERE user_id = OLD.user_id AND kind = OLD.kind_b   AND object_id = OLD.id_b AND partner_kind = OLD.kind_a   AND permitted <= 0;
END;
CREATE TRIGGER vis_pair_counts_update AFTER UPDATE OF permitted, concealed ON viewer_pair_counts WHEN ((NEW.permitted > 0) - (OLD.permitted > 0)) != 0 OR ((NEW.permitted - NEW.concealed > 0) - (OLD.permitted - OLD.concealed > 0)) != 0 BEGIN
INSERT INTO viewer_partner_counts (user_id, kind, object_id, partner_kind) SELECT NEW.user_id, NEW.kind_a, NEW.id_a, NEW.kind_b WHERE (((NEW.permitted > 0) - (OLD.permitted > 0)) > 0 OR ((NEW.permitted - NEW.concealed > 0) - (OLD.permitted - OLD.concealed > 0)) > 0) AND NOT EXISTS (SELECT 1 FROM viewer_partner_counts WHERE user_id = NEW.user_id AND kind = NEW.kind_a   AND object_id = NEW.id_a AND partner_kind = NEW.kind_b);
UPDATE viewer_partner_counts SET permitted = permitted + ((NEW.permitted > 0) - (OLD.permitted > 0)), shown = shown + ((NEW.permitted - NEW.concealed > 0) - (OLD.permitted - OLD.concealed > 0)) WHERE user_id = NEW.user_id AND kind = NEW.kind_a   AND object_id = NEW.id_a AND partner_kind = NEW.kind_b;
DELETE FROM viewer_partner_counts WHERE user_id = NEW.user_id AND kind = NEW.kind_a   AND object_id = NEW.id_a AND partner_kind = NEW.kind_b   AND permitted <= 0;
INSERT INTO viewer_partner_counts (user_id, kind, object_id, partner_kind) SELECT NEW.user_id, NEW.kind_b, NEW.id_b, NEW.kind_a WHERE (((NEW.permitted > 0) - (OLD.permitted > 0)) > 0 OR ((NEW.permitted - NEW.concealed > 0) - (OLD.permitted - OLD.concealed > 0)) > 0) AND NOT EXISTS (SELECT 1 FROM viewer_partner_counts WHERE user_id = NEW.user_id AND kind = NEW.kind_b   AND object_id = NEW.id_b AND partner_kind = NEW.kind_a);
UPDATE viewer_partner_counts SET permitted = permitted + ((NEW.permitted > 0) - (OLD.permitted > 0)), shown = shown + ((NEW.permitted - NEW.concealed > 0) - (OLD.permitted - OLD.concealed > 0)) WHERE user_id = NEW.user_id AND kind = NEW.kind_b   AND object_id = NEW.id_b AND partner_kind = NEW.kind_a;
DELETE FROM viewer_partner_counts WHERE user_id = NEW.user_id AND kind = NEW.kind_b   AND object_id = NEW.id_b AND partner_kind = NEW.kind_a   AND permitted <= 0;
END;
CREATE TRIGGER vis_viewer_entity_counts_emptied AFTER UPDATE OF permitted ON viewer_entity_counts WHEN NEW.permitted <= 0 BEGIN
DELETE FROM viewer_entity_counts WHERE user_id = NEW.user_id AND kind = NEW.kind AND object_id = NEW.object_id;
END;
CREATE TRIGGER vis_viewer_pair_counts_emptied AFTER UPDATE OF permitted ON viewer_pair_counts WHEN NEW.permitted <= 0 BEGIN
DELETE FROM viewer_pair_counts WHERE user_id = NEW.user_id AND kind_a = NEW.kind_a AND id_a = NEW.id_a AND kind_b = NEW.kind_b AND id_b = NEW.id_b;
END;
CREATE TRIGGER vis_wall_totals_insert AFTER INSERT ON viewer_entity_counts WHEN (NEW.permitted > 0) != 0 OR (NEW.permitted - NEW.concealed > 0) != 0 BEGIN
INSERT INTO viewer_wall_totals (user_id, kind) SELECT NEW.user_id, NEW.kind WHERE ((NEW.permitted > 0) > 0 OR (NEW.permitted - NEW.concealed > 0) > 0) AND NOT EXISTS (SELECT 1 FROM viewer_wall_totals WHERE user_id = NEW.user_id AND kind = NEW.kind);
UPDATE viewer_wall_totals SET permitted = permitted + (NEW.permitted > 0), shown = shown + (NEW.permitted - NEW.concealed > 0) WHERE user_id = NEW.user_id AND kind = NEW.kind;
DELETE FROM viewer_wall_totals WHERE user_id = NEW.user_id AND kind = NEW.kind AND permitted <= 0;
END;
CREATE TRIGGER vis_wall_totals_delete AFTER DELETE ON viewer_entity_counts WHEN -(OLD.permitted > 0) != 0 OR -(OLD.permitted - OLD.concealed > 0) != 0 BEGIN
INSERT INTO viewer_wall_totals (user_id, kind) SELECT OLD.user_id, OLD.kind WHERE (-(OLD.permitted > 0) > 0 OR -(OLD.permitted - OLD.concealed > 0) > 0) AND NOT EXISTS (SELECT 1 FROM viewer_wall_totals WHERE user_id = OLD.user_id AND kind = OLD.kind);
UPDATE viewer_wall_totals SET permitted = permitted + -(OLD.permitted > 0), shown = shown + -(OLD.permitted - OLD.concealed > 0) WHERE user_id = OLD.user_id AND kind = OLD.kind;
DELETE FROM viewer_wall_totals WHERE user_id = OLD.user_id AND kind = OLD.kind AND permitted <= 0;
END;
CREATE TRIGGER vis_wall_totals_update AFTER UPDATE OF permitted, concealed ON viewer_entity_counts WHEN ((NEW.permitted > 0) - (OLD.permitted > 0)) != 0 OR ((NEW.permitted - NEW.concealed > 0) - (OLD.permitted - OLD.concealed > 0)) != 0 BEGIN
INSERT INTO viewer_wall_totals (user_id, kind) SELECT NEW.user_id, NEW.kind WHERE (((NEW.permitted > 0) - (OLD.permitted > 0)) > 0 OR ((NEW.permitted - NEW.concealed > 0) - (OLD.permitted - OLD.concealed > 0)) > 0) AND NOT EXISTS (SELECT 1 FROM viewer_wall_totals WHERE user_id = NEW.user_id AND kind = NEW.kind);
UPDATE viewer_wall_totals SET permitted = permitted + ((NEW.permitted > 0) - (OLD.permitted > 0)), shown = shown + ((NEW.permitted - NEW.concealed > 0) - (OLD.permitted - OLD.concealed > 0)) WHERE user_id = NEW.user_id AND kind = NEW.kind;
DELETE FROM viewer_wall_totals WHERE user_id = NEW.user_id AND kind = NEW.kind AND permitted <= 0;
END;
CREATE TRIGGER vis_recompute_user INSTEAD OF INSERT ON visibility_step_user BEGIN
INSERT INTO visibility_step_fold (user_id) VALUES (NULL);
DELETE FROM viewer_stats WHERE user_id = NEW.user_id;
DELETE FROM viewer_entity_counts WHERE user_id = NEW.user_id;
DELETE FROM viewer_pair_counts WHERE user_id = NEW.user_id;
DELETE FROM viewer_assets WHERE user_id = NEW.user_id;
DELETE FROM visibility_places;

INSERT INTO visibility_places (user_id, root_id, place, restricted, shared, vaulted)
SELECT l.user_id, l.root_id, COALESCE(l.folder_id, ''),
       CASE WHEN r.id IS NULL THEN 1 ELSE CASE WHEN l.folder_id IS NULL THEN CASE WHEN 
(EXISTS (SELECT 1 FROM acl_grants g
          WHERE g.subject_user_id = p.user_id AND g.object_type = 'root' AND g.object_id = l.root_id
            AND g.effect = 'restrict')
 OR EXISTS (SELECT 1 FROM acl_grants g
             WHERE g.subject_user_id = p.user_id AND g.object_type = 'global'
               AND g.object_id IS NULL AND g.effect = 'restrict')) THEN 1 ELSE 0 END
     WHEN fa.folder_id IS NULL THEN 1
     WHEN 
EXISTS (SELECT 1 FROM folder_ancestry an
         JOIN acl_grants g ON g.object_type = 'folder' AND g.object_id = an.ancestor_id
                          AND g.subject_user_id = p.user_id AND g.effect = 'restrict'
        WHERE an.folder_id = l.folder_id) OR 
(EXISTS (SELECT 1 FROM acl_grants g
          WHERE g.subject_user_id = p.user_id AND g.object_type = 'root' AND g.object_id = l.root_id
            AND g.effect = 'restrict')
 OR EXISTS (SELECT 1 FROM acl_grants g
             WHERE g.subject_user_id = p.user_id AND g.object_type = 'global'
               AND g.object_id IS NULL AND g.effect = 'restrict')) THEN 1
     ELSE 0 END END,
       CASE WHEN r.id IS NULL THEN 0 ELSE CASE WHEN l.folder_id IS NULL THEN 
COALESCE((SELECT MAX(g.effect = 'share') FROM acl_grants g
           WHERE g.subject_user_id = p.user_id AND g.object_type = 'root' AND g.object_id = l.root_id),
         (SELECT MAX(g.effect = 'share') FROM acl_grants g
           WHERE g.subject_user_id = p.user_id AND g.object_type = 'global' AND g.object_id IS NULL),
         0)
     WHEN fa.folder_id IS NULL THEN 0
     ELSE COALESCE(
(SELECT MAX(g.effect = 'share')
   FROM folder_ancestry an
   JOIN acl_grants g ON g.object_type = 'folder' AND g.object_id = an.ancestor_id
                    AND g.subject_user_id = p.user_id
  WHERE an.folder_id = l.folder_id
  GROUP BY an.depth ORDER BY an.depth LIMIT 1), 
COALESCE((SELECT MAX(g.effect = 'share') FROM acl_grants g
           WHERE g.subject_user_id = p.user_id AND g.object_type = 'root' AND g.object_id = l.root_id),
         (SELECT MAX(g.effect = 'share') FROM acl_grants g
           WHERE g.subject_user_id = p.user_id AND g.object_type = 'global' AND g.object_id IS NULL),
         0)) END END,
       CASE WHEN r.id IS NULL THEN 1 ELSE CASE WHEN l.folder_id IS NULL THEN CASE WHEN 
EXISTS (SELECT 1 FROM root_user_state h
         WHERE h.root_id = l.root_id AND h.user_id = p.user_id AND h.hidden = 1) THEN 1 ELSE 0 END
     WHEN fa.folder_id IS NULL THEN 1
     ELSE CASE WHEN 
EXISTS (SELECT 1 FROM root_user_state h
         WHERE h.root_id = l.root_id AND h.user_id = p.user_id AND h.hidden = 1) OR 
EXISTS (SELECT 1 FROM folder_ancestry an
         JOIN folder_user_state h ON h.folder_id = an.ancestor_id
                                 AND h.user_id = p.user_id AND h.hidden = 1
        WHERE an.folder_id = l.folder_id) THEN 1 ELSE 0 END END END
  FROM (SELECT NEW.user_id AS user_id, x.root_id, x.folder_id FROM (SELECT DISTINCT root_id, folder_id FROM asset_locations) x) l
  JOIN (SELECT id AS user_id FROM users) p ON p.user_id = l.user_id
  LEFT JOIN library_roots r ON r.id = l.root_id
  LEFT JOIN folder_ancestry fa ON fa.folder_id = l.folder_id AND fa.ancestor_id = l.folder_id;
INSERT INTO viewer_assets (user_id, asset_id, concealed)
SELECT x.user_id, x.asset_id,
       CASE WHEN x.hidden = 1 OR (x.ph & 1) = 1 OR x.lv = 1 THEN 1 ELSE 0 END AS concealed
  FROM (SELECT p.user_id, p.asset_id, u.role,
               COALESCE(
(SELECT MAX(pl.restricted) * 4
      + MAX(CASE WHEN pl.restricted = 0 AND pl.shared = 1 THEN 1 ELSE 0 END) * 2
      + MAX(pl.vaulted)
   FROM asset_locations l
   JOIN visibility_places pl ON pl.user_id = p.user_id AND pl.root_id = l.root_id
                            AND pl.place = COALESCE(l.folder_id, '')
  WHERE l.asset_id = p.asset_id), 0) AS ph,
               COALESCE(
(SELECT MAX(g.effect = 'restrict') * 2 + MAX(g.effect = 'share')
   FROM (SELECT 'tag' AS kind, tag_id AS object FROM asset_tags WHERE asset_id = p.asset_id
         UNION ALL
         SELECT 'person', person_id FROM asset_people WHERE asset_id = p.asset_id
         UNION ALL
         SELECT 'collection', collection_id FROM collection_items WHERE asset_id = p.asset_id
         UNION ALL
         SELECT 'site', up.site_id FROM (WITH RECURSIVE up(site_id) AS (SELECT s0.id FROM asset_usernames aa
  JOIN usernames ac ON ac.id = aa.username_id JOIN sites s0 ON s0.id = ac.site_id
  WHERE aa.asset_id = p.asset_id
  UNION SELECT s.parent_id FROM up JOIN sites s ON s.id = up.site_id WHERE s.parent_id IS NOT NULL)
SELECT site_id FROM up) up
         UNION ALL
         SELECT 'photo_set', photo_set_id FROM photo_set_items WHERE asset_id = p.asset_id
         UNION ALL
         SELECT 'song', song_id FROM song_files WHERE asset_id = p.asset_id) m
   JOIN acl_grants g ON g.subject_user_id = p.user_id
                    AND g.object_type = m.kind AND g.object_id = m.object), 0) AS lo,
               COALESCE(
(SELECT MAX(g.effect = 'restrict') * 2 + MAX(g.effect = 'share')
   FROM acl_grants g
  WHERE g.subject_user_id = p.user_id AND g.object_type = 'item' AND g.object_id = p.asset_id), 0) AS it,
               CASE WHEN 
EXISTS (SELECT 1 FROM asset_user_state h
         WHERE h.asset_id = p.asset_id AND h.user_id = p.user_id AND h.hidden = 1) THEN 1 ELSE 0 END AS hidden,
               CASE WHEN 
EXISTS (SELECT 1 FROM asset_people ap
         JOIN person_user_state hp ON hp.person_id = ap.person_id
        WHERE ap.asset_id = p.asset_id AND hp.user_id = p.user_id AND hp.hidden = 1)
OR EXISTS (SELECT 1 FROM collection_items ci
            JOIN collection_user_state hc ON hc.collection_id = ci.collection_id
           WHERE ci.asset_id = p.asset_id AND hc.user_id = p.user_id AND hc.hidden = 1)
OR EXISTS (SELECT 1 FROM asset_tags vt
            JOIN tag_user_state ht ON ht.tag_id = vt.tag_id
           WHERE vt.asset_id = p.asset_id AND ht.user_id = p.user_id AND ht.hidden = 1)
OR (EXISTS (SELECT 1 FROM site_user_state hz WHERE hz.user_id = p.user_id AND hz.hidden = 1)
    AND EXISTS (SELECT 1 FROM (WITH RECURSIVE up(site_id) AS (SELECT s0.id FROM asset_usernames aa
  JOIN usernames ac ON ac.id = aa.username_id JOIN sites s0 ON s0.id = ac.site_id
  WHERE aa.asset_id = p.asset_id
  UNION SELECT s.parent_id FROM up JOIN sites s ON s.id = up.site_id WHERE s.parent_id IS NOT NULL)
SELECT site_id FROM up) up JOIN site_user_state hl ON hl.site_id = up.site_id
                 WHERE hl.user_id = p.user_id AND hl.hidden = 1))
OR EXISTS (SELECT 1 FROM photo_set_items vp
            JOIN photo_set_user_state hs ON hs.photo_set_id = vp.photo_set_id
           WHERE vp.asset_id = p.asset_id AND hs.user_id = p.user_id AND hs.hidden = 1)
OR EXISTS (SELECT 1 FROM song_files vs
            JOIN song_user_state hg ON hg.song_id = vs.song_id
           WHERE vs.asset_id = p.asset_id AND hg.user_id = p.user_id AND hg.hidden = 1) THEN 1 ELSE 0 END AS lv
          FROM (SELECT NEW.user_id AS user_id, a.id AS asset_id FROM assets a) p
          JOIN users u ON u.id = p.user_id
         WHERE EXISTS (SELECT 1 FROM asset_locations al WHERE al.asset_id = p.asset_id)
         LIMIT -1) x
 WHERE x.role = 'admin'
    OR CASE WHEN (x.lo & 2) = 2 THEN 0
            WHEN (x.it & 2) = 2 THEN 0
            WHEN (x.ph & 4) = 4 THEN 0
            WHEN (x.it & 1) = 1 THEN 1
            WHEN (x.ph & 2) = 2 OR (x.lo & 1) = 1 THEN 1
            ELSE 0 END = 1;
DELETE FROM visibility_places;
INSERT INTO viewer_stats (user_id, permitted, concealed, permitted_bytes, concealed_bytes) SELECT NEW.user_id, COUNT(*), COALESCE(SUM(v.concealed), 0), COALESCE(SUM(a.size_bytes), 0), COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.size_bytes END), 0)   FROM viewer_assets v JOIN assets a ON a.id = v.asset_id WHERE v.user_id = NEW.user_id;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT v.user_id AS user_id, 'tag' AS kind, m.tag_id AS object_id, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed, COALESCE(SUM(a.size_bytes), 0) AS permitted_bytes, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.size_bytes END), 0) AS concealed_bytes, COALESCE(SUM(a.duration_ms), 0) AS permitted_ms, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.duration_ms END), 0) AS concealed_ms FROM viewer_assets v JOIN asset_tags m ON m.asset_id = v.asset_id JOIN assets a ON a.id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.tag_id UNION ALL SELECT v.user_id AS user_id, 'person' AS kind, m.person_id AS object_id, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed, COALESCE(SUM(a.size_bytes), 0) AS permitted_bytes, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.size_bytes END), 0) AS concealed_bytes, COALESCE(SUM(a.duration_ms), 0) AS permitted_ms, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.duration_ms END), 0) AS concealed_ms FROM viewer_assets v JOIN asset_people m ON m.asset_id = v.asset_id JOIN assets a ON a.id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.person_id UNION ALL SELECT v.user_id AS user_id, 'collection' AS kind, m.collection_id AS object_id, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed, COALESCE(SUM(a.size_bytes), 0) AS permitted_bytes, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.size_bytes END), 0) AS concealed_bytes, COALESCE(SUM(a.duration_ms), 0) AS permitted_ms, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.duration_ms END), 0) AS concealed_ms FROM viewer_assets v JOIN collection_items m ON m.asset_id = v.asset_id JOIN assets a ON a.id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.collection_id UNION ALL SELECT v.user_id AS user_id, 'photo_set' AS kind, m.photo_set_id AS object_id, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed, COALESCE(SUM(a.size_bytes), 0) AS permitted_bytes, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.size_bytes END), 0) AS concealed_bytes, COALESCE(SUM(a.duration_ms), 0) AS permitted_ms, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.duration_ms END), 0) AS concealed_ms FROM viewer_assets v JOIN photo_set_items m ON m.asset_id = v.asset_id JOIN assets a ON a.id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.photo_set_id UNION ALL SELECT v.user_id AS user_id, 'song' AS kind, m.song_id AS object_id, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed, COALESCE(SUM(a.size_bytes), 0) AS permitted_bytes, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.size_bytes END), 0) AS concealed_bytes, COALESCE(SUM(a.duration_ms), 0) AS permitted_ms, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.duration_ms END), 0) AS concealed_ms FROM viewer_assets v JOIN song_files m ON m.asset_id = v.asset_id JOIN assets a ON a.id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.song_id UNION ALL SELECT v.user_id AS user_id, 'username' AS kind, m.username_id AS object_id, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed, COALESCE(SUM(a.size_bytes), 0) AS permitted_bytes, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.size_bytes END), 0) AS concealed_bytes, COALESCE(SUM(a.duration_ms), 0) AS permitted_ms, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.duration_ms END), 0) AS concealed_ms FROM viewer_assets v JOIN asset_usernames m ON m.asset_id = v.asset_id JOIN assets a ON a.id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.username_id UNION ALL SELECT v.user_id AS user_id, 'loop' AS kind, m.id AS object_id, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed, 0 AS permitted_bytes, 0 AS concealed_bytes, 0 AS permitted_ms, 0 AS concealed_ms FROM viewer_assets v JOIN loops m ON m.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.id UNION ALL SELECT v.user_id AS user_id, 'folder' AS kind, m.folder_id AS object_id, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed, COALESCE(SUM(a.size_bytes), 0) AS permitted_bytes, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.size_bytes END), 0) AS concealed_bytes, COALESCE(SUM(a.duration_ms), 0) AS permitted_ms, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.duration_ms END), 0) AS concealed_ms FROM viewer_assets v JOIN (SELECT l.asset_id, an.ancestor_id AS folder_id   FROM asset_locations l JOIN folder_ancestry an ON an.folder_id = l.folder_id  WHERE l.status = 'present') m ON m.asset_id = v.asset_id JOIN assets a ON a.id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.folder_id UNION ALL SELECT v.user_id AS user_id, 'media' AS kind, m.media_type AS object_id, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed, COALESCE(SUM(a.size_bytes), 0) AS permitted_bytes, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.size_bytes END), 0) AS concealed_bytes, COALESCE(SUM(a.duration_ms), 0) AS permitted_ms, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.duration_ms END), 0) AS concealed_ms FROM viewer_assets v JOIN (SELECT ma.id AS asset_id, ma.media_type FROM assets ma) m ON m.asset_id = v.asset_id JOIN assets a ON a.id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.media_type UNION ALL SELECT v.user_id AS user_id, 'place' AS kind, m.folder_name AS object_id, COUNT(DISTINCT v.asset_id) AS permitted, COUNT(DISTINCT CASE WHEN v.concealed = 1 THEN v.asset_id END) AS concealed, 0 AS permitted_bytes, 0 AS concealed_bytes, 0 AS permitted_ms, 0 AS concealed_ms FROM viewer_assets v JOIN (SELECT pl.asset_id, pf.name AS folder_name FROM asset_locations pl JOIN folders pf ON pf.id = pl.folder_id) m ON m.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.folder_name UNION ALL SELECT v.user_id AS user_id, 'has_tags' AS kind, m.present AS object_id, COUNT(DISTINCT v.asset_id) AS permitted, COUNT(DISTINCT CASE WHEN v.concealed = 1 THEN v.asset_id END) AS concealed, 0 AS permitted_bytes, 0 AS concealed_bytes, 0 AS permitted_ms, 0 AS concealed_ms FROM viewer_assets v JOIN (SELECT hm.asset_id, 'any' AS present FROM asset_tags hm) m ON m.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.present UNION ALL SELECT v.user_id AS user_id, 'has_people' AS kind, m.present AS object_id, COUNT(DISTINCT v.asset_id) AS permitted, COUNT(DISTINCT CASE WHEN v.concealed = 1 THEN v.asset_id END) AS concealed, 0 AS permitted_bytes, 0 AS concealed_bytes, 0 AS permitted_ms, 0 AS concealed_ms FROM viewer_assets v JOIN (SELECT hm.asset_id, 'any' AS present FROM asset_people hm) m ON m.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.present UNION ALL SELECT v.user_id AS user_id, 'has_sites' AS kind, m.present AS object_id, COUNT(DISTINCT v.asset_id) AS permitted, COUNT(DISTINCT CASE WHEN v.concealed = 1 THEN v.asset_id END) AS concealed, 0 AS permitted_bytes, 0 AS concealed_bytes, 0 AS permitted_ms, 0 AS concealed_ms FROM viewer_assets v JOIN (SELECT hm.asset_id, 'any' AS present FROM asset_usernames hm) m ON m.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.present UNION ALL SELECT v.user_id AS user_id, 'has_collections' AS kind, m.present AS object_id, COUNT(DISTINCT v.asset_id) AS permitted, COUNT(DISTINCT CASE WHEN v.concealed = 1 THEN v.asset_id END) AS concealed, 0 AS permitted_bytes, 0 AS concealed_bytes, 0 AS permitted_ms, 0 AS concealed_ms FROM viewer_assets v JOIN (SELECT hm.asset_id, 'any' AS present FROM collection_items hm) m ON m.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.present UNION ALL SELECT v.user_id AS user_id, 'has_photo_sets' AS kind, m.present AS object_id, COUNT(DISTINCT v.asset_id) AS permitted, COUNT(DISTINCT CASE WHEN v.concealed = 1 THEN v.asset_id END) AS concealed, 0 AS permitted_bytes, 0 AS concealed_bytes, 0 AS permitted_ms, 0 AS concealed_ms FROM viewer_assets v JOIN (SELECT hm.asset_id, 'any' AS present FROM photo_set_items hm) m ON m.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.present UNION ALL SELECT v.user_id AS user_id, 'has_songs' AS kind, m.present AS object_id, COUNT(DISTINCT v.asset_id) AS permitted, COUNT(DISTINCT CASE WHEN v.concealed = 1 THEN v.asset_id END) AS concealed, 0 AS permitted_bytes, 0 AS concealed_bytes, 0 AS permitted_ms, 0 AS concealed_ms FROM viewer_assets v JOIN (SELECT hm.asset_id, 'any' AS present FROM song_files hm) m ON m.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.present UNION ALL SELECT v.user_id AS user_id, 'site' AS kind, v.site_id AS object_id, COUNT(DISTINCT v.asset_id) AS permitted, COUNT(DISTINCT CASE WHEN v.concealed = 1 THEN v.asset_id END) AS concealed, COALESCE(SUM(a.size_bytes), 0) AS permitted_bytes, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.size_bytes END), 0) AS concealed_bytes, COALESCE(SUM(a.duration_ms), 0) AS permitted_ms, COALESCE(SUM(CASE WHEN v.concealed = 1 THEN a.duration_ms END), 0) AS concealed_ms FROM (SELECT DISTINCT v.user_id, v.asset_id, v.concealed, m.site_id FROM viewer_assets v JOIN (SELECT aa.asset_id, reach.ancestor_id AS site_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id) m ON m.asset_id = v.asset_id WHERE v.user_id = NEW.user_id) v CROSS JOIN assets a ON a.id = v.asset_id GROUP BY v.user_id, v.site_id UNION ALL SELECT v.user_id AS user_id, 'pile' AS kind, m.pile_id AS object_id, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed, 0 AS permitted_bytes, 0 AS concealed_bytes, 0 AS permitted_ms, 0 AS concealed_ms FROM viewer_assets v JOIN (SELECT asset_id, pile_id FROM face_tracks WHERE person_id IS NULL AND pile_id IS NOT NULL) m ON m.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.pile_id UNION ALL SELECT v.user_id AS user_id, 'face_band' AS kind, m.band AS object_id, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed, 0 AS permitted_bytes, 0 AS concealed_bytes, 0 AS permitted_ms, 0 AS concealed_ms FROM viewer_assets v JOIN (SELECT asset_id, person_id || ':' || COALESCE(attribution, '') AS band FROM face_tracks WHERE person_id IS NOT NULL) m ON m.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.band UNION ALL SELECT v.user_id AS user_id, 'music_waiting' AS kind, m.scope AS object_id, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed, 0 AS permitted_bytes, 0 AS concealed_bytes, 0 AS permitted_ms, 0 AS concealed_ms FROM viewer_assets v JOIN (SELECT asset_id, 'library' AS scope FROM music_waiting) m ON m.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, m.scope;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT v.user_id AS user_id, 'person' AS kind_a, ma.person_id AS id_a, 'photo_set' AS kind_b, mb.photo_set_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN asset_people ma ON ma.asset_id = v.asset_id JOIN photo_set_items mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.person_id, mb.photo_set_id UNION ALL SELECT v.user_id AS user_id, 'person' AS kind_a, ma.person_id AS id_a, 'tag' AS kind_b, mb.tag_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN asset_people ma ON ma.asset_id = v.asset_id JOIN asset_tags mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.person_id, mb.tag_id UNION ALL SELECT v.user_id AS user_id, 'person' AS kind_a, ma.person_id AS id_a, 'collection' AS kind_b, mb.collection_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN asset_people ma ON ma.asset_id = v.asset_id JOIN collection_items mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.person_id, mb.collection_id UNION ALL SELECT v.user_id AS user_id, 'person' AS kind_a, ma.person_id AS id_a, 'username' AS kind_b, mb.username_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN asset_people ma ON ma.asset_id = v.asset_id JOIN asset_usernames mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.person_id, mb.username_id UNION ALL SELECT v.user_id AS user_id, 'tag' AS kind_a, ma.tag_id AS id_a, 'photo_set' AS kind_b, mb.photo_set_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN asset_tags ma ON ma.asset_id = v.asset_id JOIN photo_set_items mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.tag_id, mb.photo_set_id UNION ALL SELECT v.user_id AS user_id, 'tag' AS kind_a, ma.tag_id AS id_a, 'collection' AS kind_b, mb.collection_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN asset_tags ma ON ma.asset_id = v.asset_id JOIN collection_items mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.tag_id, mb.collection_id UNION ALL SELECT v.user_id AS user_id, 'tag' AS kind_a, ma.tag_id AS id_a, 'username' AS kind_b, mb.username_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN asset_tags ma ON ma.asset_id = v.asset_id JOIN asset_usernames mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.tag_id, mb.username_id UNION ALL SELECT v.user_id AS user_id, 'collection' AS kind_a, ma.collection_id AS id_a, 'username' AS kind_b, mb.username_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN collection_items ma ON ma.asset_id = v.asset_id JOIN asset_usernames mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.collection_id, mb.username_id UNION ALL SELECT v.user_id AS user_id, 'photo_set' AS kind_a, ma.photo_set_id AS id_a, 'username' AS kind_b, mb.username_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN photo_set_items ma ON ma.asset_id = v.asset_id JOIN asset_usernames mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.photo_set_id, mb.username_id UNION ALL SELECT v.user_id AS user_id, 'person' AS kind_a, ma.person_id AS id_a, 'song' AS kind_b, mb.song_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN asset_people ma ON ma.asset_id = v.asset_id JOIN song_files mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.person_id, mb.song_id UNION ALL SELECT v.user_id AS user_id, 'tag' AS kind_a, ma.tag_id AS id_a, 'song' AS kind_b, mb.song_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN asset_tags ma ON ma.asset_id = v.asset_id JOIN song_files mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.tag_id, mb.song_id UNION ALL SELECT v.user_id AS user_id, 'song' AS kind_a, ma.song_id AS id_a, 'username' AS kind_b, mb.username_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN song_files ma ON ma.asset_id = v.asset_id JOIN asset_usernames mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.song_id, mb.username_id UNION ALL SELECT v.user_id AS user_id, 'collection' AS kind_a, ma.collection_id AS id_a, 'song' AS kind_b, mb.song_id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN collection_items ma ON ma.asset_id = v.asset_id JOIN song_files mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.collection_id, mb.song_id UNION ALL SELECT v.user_id AS user_id, 'song' AS kind_a, ma.song_id AS id_a, 'loop' AS kind_b, mb.id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN song_files ma ON ma.asset_id = v.asset_id JOIN loops mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.song_id, mb.id UNION ALL SELECT v.user_id AS user_id, 'person' AS kind_a, ma.person_id AS id_a, 'loop' AS kind_b, mb.id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN asset_people ma ON ma.asset_id = v.asset_id JOIN loops mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.person_id, mb.id UNION ALL SELECT v.user_id AS user_id, 'tag' AS kind_a, ma.tag_id AS id_a, 'loop' AS kind_b, mb.id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN asset_tags ma ON ma.asset_id = v.asset_id JOIN loops mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.tag_id, mb.id UNION ALL SELECT v.user_id AS user_id, 'collection' AS kind_a, ma.collection_id AS id_a, 'loop' AS kind_b, mb.id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN collection_items ma ON ma.asset_id = v.asset_id JOIN loops mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.collection_id, mb.id UNION ALL SELECT v.user_id AS user_id, 'username' AS kind_a, ma.username_id AS id_a, 'loop' AS kind_b, mb.id AS id_b, COUNT(*) AS permitted, COALESCE(SUM(v.concealed), 0) AS concealed FROM viewer_assets v JOIN asset_usernames ma ON ma.asset_id = v.asset_id JOIN loops mb ON mb.asset_id = v.asset_id WHERE v.user_id = NEW.user_id GROUP BY v.user_id, ma.username_id, mb.id;
DELETE FROM visibility_owed WHERE user_id = NEW.user_id;
END;
CREATE TRIGGER vis_recompute_settle INSTEAD OF INSERT ON visibility_step_settle BEGIN
DELETE FROM visibility_decided;
DELETE FROM visibility_places;

INSERT INTO visibility_places (user_id, root_id, place, restricted, shared, vaulted)
SELECT l.user_id, l.root_id, COALESCE(l.folder_id, ''),
       CASE WHEN r.id IS NULL THEN 1 ELSE CASE WHEN l.folder_id IS NULL THEN CASE WHEN 
(EXISTS (SELECT 1 FROM acl_grants g
          WHERE g.subject_user_id = p.user_id AND g.object_type = 'root' AND g.object_id = l.root_id
            AND g.effect = 'restrict')
 OR EXISTS (SELECT 1 FROM acl_grants g
             WHERE g.subject_user_id = p.user_id AND g.object_type = 'global'
               AND g.object_id IS NULL AND g.effect = 'restrict')) THEN 1 ELSE 0 END
     WHEN fa.folder_id IS NULL THEN 1
     WHEN 
EXISTS (SELECT 1 FROM folder_ancestry an
         JOIN acl_grants g ON g.object_type = 'folder' AND g.object_id = an.ancestor_id
                          AND g.subject_user_id = p.user_id AND g.effect = 'restrict'
        WHERE an.folder_id = l.folder_id) OR 
(EXISTS (SELECT 1 FROM acl_grants g
          WHERE g.subject_user_id = p.user_id AND g.object_type = 'root' AND g.object_id = l.root_id
            AND g.effect = 'restrict')
 OR EXISTS (SELECT 1 FROM acl_grants g
             WHERE g.subject_user_id = p.user_id AND g.object_type = 'global'
               AND g.object_id IS NULL AND g.effect = 'restrict')) THEN 1
     ELSE 0 END END,
       CASE WHEN r.id IS NULL THEN 0 ELSE CASE WHEN l.folder_id IS NULL THEN 
COALESCE((SELECT MAX(g.effect = 'share') FROM acl_grants g
           WHERE g.subject_user_id = p.user_id AND g.object_type = 'root' AND g.object_id = l.root_id),
         (SELECT MAX(g.effect = 'share') FROM acl_grants g
           WHERE g.subject_user_id = p.user_id AND g.object_type = 'global' AND g.object_id IS NULL),
         0)
     WHEN fa.folder_id IS NULL THEN 0
     ELSE COALESCE(
(SELECT MAX(g.effect = 'share')
   FROM folder_ancestry an
   JOIN acl_grants g ON g.object_type = 'folder' AND g.object_id = an.ancestor_id
                    AND g.subject_user_id = p.user_id
  WHERE an.folder_id = l.folder_id
  GROUP BY an.depth ORDER BY an.depth LIMIT 1), 
COALESCE((SELECT MAX(g.effect = 'share') FROM acl_grants g
           WHERE g.subject_user_id = p.user_id AND g.object_type = 'root' AND g.object_id = l.root_id),
         (SELECT MAX(g.effect = 'share') FROM acl_grants g
           WHERE g.subject_user_id = p.user_id AND g.object_type = 'global' AND g.object_id IS NULL),
         0)) END END,
       CASE WHEN r.id IS NULL THEN 1 ELSE CASE WHEN l.folder_id IS NULL THEN CASE WHEN 
EXISTS (SELECT 1 FROM root_user_state h
         WHERE h.root_id = l.root_id AND h.user_id = p.user_id AND h.hidden = 1) THEN 1 ELSE 0 END
     WHEN fa.folder_id IS NULL THEN 1
     ELSE CASE WHEN 
EXISTS (SELECT 1 FROM root_user_state h
         WHERE h.root_id = l.root_id AND h.user_id = p.user_id AND h.hidden = 1) OR 
EXISTS (SELECT 1 FROM folder_ancestry an
         JOIN folder_user_state h ON h.folder_id = an.ancestor_id
                                 AND h.user_id = p.user_id AND h.hidden = 1
        WHERE an.folder_id = l.folder_id) THEN 1 ELSE 0 END END END
  FROM (SELECT DISTINCT s.user_id, l.root_id, l.folder_id  FROM visibility_pending s JOIN asset_locations l ON l.asset_id = s.asset_id) l
  JOIN (SELECT id AS user_id FROM users) p ON p.user_id = l.user_id
  LEFT JOIN library_roots r ON r.id = l.root_id
  LEFT JOIN folder_ancestry fa ON fa.folder_id = l.folder_id AND fa.ancestor_id = l.folder_id;
INSERT INTO visibility_decided (user_id, asset_id, concealed)
SELECT x.user_id, x.asset_id,
       CASE WHEN x.hidden = 1 OR (x.ph & 1) = 1 OR x.lv = 1 THEN 1 ELSE 0 END AS concealed
  FROM (SELECT p.user_id, p.asset_id, u.role,
               COALESCE(
(SELECT MAX(pl.restricted) * 4
      + MAX(CASE WHEN pl.restricted = 0 AND pl.shared = 1 THEN 1 ELSE 0 END) * 2
      + MAX(pl.vaulted)
   FROM asset_locations l
   JOIN visibility_places pl ON pl.user_id = p.user_id AND pl.root_id = l.root_id
                            AND pl.place = COALESCE(l.folder_id, '')
  WHERE l.asset_id = p.asset_id), 0) AS ph,
               COALESCE(
(SELECT MAX(g.effect = 'restrict') * 2 + MAX(g.effect = 'share')
   FROM (SELECT 'tag' AS kind, tag_id AS object FROM asset_tags WHERE asset_id = p.asset_id
         UNION ALL
         SELECT 'person', person_id FROM asset_people WHERE asset_id = p.asset_id
         UNION ALL
         SELECT 'collection', collection_id FROM collection_items WHERE asset_id = p.asset_id
         UNION ALL
         SELECT 'site', up.site_id FROM (WITH RECURSIVE up(site_id) AS (SELECT s0.id FROM asset_usernames aa
  JOIN usernames ac ON ac.id = aa.username_id JOIN sites s0 ON s0.id = ac.site_id
  WHERE aa.asset_id = p.asset_id
  UNION SELECT s.parent_id FROM up JOIN sites s ON s.id = up.site_id WHERE s.parent_id IS NOT NULL)
SELECT site_id FROM up) up
         UNION ALL
         SELECT 'photo_set', photo_set_id FROM photo_set_items WHERE asset_id = p.asset_id
         UNION ALL
         SELECT 'song', song_id FROM song_files WHERE asset_id = p.asset_id) m
   JOIN acl_grants g ON g.subject_user_id = p.user_id
                    AND g.object_type = m.kind AND g.object_id = m.object), 0) AS lo,
               COALESCE(
(SELECT MAX(g.effect = 'restrict') * 2 + MAX(g.effect = 'share')
   FROM acl_grants g
  WHERE g.subject_user_id = p.user_id AND g.object_type = 'item' AND g.object_id = p.asset_id), 0) AS it,
               CASE WHEN 
EXISTS (SELECT 1 FROM asset_user_state h
         WHERE h.asset_id = p.asset_id AND h.user_id = p.user_id AND h.hidden = 1) THEN 1 ELSE 0 END AS hidden,
               CASE WHEN 
EXISTS (SELECT 1 FROM asset_people ap
         JOIN person_user_state hp ON hp.person_id = ap.person_id
        WHERE ap.asset_id = p.asset_id AND hp.user_id = p.user_id AND hp.hidden = 1)
OR EXISTS (SELECT 1 FROM collection_items ci
            JOIN collection_user_state hc ON hc.collection_id = ci.collection_id
           WHERE ci.asset_id = p.asset_id AND hc.user_id = p.user_id AND hc.hidden = 1)
OR EXISTS (SELECT 1 FROM asset_tags vt
            JOIN tag_user_state ht ON ht.tag_id = vt.tag_id
           WHERE vt.asset_id = p.asset_id AND ht.user_id = p.user_id AND ht.hidden = 1)
OR (EXISTS (SELECT 1 FROM site_user_state hz WHERE hz.user_id = p.user_id AND hz.hidden = 1)
    AND EXISTS (SELECT 1 FROM (WITH RECURSIVE up(site_id) AS (SELECT s0.id FROM asset_usernames aa
  JOIN usernames ac ON ac.id = aa.username_id JOIN sites s0 ON s0.id = ac.site_id
  WHERE aa.asset_id = p.asset_id
  UNION SELECT s.parent_id FROM up JOIN sites s ON s.id = up.site_id WHERE s.parent_id IS NOT NULL)
SELECT site_id FROM up) up JOIN site_user_state hl ON hl.site_id = up.site_id
                 WHERE hl.user_id = p.user_id AND hl.hidden = 1))
OR EXISTS (SELECT 1 FROM photo_set_items vp
            JOIN photo_set_user_state hs ON hs.photo_set_id = vp.photo_set_id
           WHERE vp.asset_id = p.asset_id AND hs.user_id = p.user_id AND hs.hidden = 1)
OR EXISTS (SELECT 1 FROM song_files vs
            JOIN song_user_state hg ON hg.song_id = vs.song_id
           WHERE vs.asset_id = p.asset_id AND hg.user_id = p.user_id AND hg.hidden = 1) THEN 1 ELSE 0 END AS lv
          FROM (SELECT user_id, asset_id FROM visibility_pending) p
          JOIN users u ON u.id = p.user_id
         WHERE EXISTS (SELECT 1 FROM asset_locations al WHERE al.asset_id = p.asset_id)
         LIMIT -1) x
 WHERE x.role = 'admin'
    OR CASE WHEN (x.lo & 2) = 2 THEN 0
            WHEN (x.it & 2) = 2 THEN 0
            WHEN (x.ph & 4) = 4 THEN 0
            WHEN (x.it & 1) = 1 THEN 1
            WHEN (x.ph & 2) = 2 OR (x.lo & 1) = 1 THEN 1
            ELSE 0 END = 1;
DELETE FROM visibility_places;
DELETE FROM visibility_pending WHERE (SELECT d.concealed FROM visibility_decided d         WHERE d.user_id = visibility_pending.user_id           AND d.asset_id = visibility_pending.asset_id)    IS (SELECT v.concealed FROM viewer_assets v         WHERE v.user_id = visibility_pending.user_id           AND v.asset_id = visibility_pending.asset_id);
END;
CREATE TRIGGER vis_recompute_settled INSTEAD OF INSERT ON visibility_step_settled BEGIN
DELETE FROM viewer_assets WHERE (user_id, asset_id) IN (SELECT user_id, asset_id FROM visibility_pending);
INSERT INTO viewer_assets (user_id, asset_id, concealed) SELECT d.user_id, d.asset_id, d.concealed FROM visibility_pending s CROSS JOIN visibility_decided d ON d.user_id = s.user_id AND d.asset_id = s.asset_id;
DELETE FROM visibility_decided;
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_recompute_touch INSTEAD OF INSERT ON visibility_step_touch BEGIN
DELETE FROM visibility_members WHERE asset_id IN (SELECT asset_id FROM visibility_pending) AND NOT EXISTS (SELECT 1 FROM visibility_owed o WHERE o.asset_id = visibility_members.asset_id);
INSERT INTO visibility_members (asset_id, side, kind, object_id, n, bytes, ms) SELECT asset_id, 0, kind, object_id, n, bytes, ms FROM (SELECT a.id AS asset_id, '' AS kind, '' AS object_id, 1 AS n, COALESCE(a.size_bytes, 0) AS bytes, COALESCE(a.duration_ms, 0) AS ms FROM assets a WHERE a.id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = a.id AND r.side = 0 AND r.kind = '#') UNION ALL SELECT m.asset_id, 'tag' AS kind, m.tag_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_tags m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#tag') GROUP BY m.asset_id, m.tag_id UNION ALL SELECT m.asset_id, 'person' AS kind, m.person_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_people m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#person') GROUP BY m.asset_id, m.person_id UNION ALL SELECT m.asset_id, 'collection' AS kind, m.collection_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM collection_items m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#collection') GROUP BY m.asset_id, m.collection_id UNION ALL SELECT m.asset_id, 'photo_set' AS kind, m.photo_set_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM photo_set_items m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#photo_set') GROUP BY m.asset_id, m.photo_set_id UNION ALL SELECT m.asset_id, 'song' AS kind, m.song_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM song_files m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#song') GROUP BY m.asset_id, m.song_id UNION ALL SELECT m.asset_id, 'username' AS kind, m.username_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_usernames m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#username') GROUP BY m.asset_id, m.username_id UNION ALL SELECT m.asset_id, 'loop' AS kind, m.id AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM loops m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#loop') GROUP BY m.asset_id, m.id UNION ALL SELECT m.asset_id, 'folder' AS kind, m.folder_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM (SELECT l.asset_id, an.ancestor_id AS folder_id   FROM asset_locations l JOIN folder_ancestry an ON an.folder_id = l.folder_id  WHERE l.status = 'present') m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.folder_id UNION ALL SELECT m.asset_id, 'media' AS kind, m.media_type AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM (SELECT ma.id AS asset_id, ma.media_type FROM assets ma) m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.media_type UNION ALL SELECT m.asset_id, 'place' AS kind, m.folder_name AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT pl.asset_id, pf.name AS folder_name FROM asset_locations pl JOIN folders pf ON pf.id = pl.folder_id) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.folder_name UNION ALL SELECT m.asset_id, 'has_tags' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM asset_tags hm) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_people' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM asset_people hm) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_sites' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM asset_usernames hm) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_collections' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM collection_items hm) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_photo_sets' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM photo_set_items hm) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_songs' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM song_files hm) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'site' AS kind, m.site_id AS object_id, 1 AS n, COALESCE(MAX(a.size_bytes), 0) * 1 AS bytes, COALESCE(MAX(a.duration_ms), 0) * 1 AS ms FROM (SELECT aa.asset_id, reach.ancestor_id AS site_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id) m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.site_id UNION ALL SELECT m.asset_id, 'pile' AS kind, m.pile_id AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, pile_id FROM face_tracks WHERE person_id IS NULL AND pile_id IS NOT NULL) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#pile') GROUP BY m.asset_id, m.pile_id UNION ALL SELECT m.asset_id, 'face_band' AS kind, m.band AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, person_id || ':' || COALESCE(attribution, '') AS band FROM face_tracks WHERE person_id IS NOT NULL) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#face_band') GROUP BY m.asset_id, m.band UNION ALL SELECT m.asset_id, 'music_waiting' AS kind, m.scope AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, 'library' AS scope FROM music_waiting) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#music_waiting') GROUP BY m.asset_id, m.scope UNION ALL SELECT a.id, k.column1, '', 0, 0, 0 FROM assets a CROSS JOIN (VALUES ('#'), ('#tag'), ('#person'), ('#collection'), ('#photo_set'), ('#song'), ('#username'), ('#loop'), ('#pile'), ('#face_band'), ('#music_waiting')) k WHERE a.id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = a.id AND r.side = 0 AND r.kind = k.column1));
UPDATE visibility_owed SET owed = 0 WHERE owed = 1 AND asset_id IN (SELECT asset_id FROM visibility_pending);
INSERT INTO visibility_owed (asset_id, user_id, concealed) SELECT s.asset_id, s.user_id, v.concealed FROM visibility_pending s JOIN assets a ON a.id = s.asset_id LEFT JOIN viewer_assets v ON v.user_id = s.user_id AND v.asset_id = s.asset_id WHERE NOT EXISTS (SELECT 1 FROM visibility_owed o WHERE o.asset_id = s.asset_id AND o.user_id = s.user_id);
END;
CREATE TRIGGER vis_recompute_answers INSTEAD OF INSERT ON visibility_step_answers BEGIN
DELETE FROM visibility_members WHERE asset_id IN (SELECT asset_id FROM visibility_pending) AND NOT EXISTS (SELECT 1 FROM visibility_owed o WHERE o.asset_id = visibility_members.asset_id);
UPDATE visibility_owed SET owed = 0 WHERE owed = 1 AND asset_id IN (SELECT asset_id FROM visibility_pending);
INSERT INTO visibility_owed (asset_id, user_id, concealed) SELECT s.asset_id, s.user_id, v.concealed FROM visibility_pending s JOIN assets a ON a.id = s.asset_id LEFT JOIN viewer_assets v ON v.user_id = s.user_id AND v.asset_id = s.asset_id WHERE NOT EXISTS (SELECT 1 FROM visibility_owed o WHERE o.asset_id = s.asset_id AND o.user_id = s.user_id);
END;
CREATE TRIGGER vis_recompute_touch_face_tracks INSTEAD OF INSERT ON visibility_step_touch_face_tracks BEGIN
DELETE FROM visibility_members WHERE asset_id IN (SELECT asset_id FROM visibility_pending) AND NOT EXISTS (SELECT 1 FROM visibility_owed o WHERE o.asset_id = visibility_members.asset_id);
INSERT INTO visibility_members (asset_id, side, kind, object_id, n, bytes, ms) SELECT asset_id, 0, kind, object_id, n, bytes, ms FROM (SELECT m.asset_id, 'pile' AS kind, m.pile_id AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, pile_id FROM face_tracks WHERE person_id IS NULL AND pile_id IS NOT NULL) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#pile') GROUP BY m.asset_id, m.pile_id UNION ALL SELECT m.asset_id, 'face_band' AS kind, m.band AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, person_id || ':' || COALESCE(attribution, '') AS band FROM face_tracks WHERE person_id IS NOT NULL) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#face_band') GROUP BY m.asset_id, m.band UNION ALL SELECT a.id, k.column1, '', 0, 0, 0 FROM assets a CROSS JOIN (VALUES ('#pile'), ('#face_band')) k WHERE a.id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = a.id AND r.side = 0 AND r.kind = k.column1));
UPDATE visibility_owed SET owed = 0 WHERE owed = 1 AND asset_id IN (SELECT asset_id FROM visibility_pending);
INSERT INTO visibility_owed (asset_id, user_id, concealed) SELECT s.asset_id, s.user_id, v.concealed FROM visibility_pending s JOIN assets a ON a.id = s.asset_id LEFT JOIN viewer_assets v ON v.user_id = s.user_id AND v.asset_id = s.asset_id WHERE NOT EXISTS (SELECT 1 FROM visibility_owed o WHERE o.asset_id = s.asset_id AND o.user_id = s.user_id);
END;
CREATE TRIGGER vis_recompute_touch_loops INSTEAD OF INSERT ON visibility_step_touch_loops BEGIN
DELETE FROM visibility_members WHERE asset_id IN (SELECT asset_id FROM visibility_pending) AND NOT EXISTS (SELECT 1 FROM visibility_owed o WHERE o.asset_id = visibility_members.asset_id);
INSERT INTO visibility_members (asset_id, side, kind, object_id, n, bytes, ms) SELECT asset_id, 0, kind, object_id, n, bytes, ms FROM (SELECT m.asset_id, 'tag' AS kind, m.tag_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_tags m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#tag') GROUP BY m.asset_id, m.tag_id UNION ALL SELECT m.asset_id, 'person' AS kind, m.person_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_people m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#person') GROUP BY m.asset_id, m.person_id UNION ALL SELECT m.asset_id, 'collection' AS kind, m.collection_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM collection_items m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#collection') GROUP BY m.asset_id, m.collection_id UNION ALL SELECT m.asset_id, 'photo_set' AS kind, m.photo_set_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM photo_set_items m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#photo_set') GROUP BY m.asset_id, m.photo_set_id UNION ALL SELECT m.asset_id, 'song' AS kind, m.song_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM song_files m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#song') GROUP BY m.asset_id, m.song_id UNION ALL SELECT m.asset_id, 'username' AS kind, m.username_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_usernames m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#username') GROUP BY m.asset_id, m.username_id UNION ALL SELECT m.asset_id, 'loop' AS kind, m.id AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM loops m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#loop') GROUP BY m.asset_id, m.id UNION ALL SELECT a.id, k.column1, '', 0, 0, 0 FROM assets a CROSS JOIN (VALUES ('#tag'), ('#person'), ('#collection'), ('#photo_set'), ('#song'), ('#username'), ('#loop')) k WHERE a.id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = a.id AND r.side = 0 AND r.kind = k.column1));
UPDATE visibility_owed SET owed = 0 WHERE owed = 1 AND asset_id IN (SELECT asset_id FROM visibility_pending);
INSERT INTO visibility_owed (asset_id, user_id, concealed) SELECT s.asset_id, s.user_id, v.concealed FROM visibility_pending s JOIN assets a ON a.id = s.asset_id LEFT JOIN viewer_assets v ON v.user_id = s.user_id AND v.asset_id = s.asset_id WHERE NOT EXISTS (SELECT 1 FROM visibility_owed o WHERE o.asset_id = s.asset_id AND o.user_id = s.user_id);
END;
CREATE TRIGGER vis_recompute_touch_music_waiting INSTEAD OF INSERT ON visibility_step_touch_music_waiting BEGIN
DELETE FROM visibility_members WHERE asset_id IN (SELECT asset_id FROM visibility_pending) AND NOT EXISTS (SELECT 1 FROM visibility_owed o WHERE o.asset_id = visibility_members.asset_id);
INSERT INTO visibility_members (asset_id, side, kind, object_id, n, bytes, ms) SELECT asset_id, 0, kind, object_id, n, bytes, ms FROM (SELECT m.asset_id, 'music_waiting' AS kind, m.scope AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, 'library' AS scope FROM music_waiting) m WHERE m.asset_id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#music_waiting') GROUP BY m.asset_id, m.scope UNION ALL SELECT a.id, k.column1, '', 0, 0, 0 FROM assets a CROSS JOIN (VALUES ('#music_waiting')) k WHERE a.id IN (SELECT DISTINCT s.asset_id FROM visibility_pending s JOIN assets a ON a.id = s.asset_id) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = a.id AND r.side = 0 AND r.kind = k.column1));
UPDATE visibility_owed SET owed = 0 WHERE owed = 1 AND asset_id IN (SELECT asset_id FROM visibility_pending);
INSERT INTO visibility_owed (asset_id, user_id, concealed) SELECT s.asset_id, s.user_id, v.concealed FROM visibility_pending s JOIN assets a ON a.id = s.asset_id LEFT JOIN viewer_assets v ON v.user_id = s.user_id AND v.asset_id = s.asset_id WHERE NOT EXISTS (SELECT 1 FROM visibility_owed o WHERE o.asset_id = s.asset_id AND o.user_id = s.user_id);
END;
CREATE TRIGGER vis_recompute_rows INSTEAD OF INSERT ON visibility_step_rows BEGIN
DELETE FROM visibility_places;

INSERT INTO visibility_places (user_id, root_id, place, restricted, shared, vaulted)
SELECT l.user_id, l.root_id, COALESCE(l.folder_id, ''),
       CASE WHEN r.id IS NULL THEN 1 ELSE CASE WHEN l.folder_id IS NULL THEN CASE WHEN 
(EXISTS (SELECT 1 FROM acl_grants g
          WHERE g.subject_user_id = p.user_id AND g.object_type = 'root' AND g.object_id = l.root_id
            AND g.effect = 'restrict')
 OR EXISTS (SELECT 1 FROM acl_grants g
             WHERE g.subject_user_id = p.user_id AND g.object_type = 'global'
               AND g.object_id IS NULL AND g.effect = 'restrict')) THEN 1 ELSE 0 END
     WHEN fa.folder_id IS NULL THEN 1
     WHEN 
EXISTS (SELECT 1 FROM folder_ancestry an
         JOIN acl_grants g ON g.object_type = 'folder' AND g.object_id = an.ancestor_id
                          AND g.subject_user_id = p.user_id AND g.effect = 'restrict'
        WHERE an.folder_id = l.folder_id) OR 
(EXISTS (SELECT 1 FROM acl_grants g
          WHERE g.subject_user_id = p.user_id AND g.object_type = 'root' AND g.object_id = l.root_id
            AND g.effect = 'restrict')
 OR EXISTS (SELECT 1 FROM acl_grants g
             WHERE g.subject_user_id = p.user_id AND g.object_type = 'global'
               AND g.object_id IS NULL AND g.effect = 'restrict')) THEN 1
     ELSE 0 END END,
       CASE WHEN r.id IS NULL THEN 0 ELSE CASE WHEN l.folder_id IS NULL THEN 
COALESCE((SELECT MAX(g.effect = 'share') FROM acl_grants g
           WHERE g.subject_user_id = p.user_id AND g.object_type = 'root' AND g.object_id = l.root_id),
         (SELECT MAX(g.effect = 'share') FROM acl_grants g
           WHERE g.subject_user_id = p.user_id AND g.object_type = 'global' AND g.object_id IS NULL),
         0)
     WHEN fa.folder_id IS NULL THEN 0
     ELSE COALESCE(
(SELECT MAX(g.effect = 'share')
   FROM folder_ancestry an
   JOIN acl_grants g ON g.object_type = 'folder' AND g.object_id = an.ancestor_id
                    AND g.subject_user_id = p.user_id
  WHERE an.folder_id = l.folder_id
  GROUP BY an.depth ORDER BY an.depth LIMIT 1), 
COALESCE((SELECT MAX(g.effect = 'share') FROM acl_grants g
           WHERE g.subject_user_id = p.user_id AND g.object_type = 'root' AND g.object_id = l.root_id),
         (SELECT MAX(g.effect = 'share') FROM acl_grants g
           WHERE g.subject_user_id = p.user_id AND g.object_type = 'global' AND g.object_id IS NULL),
         0)) END END,
       CASE WHEN r.id IS NULL THEN 1 ELSE CASE WHEN l.folder_id IS NULL THEN CASE WHEN 
EXISTS (SELECT 1 FROM root_user_state h
         WHERE h.root_id = l.root_id AND h.user_id = p.user_id AND h.hidden = 1) THEN 1 ELSE 0 END
     WHEN fa.folder_id IS NULL THEN 1
     ELSE CASE WHEN 
EXISTS (SELECT 1 FROM root_user_state h
         WHERE h.root_id = l.root_id AND h.user_id = p.user_id AND h.hidden = 1) OR 
EXISTS (SELECT 1 FROM folder_ancestry an
         JOIN folder_user_state h ON h.folder_id = an.ancestor_id
                                 AND h.user_id = p.user_id AND h.hidden = 1
        WHERE an.folder_id = l.folder_id) THEN 1 ELSE 0 END END END
  FROM (SELECT DISTINCT s.user_id, l.root_id, l.folder_id  FROM visibility_pending s JOIN asset_locations l ON l.asset_id = s.asset_id) l
  JOIN (SELECT id AS user_id FROM users) p ON p.user_id = l.user_id
  LEFT JOIN library_roots r ON r.id = l.root_id
  LEFT JOIN folder_ancestry fa ON fa.folder_id = l.folder_id AND fa.ancestor_id = l.folder_id;
DELETE FROM viewer_assets WHERE (user_id, asset_id) IN (SELECT user_id, asset_id FROM visibility_pending);
INSERT INTO viewer_assets (user_id, asset_id, concealed)
SELECT x.user_id, x.asset_id,
       CASE WHEN x.hidden = 1 OR (x.ph & 1) = 1 OR x.lv = 1 THEN 1 ELSE 0 END AS concealed
  FROM (SELECT p.user_id, p.asset_id, u.role,
               COALESCE(
(SELECT MAX(pl.restricted) * 4
      + MAX(CASE WHEN pl.restricted = 0 AND pl.shared = 1 THEN 1 ELSE 0 END) * 2
      + MAX(pl.vaulted)
   FROM asset_locations l
   JOIN visibility_places pl ON pl.user_id = p.user_id AND pl.root_id = l.root_id
                            AND pl.place = COALESCE(l.folder_id, '')
  WHERE l.asset_id = p.asset_id), 0) AS ph,
               COALESCE(
(SELECT MAX(g.effect = 'restrict') * 2 + MAX(g.effect = 'share')
   FROM (SELECT 'tag' AS kind, tag_id AS object FROM asset_tags WHERE asset_id = p.asset_id
         UNION ALL
         SELECT 'person', person_id FROM asset_people WHERE asset_id = p.asset_id
         UNION ALL
         SELECT 'collection', collection_id FROM collection_items WHERE asset_id = p.asset_id
         UNION ALL
         SELECT 'site', up.site_id FROM (WITH RECURSIVE up(site_id) AS (SELECT s0.id FROM asset_usernames aa
  JOIN usernames ac ON ac.id = aa.username_id JOIN sites s0 ON s0.id = ac.site_id
  WHERE aa.asset_id = p.asset_id
  UNION SELECT s.parent_id FROM up JOIN sites s ON s.id = up.site_id WHERE s.parent_id IS NOT NULL)
SELECT site_id FROM up) up
         UNION ALL
         SELECT 'photo_set', photo_set_id FROM photo_set_items WHERE asset_id = p.asset_id
         UNION ALL
         SELECT 'song', song_id FROM song_files WHERE asset_id = p.asset_id) m
   JOIN acl_grants g ON g.subject_user_id = p.user_id
                    AND g.object_type = m.kind AND g.object_id = m.object), 0) AS lo,
               COALESCE(
(SELECT MAX(g.effect = 'restrict') * 2 + MAX(g.effect = 'share')
   FROM acl_grants g
  WHERE g.subject_user_id = p.user_id AND g.object_type = 'item' AND g.object_id = p.asset_id), 0) AS it,
               CASE WHEN 
EXISTS (SELECT 1 FROM asset_user_state h
         WHERE h.asset_id = p.asset_id AND h.user_id = p.user_id AND h.hidden = 1) THEN 1 ELSE 0 END AS hidden,
               CASE WHEN 
EXISTS (SELECT 1 FROM asset_people ap
         JOIN person_user_state hp ON hp.person_id = ap.person_id
        WHERE ap.asset_id = p.asset_id AND hp.user_id = p.user_id AND hp.hidden = 1)
OR EXISTS (SELECT 1 FROM collection_items ci
            JOIN collection_user_state hc ON hc.collection_id = ci.collection_id
           WHERE ci.asset_id = p.asset_id AND hc.user_id = p.user_id AND hc.hidden = 1)
OR EXISTS (SELECT 1 FROM asset_tags vt
            JOIN tag_user_state ht ON ht.tag_id = vt.tag_id
           WHERE vt.asset_id = p.asset_id AND ht.user_id = p.user_id AND ht.hidden = 1)
OR (EXISTS (SELECT 1 FROM site_user_state hz WHERE hz.user_id = p.user_id AND hz.hidden = 1)
    AND EXISTS (SELECT 1 FROM (WITH RECURSIVE up(site_id) AS (SELECT s0.id FROM asset_usernames aa
  JOIN usernames ac ON ac.id = aa.username_id JOIN sites s0 ON s0.id = ac.site_id
  WHERE aa.asset_id = p.asset_id
  UNION SELECT s.parent_id FROM up JOIN sites s ON s.id = up.site_id WHERE s.parent_id IS NOT NULL)
SELECT site_id FROM up) up JOIN site_user_state hl ON hl.site_id = up.site_id
                 WHERE hl.user_id = p.user_id AND hl.hidden = 1))
OR EXISTS (SELECT 1 FROM photo_set_items vp
            JOIN photo_set_user_state hs ON hs.photo_set_id = vp.photo_set_id
           WHERE vp.asset_id = p.asset_id AND hs.user_id = p.user_id AND hs.hidden = 1)
OR EXISTS (SELECT 1 FROM song_files vs
            JOIN song_user_state hg ON hg.song_id = vs.song_id
           WHERE vs.asset_id = p.asset_id AND hg.user_id = p.user_id AND hg.hidden = 1) THEN 1 ELSE 0 END AS lv
          FROM (SELECT user_id, asset_id FROM visibility_pending) p
          JOIN users u ON u.id = p.user_id
         WHERE EXISTS (SELECT 1 FROM asset_locations al WHERE al.asset_id = p.asset_id)
         LIMIT -1) x
 WHERE x.role = 'admin'
    OR CASE WHEN (x.lo & 2) = 2 THEN 0
            WHEN (x.it & 2) = 2 THEN 0
            WHEN (x.ph & 4) = 4 THEN 0
            WHEN (x.it & 1) = 1 THEN 1
            WHEN (x.ph & 2) = 2 OR (x.lo & 1) = 1 THEN 1
            ELSE 0 END = 1;
DELETE FROM visibility_places;
DELETE FROM visibility_pending;
END;
CREATE TRIGGER vis_recompute_owe INSTEAD OF INSERT ON visibility_step_owe BEGIN
UPDATE visibility_owed SET owed = 1 WHERE asset_id IN (SELECT asset_id FROM visibility_pending);
END;
CREATE TRIGGER vis_recompute_fold INSTEAD OF INSERT ON visibility_step_fold BEGIN
INSERT INTO visibility_moved (asset_id, user_id, dn, dc, read, size, time) SELECT o.asset_id, o.user_id, (v.asset_id IS NOT NULL) - (o.concealed IS NOT NULL), COALESCE(v.concealed, 0) - COALESCE(o.concealed, 0), EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = o.asset_id AND r.side = 0), COALESCE(a.size_bytes, 0), COALESCE(a.duration_ms, 0) FROM visibility_owed o LEFT JOIN viewer_assets v ON v.user_id = o.user_id AND v.asset_id = o.asset_id LEFT JOIN assets a ON a.id = o.asset_id WHERE o.asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0) AND o.concealed IS NOT v.concealed;
INSERT INTO visibility_members (asset_id, side, kind, object_id, n, bytes, ms) SELECT asset_id, 0, kind, object_id, n, bytes, ms FROM (SELECT a.id AS asset_id, '' AS kind, '' AS object_id, 1 AS n, COALESCE(a.size_bytes, 0) AS bytes, COALESCE(a.duration_ms, 0) AS ms FROM assets a WHERE a.id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = a.id AND r.side = 0 AND r.kind = '#') UNION ALL SELECT m.asset_id, 'tag' AS kind, m.tag_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_tags m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#tag') GROUP BY m.asset_id, m.tag_id UNION ALL SELECT m.asset_id, 'person' AS kind, m.person_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_people m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#person') GROUP BY m.asset_id, m.person_id UNION ALL SELECT m.asset_id, 'collection' AS kind, m.collection_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM collection_items m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#collection') GROUP BY m.asset_id, m.collection_id UNION ALL SELECT m.asset_id, 'photo_set' AS kind, m.photo_set_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM photo_set_items m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#photo_set') GROUP BY m.asset_id, m.photo_set_id UNION ALL SELECT m.asset_id, 'song' AS kind, m.song_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM song_files m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#song') GROUP BY m.asset_id, m.song_id UNION ALL SELECT m.asset_id, 'username' AS kind, m.username_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_usernames m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#username') GROUP BY m.asset_id, m.username_id UNION ALL SELECT m.asset_id, 'loop' AS kind, m.id AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM loops m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#loop') GROUP BY m.asset_id, m.id UNION ALL SELECT m.asset_id, 'folder' AS kind, m.folder_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM (SELECT l.asset_id, an.ancestor_id AS folder_id   FROM asset_locations l JOIN folder_ancestry an ON an.folder_id = l.folder_id  WHERE l.status = 'present') m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.folder_id UNION ALL SELECT m.asset_id, 'media' AS kind, m.media_type AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM (SELECT ma.id AS asset_id, ma.media_type FROM assets ma) m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.media_type UNION ALL SELECT m.asset_id, 'place' AS kind, m.folder_name AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT pl.asset_id, pf.name AS folder_name FROM asset_locations pl JOIN folders pf ON pf.id = pl.folder_id) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.folder_name UNION ALL SELECT m.asset_id, 'has_tags' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM asset_tags hm) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_people' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM asset_people hm) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_sites' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM asset_usernames hm) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_collections' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM collection_items hm) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_photo_sets' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM photo_set_items hm) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_songs' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM song_files hm) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'site' AS kind, m.site_id AS object_id, 1 AS n, COALESCE(MAX(a.size_bytes), 0) * 1 AS bytes, COALESCE(MAX(a.duration_ms), 0) * 1 AS ms FROM (SELECT aa.asset_id, reach.ancestor_id AS site_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id) m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.site_id UNION ALL SELECT m.asset_id, 'pile' AS kind, m.pile_id AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, pile_id FROM face_tracks WHERE person_id IS NULL AND pile_id IS NOT NULL) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#pile') GROUP BY m.asset_id, m.pile_id UNION ALL SELECT m.asset_id, 'face_band' AS kind, m.band AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, person_id || ':' || COALESCE(attribution, '') AS band FROM face_tracks WHERE person_id IS NOT NULL) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#face_band') GROUP BY m.asset_id, m.band UNION ALL SELECT m.asset_id, 'music_waiting' AS kind, m.scope AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, 'library' AS scope FROM music_waiting) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#music_waiting') GROUP BY m.asset_id, m.scope UNION ALL SELECT a.id, k.column1, '', 0, 0, 0 FROM assets a CROSS JOIN (VALUES ('#'), ('#tag'), ('#person'), ('#collection'), ('#photo_set'), ('#song'), ('#username'), ('#loop'), ('#pile'), ('#face_band'), ('#music_waiting')) k WHERE a.id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = a.id AND r.side = 0 AND r.kind = k.column1));
INSERT INTO visibility_members (asset_id, side, kind, object_id, n, bytes, ms) SELECT asset_id, 1, kind, object_id, n, bytes, ms FROM (SELECT a.id AS asset_id, '' AS kind, '' AS object_id, 1 AS n, COALESCE(a.size_bytes, 0) AS bytes, COALESCE(a.duration_ms, 0) AS ms FROM assets a WHERE a.id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = a.id AND r.side = 0 AND r.kind = '#') UNION ALL SELECT m.asset_id, 'tag' AS kind, m.tag_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_tags m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#tag') GROUP BY m.asset_id, m.tag_id UNION ALL SELECT m.asset_id, 'person' AS kind, m.person_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_people m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#person') GROUP BY m.asset_id, m.person_id UNION ALL SELECT m.asset_id, 'collection' AS kind, m.collection_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM collection_items m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#collection') GROUP BY m.asset_id, m.collection_id UNION ALL SELECT m.asset_id, 'photo_set' AS kind, m.photo_set_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM photo_set_items m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#photo_set') GROUP BY m.asset_id, m.photo_set_id UNION ALL SELECT m.asset_id, 'song' AS kind, m.song_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM song_files m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#song') GROUP BY m.asset_id, m.song_id UNION ALL SELECT m.asset_id, 'username' AS kind, m.username_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_usernames m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#username') GROUP BY m.asset_id, m.username_id UNION ALL SELECT m.asset_id, 'loop' AS kind, m.id AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM loops m WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#loop') GROUP BY m.asset_id, m.id UNION ALL SELECT m.asset_id, 'folder' AS kind, m.folder_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM (SELECT l.asset_id, an.ancestor_id AS folder_id   FROM asset_locations l JOIN folder_ancestry an ON an.folder_id = l.folder_id  WHERE l.status = 'present') m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.folder_id UNION ALL SELECT m.asset_id, 'media' AS kind, m.media_type AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM (SELECT ma.id AS asset_id, ma.media_type FROM assets ma) m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.media_type UNION ALL SELECT m.asset_id, 'place' AS kind, m.folder_name AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT pl.asset_id, pf.name AS folder_name FROM asset_locations pl JOIN folders pf ON pf.id = pl.folder_id) m WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.folder_name UNION ALL SELECT m.asset_id, 'has_tags' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM asset_tags hm) m WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_people' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM asset_people hm) m WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_sites' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM asset_usernames hm) m WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_collections' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM collection_items hm) m WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_photo_sets' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM photo_set_items hm) m WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_songs' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM song_files hm) m WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'site' AS kind, m.site_id AS object_id, 1 AS n, COALESCE(MAX(a.size_bytes), 0) * 1 AS bytes, COALESCE(MAX(a.duration_ms), 0) * 1 AS ms FROM (SELECT aa.asset_id, reach.ancestor_id AS site_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id) m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.site_id UNION ALL SELECT m.asset_id, 'pile' AS kind, m.pile_id AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, pile_id FROM face_tracks WHERE person_id IS NULL AND pile_id IS NOT NULL) m WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#pile') GROUP BY m.asset_id, m.pile_id UNION ALL SELECT m.asset_id, 'face_band' AS kind, m.band AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, person_id || ':' || COALESCE(attribution, '') AS band FROM face_tracks WHERE person_id IS NOT NULL) m WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#face_band') GROUP BY m.asset_id, m.band UNION ALL SELECT m.asset_id, 'music_waiting' AS kind, m.scope AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, 'library' AS scope FROM music_waiting) m WHERE m.asset_id IN (SELECT DISTINCT asset_id FROM visibility_members WHERE side = 0 AND +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0)) AND EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#music_waiting') GROUP BY m.asset_id, m.scope);
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, d.kind, d.object_id, SUM(d.n), SUM(d.c), SUM(d.b), SUM(d.cb), SUM(d.ms), SUM(d.cms) FROM (SELECT o.user_id, m.kind, m.object_id, -m.n AS n, -m.n * o.concealed AS c, -m.bytes AS b, -m.bytes * o.concealed AS cb, -m.ms AS ms, -m.ms * o.concealed AS cms FROM (SELECT 1 FROM visibility_members LIMIT 1) g CROSS JOIN visibility_owed o JOIN visibility_members m ON m.asset_id = o.asset_id AND m.side = 0 WHERE o.asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0) AND o.concealed IS NOT NULL AND m.n != 0 AND m.kind != '' UNION ALL SELECT o.user_id, m.kind, m.object_id, m.n, m.n * v.concealed, m.bytes, m.bytes * v.concealed, m.ms, m.ms * v.concealed FROM (SELECT 1 FROM visibility_members LIMIT 1) g CROSS JOIN visibility_owed o CROSS JOIN viewer_assets v ON v.user_id = o.user_id AND v.asset_id = o.asset_id JOIN visibility_members m ON m.asset_id = o.asset_id AND m.side = 1 WHERE o.asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0) AND m.n != 0 AND m.kind != '') d WHERE 1 = 1 GROUP BY d.user_id, d.kind, d.object_id HAVING SUM(d.n) != 0 OR SUM(d.c) != 0 OR SUM(d.b) != 0 OR SUM(d.cb) != 0 OR SUM(d.ms) != 0 OR SUM(d.cms) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, d.kind_a, d.id_a, d.kind_b, d.id_b, SUM(d.n), SUM(d.c) FROM (SELECT o.user_id, a.kind AS kind_a, a.object_id AS id_a, b.kind AS kind_b, b.object_id AS id_b, -a.n * b.n AS n, -a.n * b.n * o.concealed AS c FROM (SELECT 1 FROM visibility_members LIMIT 1) g CROSS JOIN visibility_owed o JOIN visibility_members a ON a.asset_id = o.asset_id AND a.side = 0 JOIN visibility_members b ON b.asset_id = o.asset_id AND b.side = 0 WHERE o.asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0) AND o.concealed IS NOT NULL AND (a.kind, b.kind) IN (('person', 'photo_set'), ('person', 'tag'), ('person', 'collection'), ('person', 'username'), ('tag', 'photo_set'), ('tag', 'collection'), ('tag', 'username'), ('collection', 'username'), ('photo_set', 'username'), ('person', 'song'), ('tag', 'song'), ('song', 'username'), ('collection', 'song'), ('song', 'loop'), ('person', 'loop'), ('tag', 'loop'), ('collection', 'loop'), ('username', 'loop')) UNION ALL SELECT o.user_id, a.kind, a.object_id, b.kind, b.object_id, a.n * b.n, a.n * b.n * v.concealed FROM (SELECT 1 FROM visibility_members LIMIT 1) g CROSS JOIN visibility_owed o CROSS JOIN viewer_assets v ON v.user_id = o.user_id AND v.asset_id = o.asset_id JOIN visibility_members a ON a.asset_id = o.asset_id AND a.side = 1 JOIN visibility_members b ON b.asset_id = o.asset_id AND b.side = 1 WHERE o.asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0) AND (a.kind, b.kind) IN (('person', 'photo_set'), ('person', 'tag'), ('person', 'collection'), ('person', 'username'), ('tag', 'photo_set'), ('tag', 'collection'), ('tag', 'username'), ('collection', 'username'), ('photo_set', 'username'), ('person', 'song'), ('tag', 'song'), ('song', 'username'), ('collection', 'song'), ('song', 'loop'), ('person', 'loop'), ('tag', 'loop'), ('collection', 'loop'), ('username', 'loop'))) d WHERE 1 = 1 GROUP BY d.user_id, d.kind_a, d.id_a, d.kind_b, d.id_b HAVING SUM(d.n) != 0 OR SUM(d.c) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_stats (user_id, permitted, concealed, permitted_bytes, concealed_bytes) SELECT d.user_id, SUM(d.n), SUM(d.c), SUM(d.b), SUM(d.cb) FROM (SELECT o.user_id, m.kind, m.object_id, -m.n AS n, -m.n * o.concealed AS c, -m.bytes AS b, -m.bytes * o.concealed AS cb, -m.ms AS ms, -m.ms * o.concealed AS cms FROM (SELECT 1 FROM visibility_members LIMIT 1) g CROSS JOIN visibility_owed o JOIN visibility_members m ON m.asset_id = o.asset_id AND m.side = 0 WHERE o.asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0) AND o.concealed IS NOT NULL AND m.n != 0 AND m.kind = '' UNION ALL SELECT o.user_id, m.kind, m.object_id, m.n, m.n * v.concealed, m.bytes, m.bytes * v.concealed, m.ms, m.ms * v.concealed FROM (SELECT 1 FROM visibility_members LIMIT 1) g CROSS JOIN visibility_owed o CROSS JOIN viewer_assets v ON v.user_id = o.user_id AND v.asset_id = o.asset_id JOIN visibility_members m ON m.asset_id = o.asset_id AND m.side = 1 WHERE o.asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0) AND m.n != 0 AND m.kind = '') d WHERE 1 = 1 GROUP BY d.user_id HAVING SUM(d.n) != 0 OR SUM(d.c) != 0 OR SUM(d.b) != 0 OR SUM(d.cb) != 0 ON CONFLICT (user_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes;
DELETE FROM visibility_moved WHERE read = 1;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'tag', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.tag_id AS object_id FROM visibility_moved d CROSS JOIN asset_tags m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'person', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.person_id AS object_id FROM visibility_moved d CROSS JOIN asset_people m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'collection', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.collection_id AS object_id FROM visibility_moved d CROSS JOIN collection_items m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'photo_set', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.photo_set_id AS object_id FROM visibility_moved d CROSS JOIN photo_set_items m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'song', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.song_id AS object_id FROM visibility_moved d CROSS JOIN song_files m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'username', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.username_id AS object_id FROM visibility_moved d CROSS JOIN asset_usernames m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'loop', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.id AS object_id FROM visibility_moved d CROSS JOIN loops m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'folder', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.folder_id AS object_id FROM visibility_moved d CROSS JOIN (SELECT l.asset_id, an.ancestor_id AS folder_id   FROM asset_locations l JOIN folder_ancestry an ON an.folder_id = l.folder_id  WHERE l.status = 'present') m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'media', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.media_type AS object_id FROM visibility_moved d CROSS JOIN (SELECT ma.id AS asset_id, ma.media_type FROM assets ma) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'place', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.folder_name AS object_id FROM visibility_moved d CROSS JOIN (SELECT pl.asset_id, pf.name AS folder_name FROM asset_locations pl JOIN folders pf ON pf.id = pl.folder_id) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'has_tags', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.present AS object_id FROM visibility_moved d CROSS JOIN (SELECT hm.asset_id, 'any' AS present FROM asset_tags hm) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'has_people', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.present AS object_id FROM visibility_moved d CROSS JOIN (SELECT hm.asset_id, 'any' AS present FROM asset_people hm) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'has_sites', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.present AS object_id FROM visibility_moved d CROSS JOIN (SELECT hm.asset_id, 'any' AS present FROM asset_usernames hm) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'has_collections', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.present AS object_id FROM visibility_moved d CROSS JOIN (SELECT hm.asset_id, 'any' AS present FROM collection_items hm) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'has_photo_sets', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.present AS object_id FROM visibility_moved d CROSS JOIN (SELECT hm.asset_id, 'any' AS present FROM photo_set_items hm) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'has_songs', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.present AS object_id FROM visibility_moved d CROSS JOIN (SELECT hm.asset_id, 'any' AS present FROM song_files hm) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'site', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.site_id AS object_id FROM visibility_moved d CROSS JOIN (SELECT aa.asset_id, reach.ancestor_id AS site_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'pile', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.pile_id AS object_id FROM visibility_moved d CROSS JOIN (SELECT asset_id, pile_id FROM face_tracks WHERE person_id IS NULL AND pile_id IS NOT NULL) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'face_band', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.band AS object_id FROM visibility_moved d CROSS JOIN (SELECT asset_id, person_id || ':' || COALESCE(attribution, '') AS band FROM face_tracks WHERE person_id IS NOT NULL) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'music_waiting', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.scope AS object_id FROM visibility_moved d CROSS JOIN (SELECT asset_id, 'library' AS scope FROM music_waiting) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'person', ma.person_id, 'photo_set', mb.photo_set_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_people ma ON ma.asset_id = d.asset_id CROSS JOIN photo_set_items mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.person_id, mb.photo_set_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'person', ma.person_id, 'tag', mb.tag_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_people ma ON ma.asset_id = d.asset_id CROSS JOIN asset_tags mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.person_id, mb.tag_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'person', ma.person_id, 'collection', mb.collection_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_people ma ON ma.asset_id = d.asset_id CROSS JOIN collection_items mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.person_id, mb.collection_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'person', ma.person_id, 'username', mb.username_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_people ma ON ma.asset_id = d.asset_id CROSS JOIN asset_usernames mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.person_id, mb.username_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'tag', ma.tag_id, 'photo_set', mb.photo_set_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_tags ma ON ma.asset_id = d.asset_id CROSS JOIN photo_set_items mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.tag_id, mb.photo_set_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'tag', ma.tag_id, 'collection', mb.collection_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_tags ma ON ma.asset_id = d.asset_id CROSS JOIN collection_items mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.tag_id, mb.collection_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'tag', ma.tag_id, 'username', mb.username_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_tags ma ON ma.asset_id = d.asset_id CROSS JOIN asset_usernames mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.tag_id, mb.username_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'collection', ma.collection_id, 'username', mb.username_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN collection_items ma ON ma.asset_id = d.asset_id CROSS JOIN asset_usernames mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.collection_id, mb.username_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'photo_set', ma.photo_set_id, 'username', mb.username_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN photo_set_items ma ON ma.asset_id = d.asset_id CROSS JOIN asset_usernames mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.photo_set_id, mb.username_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'person', ma.person_id, 'song', mb.song_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_people ma ON ma.asset_id = d.asset_id CROSS JOIN song_files mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.person_id, mb.song_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'tag', ma.tag_id, 'song', mb.song_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_tags ma ON ma.asset_id = d.asset_id CROSS JOIN song_files mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.tag_id, mb.song_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'song', ma.song_id, 'username', mb.username_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN song_files ma ON ma.asset_id = d.asset_id CROSS JOIN asset_usernames mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.song_id, mb.username_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'collection', ma.collection_id, 'song', mb.song_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN collection_items ma ON ma.asset_id = d.asset_id CROSS JOIN song_files mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.collection_id, mb.song_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'song', ma.song_id, 'loop', mb.id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN song_files ma ON ma.asset_id = d.asset_id CROSS JOIN loops mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.song_id, mb.id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'person', ma.person_id, 'loop', mb.id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_people ma ON ma.asset_id = d.asset_id CROSS JOIN loops mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.person_id, mb.id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'tag', ma.tag_id, 'loop', mb.id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_tags ma ON ma.asset_id = d.asset_id CROSS JOIN loops mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.tag_id, mb.id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'collection', ma.collection_id, 'loop', mb.id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN collection_items ma ON ma.asset_id = d.asset_id CROSS JOIN loops mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.collection_id, mb.id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'username', ma.username_id, 'loop', mb.id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_usernames ma ON ma.asset_id = d.asset_id CROSS JOIN loops mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.username_id, mb.id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_stats (user_id, permitted, concealed, permitted_bytes, concealed_bytes) SELECT d.user_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size) FROM visibility_moved d WHERE 1 = 1 GROUP BY d.user_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 ON CONFLICT (user_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes;
DELETE FROM visibility_moved;
DELETE FROM visibility_members WHERE +asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0);
DELETE FROM visibility_owed WHERE asset_id IN (SELECT asset_id FROM visibility_owed WHERE owed = 0);
END;
CREATE TRIGGER vis_recompute_fold_page INSTEAD OF INSERT ON visibility_step_fold_page BEGIN
INSERT INTO visibility_step_fold (user_id) VALUES (NULL);
END;
CREATE TRIGGER vis_recompute_going INSTEAD OF INSERT ON visibility_step_going BEGIN
DELETE FROM viewer_assets WHERE (user_id, asset_id) IN (SELECT user_id, asset_id FROM visibility_pending);
INSERT INTO visibility_moved (asset_id, user_id, dn, dc, read, size, time) SELECT o.asset_id, o.user_id, (v.asset_id IS NOT NULL) - (o.concealed IS NOT NULL), COALESCE(v.concealed, 0) - COALESCE(o.concealed, 0), EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = o.asset_id AND r.side = 0), COALESCE(a.size_bytes, 0), COALESCE(a.duration_ms, 0) FROM visibility_owed o LEFT JOIN viewer_assets v ON v.user_id = o.user_id AND v.asset_id = o.asset_id LEFT JOIN assets a ON a.id = o.asset_id WHERE o.asset_id IN (SELECT asset_id FROM visibility_pending) AND o.concealed IS NOT v.concealed;
INSERT INTO visibility_members (asset_id, side, kind, object_id, n, bytes, ms) SELECT asset_id, 0, kind, object_id, n, bytes, ms FROM (SELECT a.id AS asset_id, '' AS kind, '' AS object_id, 1 AS n, COALESCE(a.size_bytes, 0) AS bytes, COALESCE(a.duration_ms, 0) AS ms FROM assets a WHERE a.id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = a.id AND r.side = 0 AND r.kind = '#') UNION ALL SELECT m.asset_id, 'tag' AS kind, m.tag_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_tags m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#tag') GROUP BY m.asset_id, m.tag_id UNION ALL SELECT m.asset_id, 'person' AS kind, m.person_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_people m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#person') GROUP BY m.asset_id, m.person_id UNION ALL SELECT m.asset_id, 'collection' AS kind, m.collection_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM collection_items m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#collection') GROUP BY m.asset_id, m.collection_id UNION ALL SELECT m.asset_id, 'photo_set' AS kind, m.photo_set_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM photo_set_items m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#photo_set') GROUP BY m.asset_id, m.photo_set_id UNION ALL SELECT m.asset_id, 'song' AS kind, m.song_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM song_files m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#song') GROUP BY m.asset_id, m.song_id UNION ALL SELECT m.asset_id, 'username' AS kind, m.username_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM asset_usernames m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#username') GROUP BY m.asset_id, m.username_id UNION ALL SELECT m.asset_id, 'loop' AS kind, m.id AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM loops m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#loop') GROUP BY m.asset_id, m.id UNION ALL SELECT m.asset_id, 'folder' AS kind, m.folder_id AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM (SELECT l.asset_id, an.ancestor_id AS folder_id   FROM asset_locations l JOIN folder_ancestry an ON an.folder_id = l.folder_id  WHERE l.status = 'present') m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.folder_id UNION ALL SELECT m.asset_id, 'media' AS kind, m.media_type AS object_id, COUNT(*) AS n, COALESCE(MAX(a.size_bytes), 0) * COUNT(*) AS bytes, COALESCE(MAX(a.duration_ms), 0) * COUNT(*) AS ms FROM (SELECT ma.id AS asset_id, ma.media_type FROM assets ma) m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.media_type UNION ALL SELECT m.asset_id, 'place' AS kind, m.folder_name AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT pl.asset_id, pf.name AS folder_name FROM asset_locations pl JOIN folders pf ON pf.id = pl.folder_id) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.folder_name UNION ALL SELECT m.asset_id, 'has_tags' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM asset_tags hm) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_people' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM asset_people hm) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_sites' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM asset_usernames hm) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_collections' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM collection_items hm) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_photo_sets' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM photo_set_items hm) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'has_songs' AS kind, m.present AS object_id, 1 AS n, 0 AS bytes, 0 AS ms FROM (SELECT hm.asset_id, 'any' AS present FROM song_files hm) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.present UNION ALL SELECT m.asset_id, 'site' AS kind, m.site_id AS object_id, 1 AS n, COALESCE(MAX(a.size_bytes), 0) * 1 AS bytes, COALESCE(MAX(a.duration_ms), 0) * 1 AS ms FROM (SELECT aa.asset_id, reach.ancestor_id AS site_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id) m CROSS JOIN assets a ON a.id = m.asset_id WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#') GROUP BY m.asset_id, m.site_id UNION ALL SELECT m.asset_id, 'pile' AS kind, m.pile_id AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, pile_id FROM face_tracks WHERE person_id IS NULL AND pile_id IS NOT NULL) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#pile') GROUP BY m.asset_id, m.pile_id UNION ALL SELECT m.asset_id, 'face_band' AS kind, m.band AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, person_id || ':' || COALESCE(attribution, '') AS band FROM face_tracks WHERE person_id IS NOT NULL) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#face_band') GROUP BY m.asset_id, m.band UNION ALL SELECT m.asset_id, 'music_waiting' AS kind, m.scope AS object_id, COUNT(*) AS n, 0 AS bytes, 0 AS ms FROM (SELECT asset_id, 'library' AS scope FROM music_waiting) m WHERE m.asset_id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = m.asset_id AND r.side = 0 AND r.kind = '#music_waiting') GROUP BY m.asset_id, m.scope UNION ALL SELECT a.id, k.column1, '', 0, 0, 0 FROM assets a CROSS JOIN (VALUES ('#'), ('#tag'), ('#person'), ('#collection'), ('#photo_set'), ('#song'), ('#username'), ('#loop'), ('#pile'), ('#face_band'), ('#music_waiting')) k WHERE a.id IN (SELECT asset_id FROM visibility_moved WHERE read = 1) AND NOT EXISTS (SELECT 1 FROM visibility_members r WHERE r.asset_id = a.id AND r.side = 0 AND r.kind = k.column1));
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, d.kind, d.object_id, SUM(d.n), SUM(d.c), SUM(d.b), SUM(d.cb), SUM(d.ms), SUM(d.cms) FROM (SELECT o.user_id, m.kind, m.object_id, -m.n AS n, -m.n * o.concealed AS c, -m.bytes AS b, -m.bytes * o.concealed AS cb, -m.ms AS ms, -m.ms * o.concealed AS cms FROM (SELECT 1 FROM visibility_members LIMIT 1) g CROSS JOIN visibility_owed o JOIN visibility_members m ON m.asset_id = o.asset_id AND m.side = 0 WHERE o.asset_id IN (SELECT asset_id FROM visibility_pending) AND o.concealed IS NOT NULL AND m.n != 0 AND m.kind != '' UNION ALL SELECT o.user_id, m.kind, m.object_id, m.n, m.n * v.concealed, m.bytes, m.bytes * v.concealed, m.ms, m.ms * v.concealed FROM (SELECT 1 FROM visibility_members LIMIT 1) g CROSS JOIN visibility_owed o CROSS JOIN viewer_assets v ON v.user_id = o.user_id AND v.asset_id = o.asset_id JOIN visibility_members m ON m.asset_id = o.asset_id AND m.side = 1 WHERE o.asset_id IN (SELECT asset_id FROM visibility_pending) AND m.n != 0 AND m.kind != '') d WHERE 1 = 1 GROUP BY d.user_id, d.kind, d.object_id HAVING SUM(d.n) != 0 OR SUM(d.c) != 0 OR SUM(d.b) != 0 OR SUM(d.cb) != 0 OR SUM(d.ms) != 0 OR SUM(d.cms) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, d.kind_a, d.id_a, d.kind_b, d.id_b, SUM(d.n), SUM(d.c) FROM (SELECT o.user_id, a.kind AS kind_a, a.object_id AS id_a, b.kind AS kind_b, b.object_id AS id_b, -a.n * b.n AS n, -a.n * b.n * o.concealed AS c FROM (SELECT 1 FROM visibility_members LIMIT 1) g CROSS JOIN visibility_owed o JOIN visibility_members a ON a.asset_id = o.asset_id AND a.side = 0 JOIN visibility_members b ON b.asset_id = o.asset_id AND b.side = 0 WHERE o.asset_id IN (SELECT asset_id FROM visibility_pending) AND o.concealed IS NOT NULL AND (a.kind, b.kind) IN (('person', 'photo_set'), ('person', 'tag'), ('person', 'collection'), ('person', 'username'), ('tag', 'photo_set'), ('tag', 'collection'), ('tag', 'username'), ('collection', 'username'), ('photo_set', 'username'), ('person', 'song'), ('tag', 'song'), ('song', 'username'), ('collection', 'song'), ('song', 'loop'), ('person', 'loop'), ('tag', 'loop'), ('collection', 'loop'), ('username', 'loop')) UNION ALL SELECT o.user_id, a.kind, a.object_id, b.kind, b.object_id, a.n * b.n, a.n * b.n * v.concealed FROM (SELECT 1 FROM visibility_members LIMIT 1) g CROSS JOIN visibility_owed o CROSS JOIN viewer_assets v ON v.user_id = o.user_id AND v.asset_id = o.asset_id JOIN visibility_members a ON a.asset_id = o.asset_id AND a.side = 1 JOIN visibility_members b ON b.asset_id = o.asset_id AND b.side = 1 WHERE o.asset_id IN (SELECT asset_id FROM visibility_pending) AND (a.kind, b.kind) IN (('person', 'photo_set'), ('person', 'tag'), ('person', 'collection'), ('person', 'username'), ('tag', 'photo_set'), ('tag', 'collection'), ('tag', 'username'), ('collection', 'username'), ('photo_set', 'username'), ('person', 'song'), ('tag', 'song'), ('song', 'username'), ('collection', 'song'), ('song', 'loop'), ('person', 'loop'), ('tag', 'loop'), ('collection', 'loop'), ('username', 'loop'))) d WHERE 1 = 1 GROUP BY d.user_id, d.kind_a, d.id_a, d.kind_b, d.id_b HAVING SUM(d.n) != 0 OR SUM(d.c) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_stats (user_id, permitted, concealed, permitted_bytes, concealed_bytes) SELECT d.user_id, SUM(d.n), SUM(d.c), SUM(d.b), SUM(d.cb) FROM (SELECT o.user_id, m.kind, m.object_id, -m.n AS n, -m.n * o.concealed AS c, -m.bytes AS b, -m.bytes * o.concealed AS cb, -m.ms AS ms, -m.ms * o.concealed AS cms FROM (SELECT 1 FROM visibility_members LIMIT 1) g CROSS JOIN visibility_owed o JOIN visibility_members m ON m.asset_id = o.asset_id AND m.side = 0 WHERE o.asset_id IN (SELECT asset_id FROM visibility_pending) AND o.concealed IS NOT NULL AND m.n != 0 AND m.kind = '' UNION ALL SELECT o.user_id, m.kind, m.object_id, m.n, m.n * v.concealed, m.bytes, m.bytes * v.concealed, m.ms, m.ms * v.concealed FROM (SELECT 1 FROM visibility_members LIMIT 1) g CROSS JOIN visibility_owed o CROSS JOIN viewer_assets v ON v.user_id = o.user_id AND v.asset_id = o.asset_id JOIN visibility_members m ON m.asset_id = o.asset_id AND m.side = 1 WHERE o.asset_id IN (SELECT asset_id FROM visibility_pending) AND m.n != 0 AND m.kind = '') d WHERE 1 = 1 GROUP BY d.user_id HAVING SUM(d.n) != 0 OR SUM(d.c) != 0 OR SUM(d.b) != 0 OR SUM(d.cb) != 0 ON CONFLICT (user_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes;
DELETE FROM visibility_moved WHERE read = 1;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'tag', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.tag_id AS object_id FROM visibility_moved d CROSS JOIN asset_tags m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'person', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.person_id AS object_id FROM visibility_moved d CROSS JOIN asset_people m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'collection', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.collection_id AS object_id FROM visibility_moved d CROSS JOIN collection_items m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'photo_set', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.photo_set_id AS object_id FROM visibility_moved d CROSS JOIN photo_set_items m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'song', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.song_id AS object_id FROM visibility_moved d CROSS JOIN song_files m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'username', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.username_id AS object_id FROM visibility_moved d CROSS JOIN asset_usernames m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'loop', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.id AS object_id FROM visibility_moved d CROSS JOIN loops m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'folder', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.folder_id AS object_id FROM visibility_moved d CROSS JOIN (SELECT l.asset_id, an.ancestor_id AS folder_id   FROM asset_locations l JOIN folder_ancestry an ON an.folder_id = l.folder_id  WHERE l.status = 'present') m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'media', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.media_type AS object_id FROM visibility_moved d CROSS JOIN (SELECT ma.id AS asset_id, ma.media_type FROM assets ma) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'place', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.folder_name AS object_id FROM visibility_moved d CROSS JOIN (SELECT pl.asset_id, pf.name AS folder_name FROM asset_locations pl JOIN folders pf ON pf.id = pl.folder_id) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'has_tags', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.present AS object_id FROM visibility_moved d CROSS JOIN (SELECT hm.asset_id, 'any' AS present FROM asset_tags hm) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'has_people', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.present AS object_id FROM visibility_moved d CROSS JOIN (SELECT hm.asset_id, 'any' AS present FROM asset_people hm) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'has_sites', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.present AS object_id FROM visibility_moved d CROSS JOIN (SELECT hm.asset_id, 'any' AS present FROM asset_usernames hm) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'has_collections', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.present AS object_id FROM visibility_moved d CROSS JOIN (SELECT hm.asset_id, 'any' AS present FROM collection_items hm) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'has_photo_sets', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.present AS object_id FROM visibility_moved d CROSS JOIN (SELECT hm.asset_id, 'any' AS present FROM photo_set_items hm) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'has_songs', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.present AS object_id FROM visibility_moved d CROSS JOIN (SELECT hm.asset_id, 'any' AS present FROM song_files hm) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'site', d.object_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size), SUM(d.dn * d.time), SUM(d.dc * d.time) FROM (SELECT DISTINCT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.site_id AS object_id FROM visibility_moved d CROSS JOIN (SELECT aa.asset_id, reach.ancestor_id AS site_id FROM asset_usernames aa JOIN usernames ac ON ac.id = aa.username_id JOIN (WITH RECURSIVE reach_up(site_id, ancestor_id) AS (SELECT id, id FROM sites UNION SELECT r.site_id, p.parent_id FROM reach_up r JOIN sites p ON p.id = r.ancestor_id WHERE p.parent_id IS NOT NULL) SELECT site_id, ancestor_id FROM reach_up) reach ON reach.site_id = ac.site_id) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 OR SUM(d.dn * d.time) != 0 OR SUM(d.dc * d.time) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'pile', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.pile_id AS object_id FROM visibility_moved d CROSS JOIN (SELECT asset_id, pile_id FROM face_tracks WHERE person_id IS NULL AND pile_id IS NOT NULL) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'face_band', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.band AS object_id FROM visibility_moved d CROSS JOIN (SELECT asset_id, person_id || ':' || COALESCE(attribution, '') AS band FROM face_tracks WHERE person_id IS NOT NULL) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_entity_counts (user_id, kind, object_id, permitted, concealed, permitted_bytes, concealed_bytes, permitted_ms, concealed_ms) SELECT d.user_id, 'music_waiting', d.object_id, SUM(d.dn), SUM(d.dc), 0, 0, 0, 0 FROM (SELECT d.user_id, d.asset_id, d.dn, d.dc, d.size, d.time, m.scope AS object_id FROM visibility_moved d CROSS JOIN (SELECT asset_id, 'library' AS scope FROM music_waiting) m ON m.asset_id = d.asset_id) d WHERE 1 = 1 GROUP BY d.user_id, d.object_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind, object_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes, permitted_ms = permitted_ms + excluded.permitted_ms, concealed_ms = concealed_ms + excluded.concealed_ms;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'person', ma.person_id, 'photo_set', mb.photo_set_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_people ma ON ma.asset_id = d.asset_id CROSS JOIN photo_set_items mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.person_id, mb.photo_set_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'person', ma.person_id, 'tag', mb.tag_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_people ma ON ma.asset_id = d.asset_id CROSS JOIN asset_tags mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.person_id, mb.tag_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'person', ma.person_id, 'collection', mb.collection_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_people ma ON ma.asset_id = d.asset_id CROSS JOIN collection_items mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.person_id, mb.collection_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'person', ma.person_id, 'username', mb.username_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_people ma ON ma.asset_id = d.asset_id CROSS JOIN asset_usernames mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.person_id, mb.username_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'tag', ma.tag_id, 'photo_set', mb.photo_set_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_tags ma ON ma.asset_id = d.asset_id CROSS JOIN photo_set_items mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.tag_id, mb.photo_set_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'tag', ma.tag_id, 'collection', mb.collection_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_tags ma ON ma.asset_id = d.asset_id CROSS JOIN collection_items mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.tag_id, mb.collection_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'tag', ma.tag_id, 'username', mb.username_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_tags ma ON ma.asset_id = d.asset_id CROSS JOIN asset_usernames mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.tag_id, mb.username_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'collection', ma.collection_id, 'username', mb.username_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN collection_items ma ON ma.asset_id = d.asset_id CROSS JOIN asset_usernames mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.collection_id, mb.username_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'photo_set', ma.photo_set_id, 'username', mb.username_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN photo_set_items ma ON ma.asset_id = d.asset_id CROSS JOIN asset_usernames mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.photo_set_id, mb.username_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'person', ma.person_id, 'song', mb.song_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_people ma ON ma.asset_id = d.asset_id CROSS JOIN song_files mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.person_id, mb.song_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'tag', ma.tag_id, 'song', mb.song_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_tags ma ON ma.asset_id = d.asset_id CROSS JOIN song_files mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.tag_id, mb.song_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'song', ma.song_id, 'username', mb.username_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN song_files ma ON ma.asset_id = d.asset_id CROSS JOIN asset_usernames mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.song_id, mb.username_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'collection', ma.collection_id, 'song', mb.song_id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN collection_items ma ON ma.asset_id = d.asset_id CROSS JOIN song_files mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.collection_id, mb.song_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'song', ma.song_id, 'loop', mb.id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN song_files ma ON ma.asset_id = d.asset_id CROSS JOIN loops mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.song_id, mb.id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'person', ma.person_id, 'loop', mb.id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_people ma ON ma.asset_id = d.asset_id CROSS JOIN loops mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.person_id, mb.id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'tag', ma.tag_id, 'loop', mb.id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_tags ma ON ma.asset_id = d.asset_id CROSS JOIN loops mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.tag_id, mb.id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'collection', ma.collection_id, 'loop', mb.id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN collection_items ma ON ma.asset_id = d.asset_id CROSS JOIN loops mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.collection_id, mb.id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_pair_counts (user_id, kind_a, id_a, kind_b, id_b, permitted, concealed) SELECT d.user_id, 'username', ma.username_id, 'loop', mb.id, SUM(d.dn), SUM(d.dc) FROM visibility_moved d CROSS JOIN asset_usernames ma ON ma.asset_id = d.asset_id CROSS JOIN loops mb ON mb.asset_id = d.asset_id WHERE 1 = 1 GROUP BY d.user_id, ma.username_id, mb.id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 ON CONFLICT (user_id, kind_a, id_a, kind_b, id_b) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed;
INSERT INTO viewer_stats (user_id, permitted, concealed, permitted_bytes, concealed_bytes) SELECT d.user_id, SUM(d.dn), SUM(d.dc), SUM(d.dn * d.size), SUM(d.dc * d.size) FROM visibility_moved d WHERE 1 = 1 GROUP BY d.user_id HAVING SUM(d.dn) != 0 OR SUM(d.dc) != 0 OR SUM(d.dn * d.size) != 0 OR SUM(d.dc * d.size) != 0 ON CONFLICT (user_id) DO UPDATE SET permitted = permitted + excluded.permitted, concealed = concealed + excluded.concealed, permitted_bytes = permitted_bytes + excluded.permitted_bytes, concealed_bytes = concealed_bytes + excluded.concealed_bytes;
DELETE FROM visibility_moved;
DELETE FROM visibility_members WHERE +asset_id IN (SELECT asset_id FROM visibility_pending);
DELETE FROM visibility_owed WHERE asset_id IN (SELECT asset_id FROM visibility_pending);
DELETE FROM visibility_pending;
END;
CREATE INDEX ix_insight_days_split ON insight_days(user_id, split_at);
CREATE INDEX ix_page_visits_user ON page_visits(user_id, opened_at_ms);
CREATE INDEX ix_page_visits_sitting ON page_visits(app_session_id, opened_at_ms);
CREATE INDEX ix_app_sessions_device ON app_sessions(user_id, device_id, last_at_ms);
CREATE INDEX ix_file_departures_arrived ON file_departures(arrived_at);
CREATE INDEX ix_file_departures_ended ON file_departures(ended_at);
CREATE TRIGGER insights_file_departs BEFORE DELETE ON assets
BEGIN
  INSERT INTO file_departures
    (asset_id, arrived_at, ended_at, size_bytes, media_type, duration_ms, site_ids, viewers_known)
  SELECT OLD.id, OLD.added_at, CAST(strftime('%s', 'now') AS INTEGER), OLD.size_bytes,
         OLD.media_type, OLD.duration_ms,
         (SELECT json_group_array(DISTINCT u.site_id)
            FROM asset_usernames au JOIN usernames u ON u.id = au.username_id
           WHERE au.asset_id = OLD.id AND u.site_id IS NOT NULL),
         1
   WHERE NOT EXISTS (SELECT 1 FROM file_departures f WHERE f.asset_id = OLD.id);
  INSERT INTO file_departure_viewers (user_id, asset_id, concealed)
  SELECT va.user_id, OLD.id, va.concealed
    FROM users x JOIN viewer_assets va ON va.user_id = x.id AND va.asset_id = OLD.id
   WHERE NOT EXISTS (SELECT 1 FROM file_departure_viewers d
                      WHERE d.user_id = va.user_id AND d.asset_id = OLD.id);
END;
CREATE INDEX ix_work_runs_recent ON work_runs(started_at DESC);
CREATE INDEX ix_work_runs_family ON work_runs(family, started_at DESC);
CREATE INDEX ix_said_times_run ON said_times(run_id, at);
CREATE TRIGGER placeless_file_added AFTER INSERT ON assets BEGIN
  INSERT INTO placeless_assets (asset_id) SELECT NEW.id
   WHERE NOT EXISTS (SELECT 1 FROM asset_locations WHERE asset_id = NEW.id)
     AND NOT EXISTS (SELECT 1 FROM placeless_assets WHERE asset_id = NEW.id);
END;
CREATE TRIGGER placeless_file_removed AFTER DELETE ON assets BEGIN
  DELETE FROM placeless_assets WHERE asset_id = OLD.id;
END;
CREATE TRIGGER placeless_place_added AFTER INSERT ON asset_locations BEGIN
  DELETE FROM placeless_assets WHERE asset_id = NEW.asset_id;
END;
CREATE TRIGGER placeless_place_removed AFTER DELETE ON asset_locations BEGIN
  INSERT INTO placeless_assets (asset_id) SELECT OLD.asset_id
   WHERE EXISTS (SELECT 1 FROM assets WHERE id = OLD.asset_id)
     AND NOT EXISTS (SELECT 1 FROM asset_locations WHERE asset_id = OLD.asset_id)
     AND NOT EXISTS (SELECT 1 FROM placeless_assets WHERE asset_id = OLD.asset_id);
END;
CREATE TRIGGER placeless_place_moved
AFTER UPDATE OF asset_id ON asset_locations WHEN OLD.asset_id IS NOT NEW.asset_id BEGIN
  DELETE FROM placeless_assets WHERE asset_id = NEW.asset_id;
  INSERT INTO placeless_assets (asset_id) SELECT OLD.asset_id
   WHERE NOT EXISTS (SELECT 1 FROM asset_locations WHERE asset_id = OLD.asset_id)
     AND NOT EXISTS (SELECT 1 FROM placeless_assets WHERE asset_id = OLD.asset_id);
END;
CREATE INDEX ix_plays_asset ON plays(asset_id, started_at);
CREATE INDEX ix_plays_user ON plays(user_id, started_at);
CREATE UNIQUE INDEX ux_plays_sitting ON plays(user_id, asset_id, sitting) WHERE sitting IS NOT NULL;
CREATE INDEX ix_plays_theater_session ON plays(user_id, theater_session) WHERE theater_session IS NOT NULL;
CREATE INDEX ix_play_names_ref ON play_names(user_id, kind, ref, since);
CREATE INDEX ix_produced_source ON produced_files(source_asset_id);
CREATE INDEX ix_produced_at ON produced_files(produced_at);
CREATE INDEX ix_save_user ON save_log(user_id, saved_at);
CREATE INDEX ix_scan_rejections_root ON scan_rejections(root_id, rel_path);
CREATE INDEX ix_search_history_user ON search_history(user_id, created_at);
CREATE UNIQUE INDEX ux_search_history_subject ON search_history(user_id, kind, subject);
CREATE INDEX ix_saved_searches_user ON saved_searches(user_id, created_at);
CREATE INDEX ix_search_events_user ON search_events(user_id, at);
CREATE INDEX ix_search_opens_user ON search_opens(user_id, at);
CREATE INDEX ix_search_opens_event ON search_opens(event_id);
CREATE INDEX ix_search_events_subject ON search_events(user_id, subject);
CREATE INDEX ix_semantic_revision ON semantic_indexed(revision);
CREATE INDEX ix_semantic_frame_keys_asset ON semantic_frame_keys(asset_id);
CREATE TRIGGER backlog_semantic_indexed_added AFTER INSERT ON semantic_indexed BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_semantic_indexed_removed AFTER DELETE ON semantic_indexed BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_semantic_indexed_moved AFTER UPDATE ON semantic_indexed BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER semantic_counts_file_added AFTER INSERT ON semantic_indexed BEGIN
  INSERT INTO semantic_counts (revision) SELECT NEW.revision
   WHERE NOT EXISTS (SELECT 1 FROM semantic_counts WHERE revision = NEW.revision);
  UPDATE semantic_counts SET files = files + 1 WHERE revision = NEW.revision;
  DELETE FROM semantic_unrecorded WHERE asset_id = NEW.asset_id;
END;
CREATE TRIGGER semantic_counts_file_removed AFTER DELETE ON semantic_indexed BEGIN
  UPDATE semantic_counts SET files = files - 1 WHERE revision = OLD.revision;
  INSERT INTO semantic_unrecorded (asset_id) SELECT OLD.asset_id
   WHERE EXISTS (SELECT 1 FROM semantic_file_keys WHERE asset_id = OLD.asset_id)
     AND NOT EXISTS (SELECT 1 FROM semantic_unrecorded WHERE asset_id = OLD.asset_id);
END;
CREATE TRIGGER semantic_counts_file_moved
AFTER UPDATE OF revision ON semantic_indexed WHEN OLD.revision IS NOT NEW.revision BEGIN
  UPDATE semantic_counts SET files = files - 1 WHERE revision = OLD.revision;
  INSERT INTO semantic_counts (revision) SELECT NEW.revision
   WHERE NOT EXISTS (SELECT 1 FROM semantic_counts WHERE revision = NEW.revision);
  UPDATE semantic_counts SET files = files + 1 WHERE revision = NEW.revision;
END;
CREATE TRIGGER semantic_counts_frame_added AFTER INSERT ON semantic_frame_keys BEGIN
  INSERT INTO semantic_counts (revision) SELECT NEW.revision
   WHERE NOT EXISTS (SELECT 1 FROM semantic_counts WHERE revision = NEW.revision);
  UPDATE semantic_counts SET frames = frames + 1 WHERE revision = NEW.revision;
END;
CREATE TRIGGER semantic_counts_frame_removed AFTER DELETE ON semantic_frame_keys BEGIN
  UPDATE semantic_counts SET frames = frames - 1 WHERE revision = OLD.revision;
END;
CREATE TRIGGER semantic_unrecorded_keyed AFTER INSERT ON semantic_file_keys BEGIN
  INSERT INTO semantic_unrecorded (asset_id) SELECT NEW.asset_id
   WHERE NOT EXISTS (SELECT 1 FROM semantic_indexed WHERE asset_id = NEW.asset_id)
     AND NOT EXISTS (SELECT 1 FROM semantic_unrecorded WHERE asset_id = NEW.asset_id);
END;
CREATE TRIGGER semantic_unrecorded_unkeyed AFTER DELETE ON semantic_file_keys BEGIN
  DELETE FROM semantic_unrecorded WHERE asset_id = OLD.asset_id;
END;
CREATE INDEX ix_sessions_user ON sessions(user_id);
CREATE INDEX ix_sessions_expires ON sessions(expires_at);
CREATE INDEX ix_shoot_proposals_found ON shoot_proposals(found_at DESC, id DESC);
CREATE INDEX ix_shoot_items_order ON shoot_proposal_items(proposal_id, position);
CREATE INDEX ix_shoot_sets_made ON shoot_sets(photo_set_id);
CREATE INDEX ix_stash_matches_state ON asset_stash_box_matches(state, found_at);
CREATE INDEX ix_stash_matches_box ON asset_stash_box_matches(box_id);
CREATE INDEX ix_stash_scans_asked ON stash_box_scans(box_id, asset_id);
CREATE INDEX ix_stash_scans_box ON stash_box_scans(box_id);
CREATE INDEX ix_stash_scans_asset ON stash_box_scans(asset_id, box_id, scanned_at);
CREATE INDEX ix_stash_answers_age ON stash_box_answers(fetched_at);
CREATE INDEX ix_person_links_box ON person_stash_box_links(box_id);
CREATE INDEX ix_site_stash_box_links_box ON site_stash_box_links(box_id);
CREATE INDEX ix_tag_links_box ON tag_stash_box_links(box_id);
CREATE INDEX ix_folder_claims_state_by_id ON folder_claims(state, id);
CREATE INDEX ix_folder_claims_name ON folder_claims(name_key);
CREATE INDEX ix_folder_people_person ON folder_people(person_id);
CREATE INDEX ix_swap_sessions_state ON swap_sessions(state);
CREATE INDEX ix_swap_manifests_age ON swap_manifests(updated_at);
CREATE INDEX ix_theater_arrangements_user ON theater_arrangements(user_id, created_at);
CREATE INDEX ix_theater_sessions_user ON theater_sessions(user_id, started_at);
CREATE UNIQUE INDEX ux_tunnels_name ON tunnels(name COLLATE NOCASE);
CREATE INDEX ix_watermark_revision ON watermark_scans(revision);
CREATE TRIGGER backlog_watermark_scans_added AFTER INSERT ON watermark_scans BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_watermark_scans_removed AFTER DELETE ON watermark_scans BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_watermark_scans_moved AFTER UPDATE ON watermark_scans BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_watermark_reads_added AFTER INSERT ON watermark_reads BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_watermark_reads_removed AFTER DELETE ON watermark_reads BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_watermark_reads_moved AFTER UPDATE OF asset_id, matcher_version ON watermark_reads WHEN OLD.asset_id IS NOT NEW.asset_id OR OLD.matcher_version IS NOT NEW.matcher_version BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_watermark_refusals_added AFTER INSERT ON watermark_refusals BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_watermark_refusals_removed AFTER DELETE ON watermark_refusals BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER backlog_watermark_refusals_moved AFTER UPDATE ON watermark_refusals BEGIN UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = OLD.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (OLD.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); UPDATE backlog_clock SET seq = seq + 1 WHERE id = 1; DELETE FROM backlog_moved WHERE asset_id = NEW.asset_id; INSERT INTO backlog_moved (asset_id, seq) VALUES (NEW.asset_id, (SELECT seq FROM backlog_clock WHERE id = 1)); END;
CREATE TRIGGER default_cover_person_filed AFTER INSERT ON asset_people WHEN EXISTS (SELECT 1 FROM people e WHERE e.id = NEW.person_id AND e.cover_asset_id IS NULL AND e.cover_upload_id IS NULL AND e.cover_cleared_at IS NULL) BEGIN UPDATE people SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL, cover_track_id = NULL WHERE people.id = NEW.person_id AND people.cover_asset_id IS NULL AND people.cover_upload_id IS NULL AND people.cover_cleared_at IS NULL AND EXISTS (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL); END;
CREATE TRIGGER default_cover_person_lost AFTER UPDATE OF cover_asset_id, cover_upload_id ON people WHEN NEW.cover_asset_id IS NULL AND NEW.cover_upload_id IS NULL AND NEW.cover_cleared_at IS NULL AND (OLD.cover_asset_id IS NOT NULL OR OLD.cover_upload_id IS NOT NULL) BEGIN UPDATE people SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL, cover_track_id = NULL WHERE people.id = NEW.id AND people.cover_asset_id IS NULL AND people.cover_upload_id IS NULL AND people.cover_cleared_at IS NULL AND EXISTS (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL); END;
CREATE TRIGGER default_cover_person_unfiled AFTER DELETE ON asset_people BEGIN UPDATE people SET cover_asset_id = NULL, cover_by_default = NULL WHERE people.id = OLD.person_id AND people.cover_asset_id = OLD.asset_id AND people.cover_by_default IS NOT NULL AND people.cover_asset_id = people.cover_by_default AND people.cover_upload_id IS NULL AND people.cover_at_ms IS NULL AND people.cover_frame IS NULL AND people.cover_track_id IS NULL; END;
CREATE TRIGGER default_cover_person_filed_seen AFTER INSERT ON asset_people WHEN EXISTS (SELECT 1 FROM people e WHERE e.id = NEW.person_id AND e.cover_by_default IS NOT NULL AND e.cover_asset_id = e.cover_by_default AND e.cover_upload_id IS NULL AND e.cover_at_ms IS NULL AND e.cover_frame IS NULL AND e.cover_track_id IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = e.cover_asset_id AND v.concealed = 1)) BEGIN UPDATE people SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL, cover_track_id = NULL WHERE people.id = NEW.person_id AND people.cover_by_default IS NOT NULL AND people.cover_asset_id = people.cover_by_default AND people.cover_upload_id IS NULL AND people.cover_at_ms IS NULL AND people.cover_frame IS NULL AND people.cover_track_id IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = people.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT people.cover_asset_id; END;
CREATE TRIGGER default_cover_collection_filed AFTER INSERT ON collection_items WHEN EXISTS (SELECT 1 FROM collections e WHERE e.id = NEW.collection_id AND e.cover_asset_id IS NULL AND e.cover_upload_id IS NULL AND e.cover_cleared_at IS NULL) BEGIN UPDATE collections SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE collections.id = NEW.collection_id AND collections.cover_asset_id IS NULL AND collections.cover_upload_id IS NULL AND collections.cover_cleared_at IS NULL AND EXISTS (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL); END;
CREATE TRIGGER default_cover_collection_lost AFTER UPDATE OF cover_asset_id, cover_upload_id ON collections WHEN NEW.cover_asset_id IS NULL AND NEW.cover_upload_id IS NULL AND NEW.cover_cleared_at IS NULL AND (OLD.cover_asset_id IS NOT NULL OR OLD.cover_upload_id IS NOT NULL) BEGIN UPDATE collections SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE collections.id = NEW.id AND collections.cover_asset_id IS NULL AND collections.cover_upload_id IS NULL AND collections.cover_cleared_at IS NULL AND EXISTS (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL); END;
CREATE TRIGGER default_cover_collection_unfiled AFTER DELETE ON collection_items BEGIN UPDATE collections SET cover_asset_id = NULL, cover_by_default = NULL WHERE collections.id = OLD.collection_id AND collections.cover_asset_id = OLD.asset_id AND collections.cover_by_default IS NOT NULL AND collections.cover_asset_id = collections.cover_by_default AND collections.cover_upload_id IS NULL AND collections.cover_at_ms IS NULL AND collections.cover_frame IS NULL; END;
CREATE TRIGGER default_cover_collection_filed_seen AFTER INSERT ON collection_items WHEN EXISTS (SELECT 1 FROM collections e WHERE e.id = NEW.collection_id AND e.cover_by_default IS NOT NULL AND e.cover_asset_id = e.cover_by_default AND e.cover_upload_id IS NULL AND e.cover_at_ms IS NULL AND e.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = e.cover_asset_id AND v.concealed = 1)) BEGIN UPDATE collections SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE collections.id = NEW.collection_id AND collections.cover_by_default IS NOT NULL AND collections.cover_asset_id = collections.cover_by_default AND collections.cover_upload_id IS NULL AND collections.cover_at_ms IS NULL AND collections.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = collections.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT collections.cover_asset_id; END;
CREATE TRIGGER default_cover_photo_set_filed AFTER INSERT ON photo_set_items WHEN EXISTS (SELECT 1 FROM photo_sets e WHERE e.id = NEW.photo_set_id AND e.cover_asset_id IS NULL AND e.cover_upload_id IS NULL AND e.cover_cleared_at IS NULL) BEGIN UPDATE photo_sets SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE photo_sets.id = NEW.photo_set_id AND photo_sets.cover_asset_id IS NULL AND photo_sets.cover_upload_id IS NULL AND photo_sets.cover_cleared_at IS NULL AND EXISTS (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL); END;
CREATE TRIGGER default_cover_photo_set_lost AFTER UPDATE OF cover_asset_id, cover_upload_id ON photo_sets WHEN NEW.cover_asset_id IS NULL AND NEW.cover_upload_id IS NULL AND NEW.cover_cleared_at IS NULL AND (OLD.cover_asset_id IS NOT NULL OR OLD.cover_upload_id IS NOT NULL) BEGIN UPDATE photo_sets SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE photo_sets.id = NEW.id AND photo_sets.cover_asset_id IS NULL AND photo_sets.cover_upload_id IS NULL AND photo_sets.cover_cleared_at IS NULL AND EXISTS (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL); END;
CREATE TRIGGER default_cover_photo_set_unfiled AFTER DELETE ON photo_set_items BEGIN UPDATE photo_sets SET cover_asset_id = NULL, cover_by_default = NULL WHERE photo_sets.id = OLD.photo_set_id AND photo_sets.cover_asset_id = OLD.asset_id AND photo_sets.cover_by_default IS NOT NULL AND photo_sets.cover_asset_id = photo_sets.cover_by_default AND photo_sets.cover_upload_id IS NULL AND photo_sets.cover_at_ms IS NULL AND photo_sets.cover_frame IS NULL; END;
CREATE TRIGGER default_cover_photo_set_filed_seen AFTER INSERT ON photo_set_items WHEN EXISTS (SELECT 1 FROM photo_sets e WHERE e.id = NEW.photo_set_id AND e.cover_by_default IS NOT NULL AND e.cover_asset_id = e.cover_by_default AND e.cover_upload_id IS NULL AND e.cover_at_ms IS NULL AND e.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = e.cover_asset_id AND v.concealed = 1)) BEGIN UPDATE photo_sets SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE photo_sets.id = NEW.photo_set_id AND photo_sets.cover_by_default IS NOT NULL AND photo_sets.cover_asset_id = photo_sets.cover_by_default AND photo_sets.cover_upload_id IS NULL AND photo_sets.cover_at_ms IS NULL AND photo_sets.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = photo_sets.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT photo_sets.cover_asset_id; END;
CREATE TRIGGER default_cover_copy_arrived AFTER INSERT ON asset_locations WHEN NEW.status = 'present' BEGIN UPDATE people SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL, cover_track_id = NULL WHERE people.id IN (SELECT f.person_id FROM asset_people f WHERE f.asset_id = NEW.asset_id) AND people.cover_asset_id IS NULL AND people.cover_upload_id IS NULL AND people.cover_cleared_at IS NULL AND EXISTS (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL); UPDATE collections SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE collections.id IN (SELECT f.collection_id FROM collection_items f WHERE f.asset_id = NEW.asset_id) AND collections.cover_asset_id IS NULL AND collections.cover_upload_id IS NULL AND collections.cover_cleared_at IS NULL AND EXISTS (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL); UPDATE photo_sets SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE photo_sets.id IN (SELECT f.photo_set_id FROM photo_set_items f WHERE f.asset_id = NEW.asset_id) AND photo_sets.cover_asset_id IS NULL AND photo_sets.cover_upload_id IS NULL AND photo_sets.cover_cleared_at IS NULL AND EXISTS (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL); UPDATE people SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL, cover_track_id = NULL WHERE people.id IN (SELECT f.person_id FROM asset_people f WHERE f.asset_id = NEW.asset_id) AND people.cover_by_default IS NOT NULL AND people.cover_asset_id = people.cover_by_default AND people.cover_upload_id IS NULL AND people.cover_at_ms IS NULL AND people.cover_frame IS NULL AND people.cover_track_id IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = people.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT people.cover_asset_id; UPDATE collections SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE collections.id IN (SELECT f.collection_id FROM collection_items f WHERE f.asset_id = NEW.asset_id) AND collections.cover_by_default IS NOT NULL AND collections.cover_asset_id = collections.cover_by_default AND collections.cover_upload_id IS NULL AND collections.cover_at_ms IS NULL AND collections.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = collections.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT collections.cover_asset_id; UPDATE photo_sets SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE photo_sets.id IN (SELECT f.photo_set_id FROM photo_set_items f WHERE f.asset_id = NEW.asset_id) AND photo_sets.cover_by_default IS NOT NULL AND photo_sets.cover_asset_id = photo_sets.cover_by_default AND photo_sets.cover_upload_id IS NULL AND photo_sets.cover_at_ms IS NULL AND photo_sets.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = photo_sets.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT photo_sets.cover_asset_id; END;
CREATE TRIGGER default_cover_copy_back AFTER UPDATE OF status, asset_id ON asset_locations WHEN NEW.status = 'present' AND (OLD.status IS NOT 'present' OR NEW.asset_id IS NOT OLD.asset_id) BEGIN UPDATE people SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL, cover_track_id = NULL WHERE people.id IN (SELECT f.person_id FROM asset_people f WHERE f.asset_id = NEW.asset_id) AND people.cover_asset_id IS NULL AND people.cover_upload_id IS NULL AND people.cover_cleared_at IS NULL AND EXISTS (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL); UPDATE collections SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE collections.id IN (SELECT f.collection_id FROM collection_items f WHERE f.asset_id = NEW.asset_id) AND collections.cover_asset_id IS NULL AND collections.cover_upload_id IS NULL AND collections.cover_cleared_at IS NULL AND EXISTS (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL); UPDATE photo_sets SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE photo_sets.id IN (SELECT f.photo_set_id FROM photo_set_items f WHERE f.asset_id = NEW.asset_id) AND photo_sets.cover_asset_id IS NULL AND photo_sets.cover_upload_id IS NULL AND photo_sets.cover_cleared_at IS NULL AND EXISTS (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL); UPDATE people SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL, cover_track_id = NULL WHERE people.id IN (SELECT f.person_id FROM asset_people f WHERE f.asset_id = NEW.asset_id) AND people.cover_by_default IS NOT NULL AND people.cover_asset_id = people.cover_by_default AND people.cover_upload_id IS NULL AND people.cover_at_ms IS NULL AND people.cover_frame IS NULL AND people.cover_track_id IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = people.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT people.cover_asset_id; UPDATE collections SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE collections.id IN (SELECT f.collection_id FROM collection_items f WHERE f.asset_id = NEW.asset_id) AND collections.cover_by_default IS NOT NULL AND collections.cover_asset_id = collections.cover_by_default AND collections.cover_upload_id IS NULL AND collections.cover_at_ms IS NULL AND collections.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = collections.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT collections.cover_asset_id; UPDATE photo_sets SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE photo_sets.id IN (SELECT f.photo_set_id FROM photo_set_items f WHERE f.asset_id = NEW.asset_id) AND photo_sets.cover_by_default IS NOT NULL AND photo_sets.cover_asset_id = photo_sets.cover_by_default AND photo_sets.cover_upload_id IS NULL AND photo_sets.cover_at_ms IS NULL AND photo_sets.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = photo_sets.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT photo_sets.cover_asset_id; END;
CREATE TRIGGER default_cover_hidden_moved AFTER UPDATE OF concealed ON viewer_assets WHEN NEW.concealed IS NOT OLD.concealed BEGIN UPDATE people SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL, cover_track_id = NULL WHERE people.id IN (SELECT f.person_id FROM asset_people f WHERE f.asset_id = NEW.asset_id) AND people.cover_by_default IS NOT NULL AND people.cover_asset_id = people.cover_by_default AND people.cover_upload_id IS NULL AND people.cover_at_ms IS NULL AND people.cover_frame IS NULL AND people.cover_track_id IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = people.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT people.cover_asset_id; UPDATE collections SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE collections.id IN (SELECT f.collection_id FROM collection_items f WHERE f.asset_id = NEW.asset_id) AND collections.cover_by_default IS NOT NULL AND collections.cover_asset_id = collections.cover_by_default AND collections.cover_upload_id IS NULL AND collections.cover_at_ms IS NULL AND collections.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = collections.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT collections.cover_asset_id; UPDATE photo_sets SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE photo_sets.id IN (SELECT f.photo_set_id FROM photo_set_items f WHERE f.asset_id = NEW.asset_id) AND photo_sets.cover_by_default IS NOT NULL AND photo_sets.cover_asset_id = photo_sets.cover_by_default AND photo_sets.cover_upload_id IS NULL AND photo_sets.cover_at_ms IS NULL AND photo_sets.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = photo_sets.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT photo_sets.cover_asset_id; END;
CREATE TRIGGER default_cover_hidden_new AFTER INSERT ON viewer_assets WHEN NEW.concealed = 1 BEGIN UPDATE people SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL, cover_track_id = NULL WHERE people.id IN (SELECT f.person_id FROM asset_people f WHERE f.asset_id = NEW.asset_id) AND people.cover_by_default IS NOT NULL AND people.cover_asset_id = people.cover_by_default AND people.cover_upload_id IS NULL AND people.cover_at_ms IS NULL AND people.cover_frame IS NULL AND people.cover_track_id IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = people.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT people.cover_asset_id; UPDATE collections SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE collections.id IN (SELECT f.collection_id FROM collection_items f WHERE f.asset_id = NEW.asset_id) AND collections.cover_by_default IS NOT NULL AND collections.cover_asset_id = collections.cover_by_default AND collections.cover_upload_id IS NULL AND collections.cover_at_ms IS NULL AND collections.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = collections.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT collections.cover_asset_id; UPDATE photo_sets SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE photo_sets.id IN (SELECT f.photo_set_id FROM photo_set_items f WHERE f.asset_id = NEW.asset_id) AND photo_sets.cover_by_default IS NOT NULL AND photo_sets.cover_asset_id = photo_sets.cover_by_default AND photo_sets.cover_upload_id IS NULL AND photo_sets.cover_at_ms IS NULL AND photo_sets.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = photo_sets.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT photo_sets.cover_asset_id; END;
CREATE TRIGGER default_cover_hidden_gone AFTER DELETE ON viewer_assets WHEN OLD.concealed = 1 BEGIN UPDATE people SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL, cover_track_id = NULL WHERE people.id IN (SELECT f.person_id FROM asset_people f WHERE f.asset_id = OLD.asset_id) AND people.cover_by_default IS NOT NULL AND people.cover_asset_id = people.cover_by_default AND people.cover_upload_id IS NULL AND people.cover_at_ms IS NULL AND people.cover_frame IS NULL AND people.cover_track_id IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = people.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.decided_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM asset_people m JOIN assets a ON a.id = m.asset_id WHERE m.person_id = people.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.decided_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT people.cover_asset_id; UPDATE collections SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE collections.id IN (SELECT f.collection_id FROM collection_items f WHERE f.asset_id = OLD.asset_id) AND collections.cover_by_default IS NOT NULL AND collections.cover_asset_id = collections.cover_by_default AND collections.cover_upload_id IS NULL AND collections.cover_at_ms IS NULL AND collections.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = collections.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.asset_id LIMIT 1), (SELECT m.asset_id FROM collection_items m JOIN assets a ON a.id = m.asset_id WHERE m.collection_id = collections.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT collections.cover_asset_id; UPDATE photo_sets SET cover_asset_id = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_by_default = (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL), cover_at_ms = NULL, cover_frame = NULL WHERE photo_sets.id IN (SELECT f.photo_set_id FROM photo_set_items f WHERE f.asset_id = OLD.asset_id) AND photo_sets.cover_by_default IS NOT NULL AND photo_sets.cover_asset_id = photo_sets.cover_by_default AND photo_sets.cover_upload_id IS NULL AND photo_sets.cover_at_ms IS NULL AND photo_sets.cover_frame IS NULL AND EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = photo_sets.cover_asset_id AND v.concealed = 1) AND (SELECT picked FROM (SELECT COALESCE((SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') AND NOT EXISTS (SELECT 1 FROM users u JOIN viewer_assets v ON v.user_id = u.id AND v.asset_id = m.asset_id AND v.concealed = 1) ORDER BY m.added_at, m.position, m.asset_id LIMIT 1), (SELECT m.asset_id FROM photo_set_items m JOIN assets a ON a.id = m.asset_id WHERE m.photo_set_id = photo_sets.id AND EXISTS (SELECT 1 FROM asset_locations l WHERE l.asset_id = a.id AND l.status = 'present') ORDER BY m.added_at, m.position, m.asset_id LIMIT 1)) AS picked) WHERE picked IS NOT NULL) IS NOT photo_sets.cover_asset_id; END;
CREATE TRIGGER edited_asset_links_changed AFTER UPDATE OF url, label ON asset_links WHEN (OLD.url IS NOT NEW.url OR OLD.label IS NOT NEW.label) BEGIN UPDATE asset_edits SET edited_at = unixepoch() WHERE asset_id = NEW.asset_id; INSERT INTO asset_edits (asset_id, edited_at) SELECT NEW.asset_id, unixepoch() WHERE NOT EXISTS (SELECT 1 FROM asset_edits WHERE asset_id = NEW.asset_id) AND EXISTS (SELECT 1 FROM assets WHERE id = NEW.asset_id); END;
CREATE TRIGGER edited_asset_links_in AFTER INSERT ON asset_links BEGIN UPDATE asset_edits SET edited_at = unixepoch() WHERE asset_id = NEW.asset_id; INSERT INTO asset_edits (asset_id, edited_at) SELECT NEW.asset_id, unixepoch() WHERE NOT EXISTS (SELECT 1 FROM asset_edits WHERE asset_id = NEW.asset_id) AND EXISTS (SELECT 1 FROM assets WHERE id = NEW.asset_id); END;
CREATE TRIGGER edited_asset_links_out AFTER DELETE ON asset_links WHEN EXISTS (SELECT 1 FROM assets WHERE id = OLD.asset_id) BEGIN UPDATE asset_edits SET edited_at = unixepoch() WHERE asset_id = OLD.asset_id; INSERT INTO asset_edits (asset_id, edited_at) SELECT OLD.asset_id, unixepoch() WHERE NOT EXISTS (SELECT 1 FROM asset_edits WHERE asset_id = OLD.asset_id) AND EXISTS (SELECT 1 FROM assets WHERE id = OLD.asset_id); END;
CREATE TRIGGER edited_asset_people_in AFTER INSERT ON asset_people BEGIN UPDATE asset_edits SET edited_at = unixepoch() WHERE asset_id = NEW.asset_id; INSERT INTO asset_edits (asset_id, edited_at) SELECT NEW.asset_id, unixepoch() WHERE NOT EXISTS (SELECT 1 FROM asset_edits WHERE asset_id = NEW.asset_id) AND EXISTS (SELECT 1 FROM assets WHERE id = NEW.asset_id); END;
CREATE TRIGGER edited_asset_people_out AFTER DELETE ON asset_people WHEN EXISTS (SELECT 1 FROM assets WHERE id = OLD.asset_id) AND EXISTS (SELECT 1 FROM people WHERE id = OLD.person_id) BEGIN UPDATE asset_edits SET edited_at = unixepoch() WHERE asset_id = OLD.asset_id; INSERT INTO asset_edits (asset_id, edited_at) SELECT OLD.asset_id, unixepoch() WHERE NOT EXISTS (SELECT 1 FROM asset_edits WHERE asset_id = OLD.asset_id) AND EXISTS (SELECT 1 FROM assets WHERE id = OLD.asset_id); END;
CREATE TRIGGER edited_asset_record AFTER UPDATE OF title, download_url, release_date, details, production_date, site_code ON assets WHEN (OLD.title IS NOT NEW.title OR OLD.download_url IS NOT NEW.download_url OR OLD.release_date IS NOT NEW.release_date OR OLD.details IS NOT NEW.details OR OLD.production_date IS NOT NEW.production_date OR OLD.site_code IS NOT NEW.site_code) BEGIN UPDATE asset_edits SET edited_at = unixepoch() WHERE asset_id = NEW.id; INSERT INTO asset_edits (asset_id, edited_at) SELECT NEW.id, unixepoch() WHERE NOT EXISTS (SELECT 1 FROM asset_edits WHERE asset_id = NEW.id) AND EXISTS (SELECT 1 FROM assets WHERE id = NEW.id); END;
CREATE TRIGGER edited_asset_tags_in AFTER INSERT ON asset_tags BEGIN UPDATE asset_edits SET edited_at = unixepoch() WHERE asset_id = NEW.asset_id; INSERT INTO asset_edits (asset_id, edited_at) SELECT NEW.asset_id, unixepoch() WHERE NOT EXISTS (SELECT 1 FROM asset_edits WHERE asset_id = NEW.asset_id) AND EXISTS (SELECT 1 FROM assets WHERE id = NEW.asset_id); END;
CREATE TRIGGER edited_asset_tags_out AFTER DELETE ON asset_tags WHEN EXISTS (SELECT 1 FROM assets WHERE id = OLD.asset_id) AND EXISTS (SELECT 1 FROM tags WHERE id = OLD.tag_id) BEGIN UPDATE asset_edits SET edited_at = unixepoch() WHERE asset_id = OLD.asset_id; INSERT INTO asset_edits (asset_id, edited_at) SELECT OLD.asset_id, unixepoch() WHERE NOT EXISTS (SELECT 1 FROM asset_edits WHERE asset_id = OLD.asset_id) AND EXISTS (SELECT 1 FROM assets WHERE id = OLD.asset_id); END;
CREATE TRIGGER edited_collection_tags_in AFTER INSERT ON collection_tags BEGIN UPDATE collections SET edited_at = unixepoch() WHERE id = NEW.collection_id; END;
CREATE TRIGGER edited_collection_tags_out AFTER DELETE ON collection_tags WHEN EXISTS (SELECT 1 FROM tags WHERE id = OLD.tag_id) BEGIN UPDATE collections SET edited_at = unixepoch() WHERE id = OLD.collection_id; END;
CREATE TRIGGER edited_collections AFTER UPDATE OF name, cover_asset_id, cover_at_ms, cover_upload_id, cover_frame, cover_cleared_at ON collections WHEN (OLD.name IS NOT NEW.name OR (OLD.cover_by_default IS NEW.cover_by_default AND ((OLD.cover_asset_id IS NOT NEW.cover_asset_id AND (NEW.cover_asset_id IS NOT NULL OR EXISTS (SELECT 1 FROM assets WHERE id = OLD.cover_asset_id))) OR OLD.cover_at_ms IS NOT NEW.cover_at_ms OR OLD.cover_upload_id IS NOT NEW.cover_upload_id OR OLD.cover_frame IS NOT NEW.cover_frame OR OLD.cover_cleared_at IS NOT NEW.cover_cleared_at))) BEGIN UPDATE collections SET edited_at = unixepoch() WHERE id = NEW.id; END;
CREATE TRIGGER edited_loop_tags_in AFTER INSERT ON loop_tags BEGIN UPDATE loops SET edited_at = unixepoch() WHERE id = NEW.loop_id; END;
CREATE TRIGGER edited_loop_tags_out AFTER DELETE ON loop_tags WHEN EXISTS (SELECT 1 FROM tags WHERE id = OLD.tag_id) BEGIN UPDATE loops SET edited_at = unixepoch() WHERE id = OLD.loop_id; END;
CREATE TRIGGER edited_loops AFTER UPDATE OF name, start_ms, end_ms ON loops WHEN (OLD.name IS NOT NEW.name OR OLD.start_ms IS NOT NEW.start_ms OR OLD.end_ms IS NOT NEW.end_ms) BEGIN UPDATE loops SET edited_at = unixepoch() WHERE id = NEW.id; END;
CREATE TRIGGER edited_people AFTER UPDATE OF name, notes, disambiguation, gender, birth_date, country, ethnicity, eye_color, hair_color, height_cm, measurements, breast_type, career_start_year, career_end_year, tattoos, piercings, pmv_creator, cover_asset_id, cover_at_ms, cover_upload_id, cover_frame, cover_cleared_at, cover_track_id ON people WHEN (OLD.name IS NOT NEW.name OR OLD.notes IS NOT NEW.notes OR OLD.disambiguation IS NOT NEW.disambiguation OR OLD.gender IS NOT NEW.gender OR OLD.birth_date IS NOT NEW.birth_date OR OLD.country IS NOT NEW.country OR OLD.ethnicity IS NOT NEW.ethnicity OR OLD.eye_color IS NOT NEW.eye_color OR OLD.hair_color IS NOT NEW.hair_color OR OLD.height_cm IS NOT NEW.height_cm OR OLD.measurements IS NOT NEW.measurements OR OLD.breast_type IS NOT NEW.breast_type OR OLD.career_start_year IS NOT NEW.career_start_year OR OLD.career_end_year IS NOT NEW.career_end_year OR OLD.tattoos IS NOT NEW.tattoos OR OLD.piercings IS NOT NEW.piercings OR OLD.pmv_creator IS NOT NEW.pmv_creator OR (OLD.cover_by_default IS NEW.cover_by_default AND ((OLD.cover_asset_id IS NOT NEW.cover_asset_id AND (NEW.cover_asset_id IS NOT NULL OR EXISTS (SELECT 1 FROM assets WHERE id = OLD.cover_asset_id))) OR OLD.cover_at_ms IS NOT NEW.cover_at_ms OR OLD.cover_upload_id IS NOT NEW.cover_upload_id OR OLD.cover_frame IS NOT NEW.cover_frame OR OLD.cover_cleared_at IS NOT NEW.cover_cleared_at OR OLD.cover_track_id IS NOT NEW.cover_track_id))) BEGIN UPDATE people SET edited_at = unixepoch() WHERE id = NEW.id; END;
CREATE TRIGGER edited_people_aliases_changed AFTER UPDATE OF alias ON people_aliases WHEN (OLD.alias IS NOT NEW.alias) BEGIN UPDATE people SET edited_at = unixepoch() WHERE id = NEW.person_id; END;
CREATE TRIGGER edited_people_aliases_in AFTER INSERT ON people_aliases BEGIN UPDATE people SET edited_at = unixepoch() WHERE id = NEW.person_id; END;
CREATE TRIGGER edited_people_aliases_out AFTER DELETE ON people_aliases BEGIN UPDATE people SET edited_at = unixepoch() WHERE id = OLD.person_id; END;
CREATE TRIGGER edited_people_links_changed AFTER UPDATE OF url, label ON people_links WHEN (OLD.url IS NOT NEW.url OR OLD.label IS NOT NEW.label) BEGIN UPDATE people SET edited_at = unixepoch() WHERE id = NEW.person_id; END;
CREATE TRIGGER edited_people_links_in AFTER INSERT ON people_links BEGIN UPDATE people SET edited_at = unixepoch() WHERE id = NEW.person_id; END;
CREATE TRIGGER edited_people_links_out AFTER DELETE ON people_links BEGIN UPDATE people SET edited_at = unixepoch() WHERE id = OLD.person_id; END;
CREATE TRIGGER edited_person_tags_in AFTER INSERT ON person_tags BEGIN UPDATE people SET edited_at = unixepoch() WHERE id = NEW.person_id; END;
CREATE TRIGGER edited_person_tags_out AFTER DELETE ON person_tags WHEN EXISTS (SELECT 1 FROM tags WHERE id = OLD.tag_id) BEGIN UPDATE people SET edited_at = unixepoch() WHERE id = OLD.person_id; END;
CREATE TRIGGER edited_photo_set_tags_in AFTER INSERT ON photo_set_tags BEGIN UPDATE photo_sets SET edited_at = unixepoch() WHERE id = NEW.photo_set_id; END;
CREATE TRIGGER edited_photo_set_tags_out AFTER DELETE ON photo_set_tags WHEN EXISTS (SELECT 1 FROM tags WHERE id = OLD.tag_id) BEGIN UPDATE photo_sets SET edited_at = unixepoch() WHERE id = OLD.photo_set_id; END;
CREATE TRIGGER edited_photo_sets AFTER UPDATE OF name, notes, cover_asset_id, cover_at_ms, cover_upload_id, cover_frame, cover_cleared_at ON photo_sets WHEN (OLD.name IS NOT NEW.name OR OLD.notes IS NOT NEW.notes OR (OLD.cover_by_default IS NEW.cover_by_default AND ((OLD.cover_asset_id IS NOT NEW.cover_asset_id AND (NEW.cover_asset_id IS NOT NULL OR EXISTS (SELECT 1 FROM assets WHERE id = OLD.cover_asset_id))) OR OLD.cover_at_ms IS NOT NEW.cover_at_ms OR OLD.cover_upload_id IS NOT NEW.cover_upload_id OR OLD.cover_frame IS NOT NEW.cover_frame OR OLD.cover_cleared_at IS NOT NEW.cover_cleared_at))) BEGIN UPDATE photo_sets SET edited_at = unixepoch() WHERE id = NEW.id; END;
CREATE TRIGGER edited_site_aliases_changed AFTER UPDATE OF alias ON site_aliases WHEN (OLD.alias IS NOT NEW.alias) BEGIN UPDATE sites SET edited_at = unixepoch() WHERE id = NEW.site_id; END;
CREATE TRIGGER edited_site_aliases_in AFTER INSERT ON site_aliases BEGIN UPDATE sites SET edited_at = unixepoch() WHERE id = NEW.site_id; END;
CREATE TRIGGER edited_site_aliases_out AFTER DELETE ON site_aliases BEGIN UPDATE sites SET edited_at = unixepoch() WHERE id = OLD.site_id; END;
CREATE TRIGGER edited_site_links_changed AFTER UPDATE OF url, label ON site_links WHEN (OLD.url IS NOT NEW.url OR OLD.label IS NOT NEW.label) BEGIN UPDATE sites SET edited_at = unixepoch() WHERE id = NEW.site_id; END;
CREATE TRIGGER edited_site_links_in AFTER INSERT ON site_links BEGIN UPDATE sites SET edited_at = unixepoch() WHERE id = NEW.site_id; END;
CREATE TRIGGER edited_site_links_out AFTER DELETE ON site_links BEGIN UPDATE sites SET edited_at = unixepoch() WHERE id = OLD.site_id; END;
CREATE TRIGGER edited_site_tags_in AFTER INSERT ON site_tags BEGIN UPDATE sites SET edited_at = unixepoch() WHERE id = NEW.site_id; END;
CREATE TRIGGER edited_site_tags_out AFTER DELETE ON site_tags WHEN EXISTS (SELECT 1 FROM tags WHERE id = OLD.tag_id) BEGIN UPDATE sites SET edited_at = unixepoch() WHERE id = OLD.site_id; END;
CREATE TRIGGER edited_sites AFTER UPDATE OF name, notes, parent_id, cover_asset_id, cover_at_ms, cover_upload_id, cover_frame, cover_cleared_at ON sites WHEN (OLD.name IS NOT NEW.name OR OLD.notes IS NOT NEW.notes OR (OLD.parent_id IS NOT NEW.parent_id AND (NEW.parent_id IS NOT NULL OR EXISTS (SELECT 1 FROM sites WHERE id = OLD.parent_id))) OR (OLD.cover_by_default IS NEW.cover_by_default AND ((OLD.cover_asset_id IS NOT NEW.cover_asset_id AND (NEW.cover_asset_id IS NOT NULL OR EXISTS (SELECT 1 FROM assets WHERE id = OLD.cover_asset_id))) OR OLD.cover_at_ms IS NOT NEW.cover_at_ms OR OLD.cover_upload_id IS NOT NEW.cover_upload_id OR OLD.cover_frame IS NOT NEW.cover_frame OR OLD.cover_cleared_at IS NOT NEW.cover_cleared_at))) BEGIN UPDATE sites SET edited_at = unixepoch() WHERE id = NEW.id; END;
CREATE TRIGGER edited_song_files_changed AFTER UPDATE OF added_at ON song_files WHEN (OLD.added_at IS NOT NEW.added_at) BEGIN UPDATE asset_edits SET edited_at = unixepoch() WHERE asset_id = NEW.asset_id; INSERT INTO asset_edits (asset_id, edited_at) SELECT NEW.asset_id, unixepoch() WHERE NOT EXISTS (SELECT 1 FROM asset_edits WHERE asset_id = NEW.asset_id) AND EXISTS (SELECT 1 FROM assets WHERE id = NEW.asset_id); END;
CREATE TRIGGER edited_song_files_in AFTER INSERT ON song_files BEGIN UPDATE asset_edits SET edited_at = unixepoch() WHERE asset_id = NEW.asset_id; INSERT INTO asset_edits (asset_id, edited_at) SELECT NEW.asset_id, unixepoch() WHERE NOT EXISTS (SELECT 1 FROM asset_edits WHERE asset_id = NEW.asset_id) AND EXISTS (SELECT 1 FROM assets WHERE id = NEW.asset_id); END;
CREATE TRIGGER edited_song_files_out AFTER DELETE ON song_files WHEN EXISTS (SELECT 1 FROM assets WHERE id = OLD.asset_id) AND EXISTS (SELECT 1 FROM songs WHERE id = OLD.song_id) BEGIN UPDATE asset_edits SET edited_at = unixepoch() WHERE asset_id = OLD.asset_id; INSERT INTO asset_edits (asset_id, edited_at) SELECT OLD.asset_id, unixepoch() WHERE NOT EXISTS (SELECT 1 FROM asset_edits WHERE asset_id = OLD.asset_id) AND EXISTS (SELECT 1 FROM assets WHERE id = OLD.asset_id); END;
CREATE TRIGGER edited_songs AFTER UPDATE OF name, notes, cover_asset_id, cover_at_ms, cover_upload_id, cover_frame, cover_cleared_at ON songs WHEN (OLD.name IS NOT NEW.name OR OLD.notes IS NOT NEW.notes OR (OLD.cover_by_default IS NEW.cover_by_default AND ((OLD.cover_asset_id IS NOT NEW.cover_asset_id AND (NEW.cover_asset_id IS NOT NULL OR EXISTS (SELECT 1 FROM assets WHERE id = OLD.cover_asset_id))) OR OLD.cover_at_ms IS NOT NEW.cover_at_ms OR OLD.cover_upload_id IS NOT NEW.cover_upload_id OR OLD.cover_frame IS NOT NEW.cover_frame OR OLD.cover_cleared_at IS NOT NEW.cover_cleared_at))) BEGIN UPDATE songs SET edited_at = unixepoch() WHERE id = NEW.id; END;
CREATE TRIGGER edited_tag_aliases_changed AFTER UPDATE OF alias ON tag_aliases WHEN (OLD.alias IS NOT NEW.alias) BEGIN UPDATE tags SET edited_at = unixepoch() WHERE id = NEW.tag_id; END;
CREATE TRIGGER edited_tag_aliases_in AFTER INSERT ON tag_aliases BEGIN UPDATE tags SET edited_at = unixepoch() WHERE id = NEW.tag_id; END;
CREATE TRIGGER edited_tag_aliases_out AFTER DELETE ON tag_aliases BEGIN UPDATE tags SET edited_at = unixepoch() WHERE id = OLD.tag_id; END;
CREATE TRIGGER edited_tags AFTER UPDATE OF name, description, category, parent_id, cover_asset_id, cover_at_ms, cover_upload_id, cover_frame, cover_cleared_at ON tags WHEN (OLD.name IS NOT NEW.name OR OLD.description IS NOT NEW.description OR OLD.category IS NOT NEW.category OR (OLD.parent_id IS NOT NEW.parent_id AND (NEW.parent_id IS NOT NULL OR EXISTS (SELECT 1 FROM tags WHERE id = OLD.parent_id))) OR (OLD.cover_by_default IS NEW.cover_by_default AND ((OLD.cover_asset_id IS NOT NEW.cover_asset_id AND (NEW.cover_asset_id IS NOT NULL OR EXISTS (SELECT 1 FROM assets WHERE id = OLD.cover_asset_id))) OR OLD.cover_at_ms IS NOT NEW.cover_at_ms OR OLD.cover_upload_id IS NOT NEW.cover_upload_id OR OLD.cover_frame IS NOT NEW.cover_frame OR OLD.cover_cleared_at IS NOT NEW.cover_cleared_at))) BEGIN UPDATE tags SET edited_at = unixepoch() WHERE id = NEW.id; END;
CREATE TRIGGER edited_usernames AFTER UPDATE OF name, display_name, url, number, person_id, site_id ON usernames WHEN (OLD.name IS NOT NEW.name OR OLD.display_name IS NOT NEW.display_name OR OLD.url IS NOT NEW.url OR OLD.number IS NOT NEW.number OR (OLD.person_id IS NOT NEW.person_id AND (NEW.person_id IS NOT NULL OR EXISTS (SELECT 1 FROM people WHERE id = OLD.person_id))) OR (OLD.site_id IS NOT NEW.site_id AND (NEW.site_id IS NOT NULL OR EXISTS (SELECT 1 FROM sites WHERE id = OLD.site_id)))) BEGIN UPDATE usernames SET edited_at = unixepoch() WHERE id = NEW.id; END;
CREATE TRIGGER edited_usernames_person AFTER UPDATE OF person_id ON usernames WHEN OLD.person_id IS NOT NEW.person_id BEGIN UPDATE people SET edited_at = unixepoch() WHERE id IN (OLD.person_id, NEW.person_id); END;
CREATE INDEX ix_loc_filename_folded ON asset_locations(lower(filename));
CREATE TRIGGER undo_rows_go_with_their_receipt AFTER DELETE ON workbench_decisions BEGIN DELETE FROM undo_rows WHERE receipt_id = OLD.id; END;
PRAGMA writable_schema=OFF;
COMMIT;
